<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Welcome <?php echo e(session('staffInfo')[0]->name); ?></title>



<!-- Styles -->
<?php $__env->startSection('styles1'); ?>
<link href="/assets/css/lib/weather-icons.css" rel="stylesheet" />
<link href="/assets/css/lib/owl.carousel.min.css" rel="stylesheet" />
<link href="/assets/css/lib/owl.theme.default.min.css" rel="stylesheet" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles2'); ?>
<link href="/assets/css/lib/helper.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

</head>

<body >

<?php $__env->startSection('content'); ?>

<div class="content-wrap">
<div class="main">
<div class="container-fluid">

<main role="main">

<header id="main-header" class="content-wrap  text-white">
<div class="main">
<div class="container-fluid">
<div class="col-md-12">
  <br>
<h2> <b>Dashboard</b> </h2>
</div>

<?php if(Session::has('successfull')): ?>

<div  class="alert alert-success m-2" role="alert" style="color:white;">

<?php echo e(Session::pull('successfull')); ?> 

</div>

<?php endif; ?>

</div>
</div>
</header>

<!-- graph -->
<canvas style="margin-left: 10px;" class="my-4 w-100" id="myChart" width="1000" height="380"></canvas>
<br>

<canvas id="pie-chart" width="1500" height="400">
    
</canvas>


 <!-- end graph -->            

<br><br>
<?php if(array_key_exists ( 'emp-details' , $result )): ?>
<!-- Newly added Employes -->
<div class="container-fluid">
<br>
<!-- List View for Emp-->
<section id="posts">
<div>
<div class="row">
<div class="col">
<div>
<div class="card-header web_back_color">
<div class="row">
<div class="col-sm-6">
<h4 class="text-white">Newly <b>Added Employees</b>
</h4>
</div>

</div>

</div>

<table class="table table-striped bg-fadded">
<thead>
<tr>
<th>Id</th>
<th>Name</th>
<th>Email</th>
<th>Role</th>
<th style="text-align: left;">Dept Name</th>
</tr>
</thead>

<tbody id="emps">
<?php $__empty_1 = true; $__currentLoopData = $result['emp-details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>

<td scope="row">

<?php echo e($value->id); ?>


</td>

<td>

<?php echo e(ucwords($value->name)); ?>


</td>

<td><?php echo e($value->email); ?></td>

<td><?php echo e(ucwords($value->role)); ?></td>

<td style="text-align: left;"><?php echo e(ucwords($value->dept)); ?></td>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<tr></tr>

<?php endif; ?>

</tbody>
</table>

</div>

<div class="card-header bg-fadded mt-0">

<div style="float:right;display: block;">
<a href="/dashboard/employees"><button class="btn2" >Show more</button>
</a>
</div>

<br>
<br>

</div>


</div>
</div>
</div>
</section>
</div>

<br>

<?php endif; ?>


<?php if(array_key_exists ( 'verified' , $result )): ?>
<!-- Newly added Students -->
<div class="container-fluid">
<br>
<!-- List View for Emp-->
<section id="posts">
<div>
<div class="row">
<div class="col">
<div>
<div class="card-header web_back_color">
<div class="row">
<div class="col-sm-6">
<h4 class="text-white">Recently <b>Verified Students</b></b>
</h4>
</div>

</div>

</div>

<table class="table table-striped bg-fadded">
<thead>
<tr>
<th>#</th>
<th>Full Name</th>
<th>Roll no</th>
<th>Department</th>
<th>Batch</th>
</tr>
</thead>

<tbody id="emps">
<?php $__empty_1 = true; $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
<td scope="row"><?php echo e($loop->index+1); ?></td>
<td><?php echo e(ucwords($std->fullname)); ?></td>
<td><?php echo e(strtoupper($std->rollNo)); ?></td>
<td><?php echo e(ucwords($std->name)); ?></td>
<td><?php echo e($std->batch); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<tr></tr>
<?php endif; ?>
</tbody>
</table>

</div>

<div class="card-header bg-fadded mt-0">

<div style="float:right;display: block;">
<a href="/dashboard/verifiedStudents"><button class="btn2" >Show more</button>
</a>
</div>

<br>
<br>

</div>


</div>
</div>
</div>
</section>
</div>

<br>

<?php endif; ?>

<?php if(array_key_exists ( 'student' , $result )): ?>
<!-- Newly added Students -->
<div class="container-fluid">
<br>
<!-- List View for Emp-->
<section id="posts">
<div>
<div class="row">
<div class="col">
<div>
<div class="card-header web_back_color">
<div class="row">
<div class="col-sm-6">
<h4 class="text-white">Recently <b>Graduating Students</b></b>
</h4>
</div>

</div>

</div>

<table class="table table-striped bg-fadded">
<thead>
<tr>
<th>#</th>
<th>Full Name</th>
<th>Roll no</th>
<th>Department</th>
<th>Batch</th>
</tr>
</thead>

<tbody id="emps">
<?php $__empty_1 = true; $__currentLoopData = $result2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
<td scope="row"><?php echo e($loop->index+1); ?></td>
<td><?php echo e(ucwords($user->fullname)); ?></td>
<td><?php echo e(strtoupper($user->rollNo)); ?></td>
<td><?php echo e(ucwords($user->name)); ?></td>
<td><?php echo e($user->batch); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<tr></tr>
<?php endif; ?>
</tbody>
</table>

</div>

<div class="card-header bg-fadded mt-0">

<div style="float:right;display: block;">
<a href="/dashboard/students"><button class="btn2" >Show more</button>
</a>
</div>

<br>
<br>

</div>


</div>
</div>
</div>
</section>
</div>

<br>

<?php endif; ?>


</main>
</div>
</div>
</div>


<!-- List of Graduating students-->



<?php $__env->stopSection(); ?> 



<!-- Graphs -->
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>


<script type="text/javascript">

document.getElementById('dashboard').classList.add('active');

document.getElementById('staff').classList.remove('active');

document.getElementById('students').classList.remove('active');

document.getElementById('account_rights').classList.remove('active');

document.getElementById('verstudents').classList.remove('active');

document.getElementById('profile').classList.remove('active');

document.getElementById('log').classList.remove('active');

document.getElementById('setting').classList.remove('active');
</script>

<?php if(array_key_exists ( 'graph' , $result )): ?>

<script>


new Chart(document.getElementById("myChart"), {
    type: 'horizontalBar',
    data: {
      labels: ["Website","Mobile Application"],
      datasets: [{
        
        backgroundColor: ['#34DDDD','#ffc107'],
        borderColor: ['#34DDDD','#ffc107'],
        data: [<?php echo e($visits['web']); ?>,<?php echo e($visits['mobile']); ?>]
      }]
    },
    options: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Requests For Verification Using Different Mediums'
      }
    }
});

new Chart(document.getElementById("pie-chart"), {
    type: 'pie',
    data: {
      labels: ["Degree","Pass Certificate","Transcript"],
      datasets: [{
        
        backgroundColor: ["#fb5d7c", "#8e5ea2","#c45850"],
        data: [<?php echo e($certificate['degree']); ?>,<?php echo e($certificate['pass']); ?>,<?php echo e($certificate['trans']); ?>]
      }]
    },
    options: {
      title: {
        display: true,
        text: 'Certificate Serach By User'
      }
    }
});

</script>
<?php endif; ?>


<?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>