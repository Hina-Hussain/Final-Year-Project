<div class="modal fade" id="ViewSModal">
<div class="modal-dialog modal-lg">
<div class="modal-content">


<!-- Tab panes -->


<div class="modal-header bg-info  text-white">
<h5 class="modal-title text-white" id="addEModalLabel">Student Profile - <?php echo e(ucwords($res->fullname)); ?></h5>
<button class="close text-white" data-dismiss="modal">
<span>&times;</span>
</button>
</div>
<div class="modal-body">
<form class="form-horizontal" role="form" method="post" action="#">
<div class="col-sm-12">
<div>
<div class="card-user">
<div class="author2">
<a href="#">
<img class="avatar border-gray" src="<?php echo e(asset('storage/uploads/students/'.$res->pic)); ?>" alt="...">
</a>
</div>
<div class="Username">
<p style="text-align: center;font-size: 2em;color: black;font-style: bold;font-family: 'Raleway', sans-serif;margin-bottom: 2px">

    <?php echo e(ucwords($res->fullname)); ?>


  </p>

 <p style="text-align: center;font-size: 1.75em;font-family: 'Raleway', sans-serif;margin-top: 2px;letter-spacing: 2px" class="lead">
       <?php echo e(ucwords($res->currentPosition)); ?>

  </p>

 </div>


<!-- Nav tabs -->
<ul class="nav nav-tabs nav-justified customtab2" role="tablist">
<li class="nav-item col-sm-4" > <a class="nav-link active" data-toggle="tab" href="#PInformation" role="tab"><span><i class="fa fa-user-circle"></i> Personal Information</span></a> </li>
<li class="nav-item col-sm-4">
<a class="nav-link" data-toggle="tab" href="#AInfo" role="tab"> <span><i class="ti-blackboard"></i> Academic Information</span></a>
</li>
<li class="nav-item col-sm-4">
<a class="nav-link" data-toggle="tab" href="#SettingInfo" role="tab"> <span><i class="ti-pencil-alt"></i> Settings</span></a>
</li>
</ul>



<!--PErsonal Information-->            
<div class="tab-content">
<div class="tab-pane active" id="PInformation" role="tabpanel">
<div>
<div>
<div class="tab-content">
<div>
<div class="contact-information">
<legend>Personal Information</legend>
<div class="phone-content">
<span class="contact-title">Full Name:</span>
<span class="phone-number">
	<?php echo e(ucwords($res->fullname)); ?>


</span>
</div>
<div class="phone-content">
<span class="contact-title">Father Name:</span>
<span class="phone-number">
	<?php echo e(ucwords($res->fatherName)); ?>


</span>
</div>
<div class="phone-content">
<span class="contact-title"> Surname:</span>
<span class="phone-number">
	<?php echo e(ucwords($res->surname)); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title">CNIC:</span>
<span class="phone-number"><?php echo e($res->cnic); ?></span>
</div>
<div class="gender-content">
<span class="contact-title">Date Of Birth:</span>
<span class="gender" type="date" name="bday" ><?php echo e($res->dob); ?></span>
</div>

<div class="gender-content">
<span class="contact-title">Gender:</span>
<span class="gender">
	
  <?php echo e($res->gender== 'm' ? 'Male' : 'Female'); ?> 

</span>
</div>
</div>

<div class="contact-information">

<legend>Address & Contact Information</legend>
<div class="phone-content">
<span class="contact-title">Cell Phone:</span>
<span class="phone-number"><?php echo e($res->mbNo); ?></span>
</div>
      <div class="phone-content">
<span class="contact-title">Address:</span>
<span class="phone-number"><?php echo e($res->addr); ?></span>
</div>
<div class="phone-content">
<span class="contact-title">Email:</span>
<span class="phone-number"><?php echo e($res->email); ?></span>
</div>


<div class="gender-content">
<span class="contact-title">Domicile:</span>
<span class="gender" type="date" name="bday" >
	
	<?php echo e(ucwords($res->domicile)); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title">Province:</span>
<span class="phone-number">
	<?php echo e(ucwords($res->province)); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title">Country:</span>
<span class="phone-number">
	<?php echo e(ucwords($res->country)); ?>

</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<!-- tab2 -->
<div class="tab-pane p-20" id="AInfo" role="tabpanel">
<div class="col-sm-12">
<div class="row">
<div class="col-sm-6">
<div class="basic-information">
<legend>Academic Information</legend>
<div class="phone-content">
<span class="contact-title">Roll No:</span>
<span class="phone-number">
	<?php echo e(strtoupper($res->rollNo)); ?>

</span>
</div>

</div>
<div class="phone-content">
<span class="contact-title">Enrollment No:</span>
<span class="phone-number">
	<?php echo e($res->enrollmentNo); ?>

</span>
</div>                               
 <div class="phone-content">
<span class="contact-title">Department:</span>
<span class="phone-number">
	<?php echo e(ucwords($res->dept)); ?>

</span>
</div>
<div class="phone-content">
<span class="contact-title">Date Of Admission:</span>
<span class="phone-number"><?php echo e($res->doa); ?></span>
</div>

<div class="phone-content">
<span class="contact-title  ">Programme:</span>
<span class="phone-number">
   <?php echo e(strtoupper($res->programme)); ?>

</span>
    
</div>
              
<div class="phone-content">
<span class="contact-title">CGPA:</span>
<span class="phone-number"><?php echo e($degree->cgpa); ?></span>
</div>
              <div class="phone-content">
<span class="contact-title">Position:</span>
<?php
if($degree->position==1){$position = "1st";}
elseif($degree->position==2){$position = "2nd";}
elseif($degree->position==3){$position = "3rd";}
else
{$position = "None";}
?>
<span class="phone-number"><?php echo e($position); ?></span>
</div>
              <div class="phone-content">
<span class="contact-title">Last Exam Held:</span>
<span class="phone-number"><?php echo e($degree->doe); ?></span>
</div>
</div>
</div>

</div>
</div>

<!------------- SETTINGS ------------------------>


<div class="tab-pane p-20" id="SettingInfo" role="tabpanel">
<div class="col-sm-12">
	
<div class="row">
<div class="col-sm-8">


<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label">Mobile No:</label>
<div class="col-sm-8">
<input type="number" name="mobno" class="form-control"
 id="mobno" placeholder="enter mobile no" 
 value="<?php echo e($res->mbNo); ?>" required style="display: none;width: 100%">

<p style="font-size: 1.25em;" class="lead" id="prevmobno"><?php echo e($res->mbNo); ?></p>

</div>

<div class="col-sm-1 mr-7" id="editNo">
<a href="#" onclick="editMob()" id="editmob"><i class="btn fa fa-edit" title="Edit" style="color: #FFC107;">

</i></a>

<a href="#" onclick="saveMob('<?php echo e($res->rollNo); ?>')" id="savemob" style="display: none;"><i class="btn fa fa-check-circle-o" title="Save" style="color: green"></i></a>


</div>

<p class="mb-1 hidden" style="width:100%;color:red;display: none;" id="errors1">
	
</p>

<p class="mb-1" style="width:100%;color:green;display: none;" id="success1"></p>

</div>



<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label">Email:</label>
<div class="col-sm-8">

<input type="email" name="mail" class="form-control"
 id="mail" placeholder="enter email" 
 value="<?php echo e($res->email); ?>" required style="display: none;width: 100%">

<p style="font-size: 1.25em;" class="lead" id="prevmail"><?php echo e($res->email); ?></p>

</div>
<div class="col-sm-1 mr-7" id="editSaveB">
<a href="#" onclick="editMail()" id="editmail"><i class="btn fa fa-edit" title="Edit" style="color: #FFC107;"></i></a>

<a href="#" onclick="saveMail('<?php echo e($res->rollNo); ?>')" id="savemail" style="display: none;"><i class="btn fa fa-check-circle-o" title="Save" style="color: green;"></i></a>

</div>
<p class="mb-1 hidden" style="width:100%;color:red;display: none;" id="errors2"></p>

<p class="mb-1" style="width:100%;color:green;display: none;" id="success2"></p>
</div>



<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label">Address:</label>
<div class="col-sm-8">

<input type="text" name="addr" class="form-control"
 id="addr" placeholder="enter address" 
 value="<?php echo e($res->addr); ?>" required style="display: none;width: 100%">

<p style="font-size: 1.25em;" class="lead" id="prevaddr"><?php echo e($res->addr); ?></p>


</div>
<div class="col-sm-1 mr-7" id="editA">

<a href="#" onclick="editAddr()" id="editaddr"><i class="btn fa fa-edit" title="Edit" style="color: #FFC107;">
	
</i></a>

<a href="#" onclick="saveAddr('<?php echo e($res->rollNo); ?>')" id="saveaddr" style="display: none;"><i class="btn fa fa-check-circle-o" title="Save" style="color: green"></i></a>
</div>

<p class="mb-1 hidden" style="width:100%;color:red;display: none;" id="errors3"></p>

<p class="mb-1" style="width:100%;color:green;display: none;" id="success3"></p>

</div>


<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label">Current Position:</label>
<div class="col-sm-8">

<input type="text" name="currPos" class="form-control"
 id="currPos" placeholder="enter current Position" 
 value="<?php echo e($res->currentPosition); ?>" required style="display: none;width: 100%">

<p style="font-size: 1.25em;" class="lead" id="prevCP"><?php echo e($res->currentPosition); ?></p>
</div>
<div class="col-sm-1 mr-7" id="editCP">
<a href="#" onclick="editCP()" id="editCp"><i class="btn fa fa-edit" title="Edit" style="color: #FFC107;">
	
</i></a>

<a href="#" onclick="saveCP('<?php echo e($res->rollNo); ?>')" id="saveCp" style="display: none;"><i class="btn fa fa-check-circle-o" title="Save" style="color: green;"></i></a>


</div>
<p class="mb-1 hidden" style="width:100%;color:red;display: none;" id="errors4"></p>

<p class="mb-1" style="width:100%;color:green;display: none;" id="success4"></p>


</div>
</div>
</div>
</div>
</div>



</div>
</div>

</div>
</div>
</div>
</div>

<script type="text/javascript">
function editMob()
{
document.getElementById('editmob').style = "display:none";
document.getElementById('savemob').style = "display:inline-block";
document.getElementById('prevmobno').style = "display:none";
document.getElementById('mobno').style = "display:inline-block";

}

function saveMob(id)
{

 var mobno = $('#mobno').val().trim();
 var prevmob = $('#prevmobno').text();

 if(mobno=="")
 {
 	document.getElementById('errors1').style="color:red;display:inline-block;";

 	document.getElementById('errors1').innerHTML = "Mobile number field is required!";

 }

else if(mobno==prevmob)
 {
  document.getElementById('editmob').style = "display:inline-block";
    document.getElementById('savemob').style = "display:none";
  document.getElementById('prevmobno').style = "display:inline-block;";

document.getElementById('mobno').style = "display:none";
document.getElementById('errors1').style= "display:none";
	
	document.getElementById('success1').style = "display:none";
 }

 else if(mobno.length==11)
 {
 	$.ajax({
 	type:"get",
 	url : '<?php echo e(URL::to("/settings/mobno")); ?>/'+id,
 	data:{'mobno':mobno,'prevmobno':prevmob},
 	success:function(response)
 	{
     if(response=="TRUE")
     {
   document.getElementById('editmob').style = "display:inline-block";
    document.getElementById('savemob').style = "display:none";
  document.getElementById('prevmobno').style = "display:inline-block";

document.getElementById('mobno').style = "display:none";
     $('#prevmobno').text(mobno);

  document.getElementById('errors1').style = "display:none";
   document.getElementById('success1').style="color:green;display:inline-block;";

 	document.getElementById('success1').innerHTML = "Successfully Update!";


     }
 	}
 	});
 }

 else
 	{
 		document.getElementById('errors1').style="color:red;display:inline-block;";

 	document.getElementById('errors1').innerHTML = "Mobile number must be in 11 digits";
 	}
}


function editMail() {
  document.getElementById('editmail').style = "display:none";

  document.getElementById('savemail').style = "display:inline-block";
document.getElementById('prevmail').style = "display:none";
document.getElementById('mail').style = "display:inline-block";


}

function saveMail(id)
{
	var mail = $('#mail').val().trim();
	var oldmail = $('#prevmail').text();

if(mail==oldmail)
{
	 document.getElementById('editmail').style = "display:inline-block";

  document.getElementById('savemail').style = "display:none";
document.getElementById('prevmail').style = "display:inline-block";
document.getElementById('mail').style = "display:none";

document.getElementById('errors2').style= "display:none";
	
	document.getElementById('success2').style = "display:none";
}
else if(mail=="")
{
	document.getElementById('success2').style = "display:none";
	document.getElementById('errors2').style = "color:red;display:inline-block;";
	document.getElementById('errors2').innerHTML = "Email field is required";
}

else if(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
  {
  $.ajax({
   type:"get",
   url : "<?php echo e(URL::to('/settings/email')); ?>/"+id,
   data: {"mail":mail,"prevmail":oldmail},
   success:function(response)
   {
   if(response=="TRUE")
   {
   	 document.getElementById('editmail').style = "display:inline-block";

  document.getElementById('savemail').style = "display:none";
document.getElementById('prevmail').style = "display:inline-block";
$('#prevmail').text(mail);
document.getElementById('mail').style = "display:none";
 
 document.getElementById('errors2').style = "display:none";
   document.getElementById('success2').style="color:green;display:inline-block;";

 	document.getElementById('success2').innerHTML = "Successfully Update!";

   }
   }
  });
}
else
{
	document.getElementById('success2').style = "display:none";

	document.getElementById('errors2').style = "color:red;display:inline-block";
	document.getElementById('errors2').innerHTML = "The email must be a valid email address.";

}
}




function editAddr() {
	 document.getElementById('editaddr').style = "display:none";

  document.getElementById('saveaddr').style = "display:inline-block";
document.getElementById('prevaddr').style = "display:none";
document.getElementById('addr').style = "display:inline-block";


}

function saveAddr(id){
	var address = $('#addr').val().trim();
	var oldaddr = $('#prevaddr').text();

	if(address==oldaddr)
	{
	document.getElementById('errors3').style = "display:none";
	
	document.getElementById('success3').style = "display:none";
		
  document.getElementById('editaddr').style = "display:inline-block";

   document.getElementById('saveaddr').style = "display:none";
 document.getElementById('prevaddr').style = "display:inline-block";
 document.getElementById('addr').style = "display:none";
	}
else if(address=="")
{
 document.getElementById('success3').style = "display:none";
 document.getElementById('errors3').style = "color:red;display:inline-block";
 document.getElementById('errors3').innerHTML = "Address field is required";
}
else
{
 $.ajax({
 	type:"get",
 	url : "<?php echo e(URL::to('/settings/address')); ?>/"+id,
 	data : {'addr':address,'prevaddr':oldaddr},
 	success:function(response)
 	{
   if(response=="TRUE")
   {
   	 document.getElementById('editaddr').style = "display:inline-block";

   document.getElementById('saveaddr').style = "display:none";
 document.getElementById('prevaddr').style = "display:inline-block";
 $('#prevaddr').text(address);
 document.getElementById('addr').style = "display:none";
 document.getElementById('errors3').style = "display:none";
 document.getElementById('success3').style = "color:green;display:inline-block";
 document.getElementById('success3').innerHTML = "Successfully Update!";
   }
 	}
 });
}	
}


function editCP()
{
	 document.getElementById('editCp').style = "display:none";

  document.getElementById('saveCp').style = "display:inline-block";
document.getElementById('prevCP').style = "display:none";
document.getElementById('currPos').style = "display:inline-block";


}

function saveCP(id)
{
 var currPos = $('#currPos').val().trim();
 var prevCP =  $('#prevCP').text();

 if(currPos==prevCP)
 {
 	document.getElementById('errors4').style = "display:none";
	
	document.getElementById('success4').style = "display:none";

	document.getElementById('editCp').style = "display:inline-block";

  document.getElementById('saveCp').style = "display:none";
document.getElementById('prevCP').style = "display:inline-block";
document.getElementById('currPos').style = "display:none";

 }
 else if(currPos=="")
 {
 	document.getElementById('errors4').style = "color:red;display:inline-block";
 	document.getElementById('errors4').innerHTML = "Current Position field is required";
	
	document.getElementById('success4').style = "display:none";

 }

 else
 {
 	$.ajax({
 	type:"get",
 	url : "<?php echo e(URL::to('/settings/currPos')); ?>/"+id,
 	data:{'currPos':currPos,'prevPos':prevCP},
 	success:function(response)
 	{
    if(response=="TRUE")
    {
    	document.getElementById('errors4').style = "display:none";
	
	document.getElementById('editCp').style = "display:inline-block";

  document.getElementById('saveCp').style = "display:none";
document.getElementById('prevCP').style = "display:inline-block";
$('#prevCP').text(currPos);

document.getElementById('currPos').style= "display:none";
    
document.getElementById('success4').style = "color:green;display:inline-block";
document.getElementById('success4').innerHTML="Successfully Update!";
    }
 	}
 	});
 }	
}

</script>

