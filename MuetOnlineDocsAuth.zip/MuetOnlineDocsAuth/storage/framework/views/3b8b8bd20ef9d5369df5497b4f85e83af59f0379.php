
<form class="form-horizontal" role="form" method="post" action="/pinfo/update" enctype="multipart/form-data" id="pinfoform">

    <?php echo csrf_field(); ?>
  <div class="alert alert-danger hidden" id="fail"
  style="color: white;" >
</div>

<input type="hidden" name="id" value="<?php echo e($user->rollNo); ?>"
id="rollno">
<div class="text-center">
<div class="row">
<legend>Personal Information</legend>

<div class="col-sm-6">
<div class="form-group row">
<label for="Name" class="col-sm-4 col-form-label">Full Name:</label>
<div class="col-sm-8">
<input type="text" name="fullname" class="form-control" id="Name" placeholder="Full Name" required value="<?php echo e($user->fullname); ?>">

<input type="hidden" name="oldname" value="<?php echo e($user->fullname); ?>">

</div>
</div>
<div class="form-group row">
<label for="Name" class="col-sm-4 col-form-label">Father Name:</label>
<div class="col-sm-8">
<input type="text" name="fathername" class="form-control" id="Name" placeholder="Father Name" required value="<?php echo e($user->fatherName); ?>">
<input type="hidden" name="oldfathername" value="<?php echo e($user->fatherName); ?>">
</div>
</div>
<div class="form-group row">
<label for="Name" class="col-sm-4 col-form-label">Surname:</label>
<div class="col-sm-8">
<input type="text" name="surname" class="form-control" id="Name" placeholder="Surname" required value="<?php echo e($user->surname); ?>">
<input type="hidden" name="oldsurname" value="<?php echo e($user->surname); ?>">
</div>
</div>
<div class="form-group row">
<label class="col-sm-4 col-form-label" for="gender">Gender</label>
<div class="col-sm-8">
<label class="radio-inline" for="gender-0">
<input type="radio" name="gender" id="gender-0" value="m" checked="checked" required="" aria-required="true"> Male
</label>
<label class="radio-inline" for="gender-1">
<input type="radio" name="gender" id="gender-1" value="f" required="" aria-required="true"> Female
<input type="hidden" name="oldgender" value="<?php echo e(strtolower($user->gender)); ?>">
</label>
</div>
</div>
<div class="form-group row">
<label class="col-sm-4 control-label">Date Of Birth:</label>
<div class="col-sm-8">
<input class="form-control" type="date" name="dob" required
value="<?php echo e($user->dob); ?>">
<input type="hidden" name="olddob" value="<?php echo e($user->dob); ?>">
</div>
</div>
<div class="form-group  row">
<label class="col-sm-4 col-form-label">CNIC no:</label>
<div class="col-sm-8 ">
<input type="text" class="form-control" name="cnic" required minlength="13" maxlength="13" value="<?php echo e($user->cnic); ?>" id="cnic">
<input type="hidden" name="oldcnic" value="<?php echo e($user->cnic); ?>">
</div>
</div>
</div>
<!-- close of div 8 now image -->
<div class="col-sm-6 ">

    <div class="alert alert-danger" role="alert" id="imgeerror" style="display: none">
        Image should be less than 64 kb in size and image should have jpg,jpeg or png extension
    </div>    

    <img  src=  "<?php echo e(asset('/storage/uploads/students/'.$user->pic)); ?>"

 alt="" class="img-fluid mb-3 img-rounded" width="150px" height="70" id="preview" >

    <br>

    <input type="file" class="ml-5" name="pic" onchange="imagePreview(this.files[0])" id="pic">
   
   
    <input type="hidden" name="imageName" value="<?php echo e($user->pic); ?>">

   

</div>
</div>
<div class="row">
<legend>Address & Contact Information</legend>
<div class="col-sm-6">
<div class="form-group row">
<label for="example-tel-input" class="col-sm-4 col-form-label">Cell no:</label>
<div class="col-sm-8">
<input class="form-control" type="tel" value="<?php echo e($user->mbNo); ?>" id="example-tel-input" minlength="11" maxlength="11" name="mobno" required>

<input type="hidden" name="oldmobno" value="<?php echo e($user->mbNo); ?>">
</div>
</div>
<div class="form-group row">
<label for="Name" class="col-sm-4 col-form-label">Address:</label>
<div class="col-sm-8">
<textarea name="address" class="form-control" id="Name" placeholder="Address" required>
    <?php echo e($user->addr); ?>

</textarea>
<input type="hidden" name="oldadd" value="<?php echo e($user->addr); ?>">
</div>
</div>
<div class="form-group row">
<label for="Name" class="col-sm-4 col-form-label">Email:</label>
<div class="col-sm-8">
<input type="text" name="email" class="form-control" id="Name" placeholder="Email"  value="<?php echo e($user->email); ?>">

<input type="hidden" name="oldmail" value="<?php echo e($user->email); ?>">
</div>
</div>
</div>
<div class="col-sm-6">
<div class="form-group row">
<label for="domicile" class="col-sm-3 control-label">Domicile:</label>
<div class="col-sm-8">
<select class="form-control selectpicker" id="domicile" name="domicile">
  
    <option value=" ">Please select Domicile</option>
    <option value="hyderabad">Hyderabad</option>
    <option value="jacobabad">Jacobabad</option>
    <option value="karachi">Karachi</option>
    <option value="larkana">Larkana</option>
    <option value="dadu">Dadu</option>
    <option value="sukkur">Sukkur</option>
    <option value="umerkot">UmerKot</option>
    <option value="shikarpur">Shikarpur</option>
    <option value="nawabshah">Nawabshah</option>
    <option value="tando muhammad khan">Tando Muhammad Khan</option>
    <option value="mirpurkhas">Mirpurkhas</option>
    <option value="kashmor">Kashmor</option>
    <option value="ghotki">Ghotki</option>
    <option value="khaipur">Khaipur</option>
    <option value="sujawal">Sujawal</option>
    <option value="thata">Thata</option>
</select>

<input type="hidden" name="olddomicile"
 value="<?php echo e(strtolower($user->domicile)); ?>">

</div>
</div>
<div class="form-group row">
<label for="domicile" class="col-sm-3 control-label">Province:</label>
<div class="col-sm-8">

<select id="province" name="province" class="form-control required valid" aria-required="true" aria-invalid="false">
     <option value=" ">Please select Province</option>
    <option value="sindh">Sindh</option>
    <option value="balochistan">Balochistan</option>
    <option value="kpk">Khyber Pakhtunkhwa</option>
    <option value="punjab">Punjab</option>
    <option value="islamabad">Islamabad Capital Territory</option>
    <option value="fata">Federally Administered Tribal Areas</option>
    <option value="azad kashmir">Azad Kashmir</option>
    <option value="gilgit–baltistan">Gilgit–Baltistan</option>
</select>
<input type="hidden" name="oldprovince" value="<?php echo e(strtolower($user->province)); ?>">
</div>
</div>
<div class="form-group row">
<label for="domicile" class="col-sm-3 control-label">Country:</label>
<div class="col-sm-8">
<select id="country" name="country" class="form-control required valid" aria-required="true" aria-invalid="false">
    <option value=" ">Please select Country</option>
   
   
  
    <option value="united arab emirates">United Arab Emirates</option>
    <option value="afghanistan">Afghanistan</option>
    <option value="aland islands">Åland Islands</option>
    <option value="albania">Albania</option>
    <option value="algeria">Algeria</option>
    <option value="american Samoa">American Samoa</option>
    <option value="andorra">Andorra</option>
    <option value="angola">Angola</option>
    <option value="anguilla">Anguilla</option>
    <option value="antarctica">Antarctica</option>
    <option value="antigua and barbuda">Antigua and Barbuda</option>
    <option value="argentina">Argentina</option>
    <option value="armenia">Armenia</option>
    <option value="aruba">Aruba</option>
    <option value="australia">Australia</option>
    <option value="austria">Austria</option>
    <option value="azerbaijan">Azerbaijan</option>
    <option value="bahamas">Bahamas</option>
    <option value="bahrain">Bahrain</option>
    <option value="bangladesh">Bangladesh</option>
    <option value="barbados">Barbados</option>
    <option value="belarus">Belarus</option>
    <option value="belgium">Belgium</option>
    <option value="belize">Belize</option>
    <option value="benin">Benin</option>
    <option value="bermuda">Bermuda</option>
    <option value="bhutan">Bhutan</option>
    <option value="bolivia">Bolivia</option>
    <option value="bosnia and Herzegovina">Bosnia and Herzegovina</option>
    <option value="botswana">Botswana</option>
    <option value="bouvet Island">Bouvet Island</option>
    <option value="brazil">Brazil</option>
    <option value="british Indian Ocean Territory">British Indian Ocean Territory</option>
    <option value="brunei Darussalam">Brunei Darussalam</option>
    <option value="bulgaria">Bulgaria</option>
    <option value="burkina Faso">Burkina Faso</option>
    <option value="burundi">Burundi</option>
    <option value="cambodia">Cambodia</option>
    <option value="cameroon">Cameroon</option>
    <option value="canada">Canada</option>
    <option value="cape verde">Cape Verde</option>
    <option value="cayman islands">Cayman Islands</option>
    <option value="central african republic">Central African Republic</option>
    <option value="chad">Chad</option>
    <option value="chile">Chile</option>
    <option value="china">China</option>
    <option value="christmas Island">Christmas Island</option>
    <option value="cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
    <option value="colombia">Colombia</option>
    <option value="comoros">Comoros</option>
    <option value="congo">Congo</option>
    <option value="cook islands">Cook Islands</option>
    <option value="costa rica">Costa Rica</option>
    <option value="cote d'ivoire">Cote D'ivoire</option>
    <option value="croatia">Croatia</option>
    <option value="cuba">Cuba</option>
    <option value="cyprus">Cyprus</option>
    <option value="czech republic">Czech Republic</option>
    <option value="denmark">Denmark</option>
    <option value="djibouti">Djibouti</option>
    <option value="dominica">Dominica</option>
    <option value="ominican republic">Dominican Republic</option>
    <option value="ecuador">Ecuador</option>
    <option value="egypt">Egypt</option>
    <option value="el salvador">El Salvador</option>
    <option value="equatorial guinea">Equatorial Guinea</option>
    <option value="eritrea">Eritrea</option>
    <option value="estonia">Estonia</option>
    <option value="ethiopia">Ethiopia</option>
    <option value="falkland islands (malvinas)">Falkland Islands (Malvinas)</option>
    <option value="faroe islands">Faroe Islands</option>
    <option value="fiji">Fiji</option>
    <option value="finland">Finland</option>
    <option value="france">France</option>
    <option value="french guiana">French Guiana</option>
    <option value="french polynesia">French Polynesia</option>
    <option value="french southern territories">French Southern Territories</option>
    <option value="gabon">Gabon</option>
    <option value="gambia">Gambia</option>
    <option value="georgia">Georgia</option>
    <option value="germany">Germany</option>
    <option value="ghana">Ghana</option>
    <option value="gibraltar">Gibraltar</option>
    <option value="greece">Greece</option>
    <option value="greenland">Greenland</option>
    <option value="grenada">Grenada</option>
    <option value="guadeloupe">Guadeloupe</option>
    <option value="guam">Guam</option>
    <option value="guatemala">Guatemala</option>
    <option value="guernsey">Guernsey</option>
    <option value="guinea">Guinea</option>
    <option value="guinea-bissau">Guinea-bissau</option>
    <option value="guyana">Guyana</option>
    <option value="haiti">Haiti</option>
    <option value="heard island and mcdonald islands">Heard Island and Mcdonald Islands</option>
    <option value="holy see (vatican city state)">Holy See (Vatican City State)</option>
    <option value="honduras">Honduras</option>
    <option value="hong Kong">Hong Kong</option>
    <option value="hungary">Hungary</option>
    <option value="iceland">Iceland</option>
    <option value="india">India</option>
    <option value="indonesia">Indonesia</option>
    <option value="iran">Iran</option>
    <option value="iraq">Iraq</option>
    <option value="ireland">Ireland</option>
    <option value="isle of man">Isle of Man</option>
    <option value="italy">Italy</option>
    <option value="jamaica">Jamaica</option>
    <option value="japan">Japan</option>
    <option value="jersey">Jersey</option>
    <option value="jordan">Jordan</option>
    <option value="kazakhstan">Kazakhstan</option>
    <option value="kenya">Kenya</option>
    <option value="kiribati">Kiribati</option>
    <option value="north korea">North Korea</option>
    <option value="south korea">Sourth Korea</option>
    <option value="kuwait">Kuwait</option>
    <option value="kyrgyzstan">Kyrgyzstan</option>
    <option value="lao">Lao</option>
    <option value="latvia">Latvia</option>
    <option value="lebanon">Lebanon</option>
    <option value="lesotho">Lesotho</option>
    <option value="liberia">Liberia</option>
    <option value="libyan arab jamahiriya">Libyan Arab Jamahiriya</option>
    <option value="liechtenstein">Liechtenstein</option>
    <option value="lithuania">Lithuania</option>
    <option value="luxembourg">Luxembourg</option>
    <option value="macao">Macao</option>
    <option value="macedonia">Macedonia</option>
    <option value="madagascar">Madagascar</option>
    <option value="malawi">Malawi</option>
    <option value="malaysia">Malaysia</option>
    <option value="maldives">Maldives</option>
    <option value="mali">Mali</option>
    <option value="malta">Malta</option>
    <option value="marshall islands">Marshall Islands</option>
    <option value="martinique">Martinique</option>
    <option value="mauritania">Mauritania</option>
    <option value="mauritius">Mauritius</option>
    <option value="mayotte">Mayotte</option>
    <option value="mexico">Mexico</option>
    <option value="micronesia">Micronesia, Federated States of</option>
    <option value="moldova">Moldova, Republic of</option>
    <option value="monaco">Monaco</option>
    <option value="mongolia">Mongolia</option>
    <option value="montenegro">Montenegro</option>
    <option value="montserrat">Montserrat</option>
    <option value="morocco">Morocco</option>
    <option value="mozambique">Mozambique</option>
    <option value="myanmar">Myanmar</option>
    <option value="namibia">Namibia</option>
    <option value="nauru">Nauru</option>
    <option value="nepal">Nepal</option>
    <option value="netherlands">Netherlands</option>
    <option value="netherlands antilles">Netherlands Antilles</option>
    <option value="new caledonia">New Caledonia</option>
    <option value="new zealand">New Zealand</option>
    <option value="nicaragua">Nicaragua</option>
    <option value="niger">Niger</option>
    <option value="nigeria">Nigeria</option>
    <option value="niue">Niue</option>
    <option value="norfolk island">Norfolk Island</option>
    <option value="northern mariana islands">Northern Mariana Islands</option>
    <option value="norway">Norway</option>
    <option value="oman">Oman</option>
     <option value="pakistan" selected="selected">Pakistan</option>
      <option value="palestine">Palestine</option>
    <option value="palau">Palau</option>
    <option value="panama">Panama</option>
    <option value="papua new guinea">Papua New Guinea</option>
    <option value="paraguay">Paraguay</option>
    <option value="peru">Peru</option>
    <option value="philippines">Philippines</option>
    <option value="pitcairn">Pitcairn</option>
    <option value="poland">Poland</option>
    <option value="portugal">Portugal</option>
    <option value="puerto rico">Puerto Rico</option>
    <option value="qatar">Qatar</option>
    <option value="reunion">Reunion</option>
    <option value="romania">Romania</option>
    <option value="russian federation">Russian Federation</option>
    <option value="rwanda">Rwanda</option>

    <option value="saudi arabia">Saudi Arabia</option>
    <option value="saint helena">Saint Helena</option>
    <option value="saint kitts and nevis">Saint Kitts and Nevis</option>
    <option value="saint lucia">Saint Lucia</option>
    <option value="saint pierre and miquelon">Saint Pierre and Miquelon</option>
    <option value="saint vincent and the grenadines">Saint Vincent and The Grenadines</option>
    <option value="samoa">Samoa</option>
    <option value="san marino">San Marino</option>
    <option value="sao tome and principe">Sao Tome and Principe</option>
    <option value="senegal">Senegal</option>
    <option value="serbia">Serbia</option>
    <option value="seychelles">Seychelles</option>
    <option value="sierra leone">Sierra Leone</option>
    <option value="singapore">Singapore</option>
    <option value="slovakia">Slovakia</option>
    <option value="slovenia">Slovenia</option>
    <option value="solomon islands">Solomon Islands</option>
    <option value="somalia">Somalia</option>
    <option value="south africa">South Africa</option>
    <option value="south georgia and the south sandwich islands">South Georgia and The South Sandwich Islands</option>
     <option value="sudan">Sudan</option>
    <option value="spain">Spain</option>
    <option value="sri lanka">Sri Lanka</option>
    <option value="suriname">Suriname</option>
    <option value="svalbard and jan mayen">Svalbard and Jan Mayen</option>
    <option value="swaziland">Swaziland</option>
    <option value="sweden">Sweden</option>
    <option value="switzerland">Switzerland</option>
    <option value="syrian arab republic">Syrian Arab Republic</option>
    <option value="taiwan">Taiwan, Province of China</option>
    <option value="tajikistan">Tajikistan</option>
    <option value="tanzania">Tanzania, United Republic of</option>
    <option value="thailand">Thailand</option>
    <option value="timor-leste">Timor-leste</option>
    <option value="togo">Togo</option>
    <option value="tokelau">Tokelau</option>
    <option value="tonga">Tonga</option>
    <option value="trinidad and tobago">Trinidad and Tobago</option>
    <option value="tunisia">Tunisia</option>
    <option value="turkey">Turkey</option>
    <option value="turkmenistan">Turkmenistan</option>
    <option value="turks and caicos islands">Turks and Caicos Islands</option>
    <option value="tuvalu">Tuvalu</option>
    <option value="uganda">Uganda</option>
    <option value="ukraine">Ukraine</option>
    <option value="united kingdom">United Kingdom</option>
    <option value="united states">United States</option>
    <option value="united states minor outlying islands">United States Minor Outlying Islands</option>
    <option value="uruguay">Uruguay</option>
    <option value="uzbekistan">Uzbekistan</option>
    <option value="vanuatu">Vanuatu</option>
    <option value="venezuela">Venezuela</option>
    <option value="viet nam">Viet Nam</option>
    <option value="virgin islands, british">Virgin Islands, British</option>
    <option value="virgin islands, u.s">Virgin Islands, U.S.</option>
    <option value="wallis and futuna">Wallis and Futuna</option>
    <option value="western sahara">Western Sahara</option>
    <option value="yemen">Yemen</option>
    <option value="zambia">Zambia</option>
    <option value="zimbabwe">Zimbabwe</option>
</select>

<input type="hidden" name="oldcountry" value="<?php echo e(strtolower($user->country)); ?>">
</div>
</div>
</div>
</div>
<div class="row">
<legend>Admission Information</legend>
<div class="col-sm-6">
<div class="form-group row">
<label class="col-sm-4 col-form-label">Roll No:</label>
<div class="col-sm-8">
<input type="text" name="rollno" class="form-control" id="roll_no" placeholder="eg:15SW58" required readonly 
 value="<?php echo e(strtoupper($user->rollNo)); ?>" >
</div>
</div>
<div class="form-group  row">
<label class="col-sm-4 col-form-label">Enrollment no:</label>
<div class="col-sm-8 ">
<input type="number" class="form-control" id="Name" placeholder="eg:32152" required value="<?php echo e($user->enrollmentNo); ?>" name="enrollmentNo">
<input type="hidden" name="oldenrollment" 
value="<?php echo e($user->enrollmentNo); ?>">
</div>
</div>

</div>
<div class="col-sm-6">
<div class="form-group row">
<label for="domicile" class="col-sm-3 control-label">Department:</label>
<div class="col-sm-8">
<select class="form-control selectpicker" id="dept" name="dept">
  <option value=" ">Please select Department</option>

<?php $__currentLoopData = $dept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($value->id); ?>">
    
    <?php echo e($value->name); ?>

    

</option>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</select>
<input type="hidden" name="olddept" value="<?php echo e(strtolower($user->deptId)); ?>">
</div>
</div>
<div class="form-group row">
<label class="col-sm-3 control-label">Date Of Admission:</label>
<div class="col-sm-8">
<input class="form-control" type="date" name="doa" required
value="<?php echo e($user->doa); ?>" readonly>


</div>
</div>
</div>
</div>
</div>
<div class="pull-right">
    <input type="submit" name="submit" class="btn btn-success" value="Update" style="border-radius:5px;">
    <button  type="button" class="btn btn-dark text-white" data-dismiss="modal" style="border-radius:5px;">Cancel</button>  
    </div>
  
<br><br>
</form>



<script type="text/javascript">
    
    function imagePreview(path){

//path.type for extendsion  image/jpeg image/png
//path .size for size .... max for blob 65535 bytes
if(path.size < 65535 && (path.type == 'image/jpeg' || path.type == 'image/png')){
    document.getElementById('preview').src = window.URL.createObjectURL(path);
    document.getElementById('imgeerror').style="display:none"; 
}else{

 path=null;
     document.getElementById('preview').src = null;
    document.getElementById('imgeerror').style="display:block";   
}

}
// dynamically change field

document.getElementById('domicile').value = "<?php echo e($user->domicile); ?>".toLowerCase();
 
   document.getElementById('province').value = "<?php echo e($user->province); ?>".toLowerCase();

   document.getElementById('country').value =  "<?php echo e($user->country); ?>".toLowerCase();
  
   document.getElementById('dept').value = "<?php echo e($user->deptId); ?>".toLowerCase();
    
    var gender = "<?php echo e($user->gender); ?>".toLowerCase();
    
    if(gender=='m')
    {document.getElementById('gender-0').setAttribute("checked", "checked");}

    else if(gender=='f')
    {document.getElementById('gender-1').setAttribute("checked", "checked");}
   


</script>
