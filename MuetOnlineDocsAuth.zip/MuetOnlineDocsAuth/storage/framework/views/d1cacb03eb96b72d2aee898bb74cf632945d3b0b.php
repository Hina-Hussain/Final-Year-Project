<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Employees-Validator</title>

<style type="text/css">

.table-title {
color: #fff;
background: #4b5366;        
padding: 16px 25px;
margin: -20px -25px 10px;
border-radius: 3px 3px 0 0;
}

.table-title h2 {
margin: 5px 0 0;
font-size: 24px;
}

.table-wrapper {
background: #fff;
padding: 20px 25px;
margin: 30px auto;
border-radius: 3px;
box-shadow: 0 1px 1px rgba(0,0,0,.05);
}

.table-filter .filter-group {
float: right;
margin-left: 15px;
}
.table-filter input, .table-filter select{
height: 34px;
border-radius: 3px;
border-color: #ddd;
box-shadow: none;
}
.table-filter {
padding: 5px 0 15px;
border-bottom: 1px solid #e9e9e9;
margin-bottom: 5px;
}
.table-filter .btn {
height: 34px;
}
.table-filter input, .table-filter select {
display: inline-block;
margin-left: 5px;
}
.table-filter input, .table-filter select {
width: 200px;
display: inline-block;
}
</style>

</head>

<body>

<?php $__env->startSection('content'); ?>

<div class="content-wrap">
<div class="main">
<div class="container-fluid">

<div class="table-wrapper">
<div class="table-title">
<div class="row">
<div class="col-sm-6">
<h2 class="text-white">Manage <b>Employee Accounts</b></h2>
</div>
<div class="col-sm-6">                      
<div class="pull-right">

<?php if(array_key_exists ( 'add-emp' , $content )): ?>

<button class="btn btn-primary" onclick="createEmp()" id="insbtn">
<i class="fa fa-plus-circle" style="color: white;font-size: 14px;">
<p style="display: inline;" class="text-white">Add New Employee</p>
</i>
</button>

<?php endif; ?>

</div> 
</div>
</div>
</div>

<div class="table-filter">
<div class="row">

<div class="col-sm-3">

<label>Sort &nbsp;</label>

<select class="form-control" style="display: inline-block;width: 120px;"id="orderSelect" onchange="ordSelect()">
<option id="or-roles" value="roles">Roles</option>
<option id="or-staffid" value="staffid">Id</option>
<option id="or-deptId" value="deptId">Dept</option>
</select>

</div>

<div class="col-sm-3">

<?php if(session('accInfo')[0]->role==1): ?>
<span class="filter-icon"><i class="fa fa-filter"></i></span>

<label>Filter &nbsp;</label>

<select class="form-control" style="display: inline-block;width: 120px;"id="filtSelect" onchange="filtSelect()">
<option id="filt-all" value="all">All</option>
<option id="filt-activated" value="activated">Active</option>
<option id="filt-deactivated" value="deactivated">Inactive</option>
</select>

<?php endif; ?>
</div>

<div class="col-sm-6">
<?php if($search): ?>
<form action="/employees/search" class="form-inline pull-right" role="form" id="searchform" method="post">

<?php echo csrf_field(); ?>
<div class="filter-group">

<input type="text" class="form-control " placeholder="Search here" name="search" oninput ="searchlist()" 
id="searchInput" list="searchlist" autocomplete="off" >

<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>

<input type="hidden" class="form-control " name="sjson" id="sjson"> 

<datalist id="searchlist">

</datalist>
</div>
</form>
<?php endif; ?>
</div>

</div>
</div>


<?php if($flash=session('info')): ?>

<div class="alert alert-primary mt-4 ml-3" role="alert" style="color:white;">

<?php echo e($flash); ?>   

</div>

<?php endif; ?>

<?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if($flash=session('success')): ?>

<div class="alert alert-success mt-4 ml-3" role="alert" style="color:white;">

<?php echo e($flash); ?>   

</div>

<?php endif; ?>

<?php if($flash=session('danger')): ?>

<div class="alert alert-danger mt-4 ml-3" role="alert" style="color:white;">

<?php echo e($flash); ?>   

</div>

<?php endif; ?>


<!-- List View for Emp-->
<section id="posts">
<div>
<div class="row">

<div class="col">
<div>
<table class="table table-striped bg-fadded">
<thead>
<tr>
<th>Id</th>
<th>Name</th>
<th>Email</th>
<th>Role</th>
<th>Dept Name</th>
<?php if(session('accInfo')[0]->role==1): ?>

<th>

</th>

<?php endif; ?>
<th>Action</th>
</tr>
</thead>
<tbody id="emps">

<?php for($r = 0; $r < count($res); $r++ ): ?>

<tr>

<td scope="row">
<?php echo e($res[$r]->id); ?></td>

<td><?php echo e(ucwords($res[$r]->name)); ?></td>

<td><?php echo e($res[$r]->email); ?></td>

<td><?php echo e(ucwords($res[$r]->role)); ?></td>

<td><?php echo e(ucwords($res[$r]->dept)); ?></td>

<?php if(session('accInfo')[0]->role==1): ?>

<?php if($res[$r]->status==1): ?>

<td><span class="status"></span><i class="fa fa-circle" style="color: green;"> 
<p style="color:#333;display: inline;">Active
</p></i></td>

<?php else: ?>

<td><span class="status"></span><i class="fa fa-circle" style="color: orange"> 
<p style="color:#333;display: inline;">Inactive
</p></i></td>

<?php endif; ?>


<?php endif; ?>


<td>


<?php if(array_key_exists ( 'view-emp' , $content )): ?>

<button class="btn btn-info" id="viewbtn<?php echo e($res[$r]->id); ?>" onclick=
'viewEmp("<?php echo e($res[$r]->id); ?>",<?php echo e($res[$r]->status); ?>)'>

<i class="fa fa-info-circle"></i>

</button>

<?php endif; ?>

<?php if(array_key_exists ( 'edit-emp' , $content ) && $res[$r]->status!=0): ?>

<button class="btn btn-success text-white" id="editbtn<?php echo e($res[$r]->id); ?>" onclick=
'editEmp("<?php echo e($res[$r]->id); ?>")'>

<i class="fa fa-edit"></i>

</button>

<?php endif; ?>


<?php if(session('accInfo')[0]->role==1 && $res[$r]->status==0): ?>

<button class="btn text-white" style="background-color: orange" id="resbtn<?php echo e($res[$r]->id); ?>" title="restore account" onclick=
'restoreEmp("<?php echo e($res[$r]->id); ?>")'>

<i class="fa fa-repeat"></i>

</button>

<?php endif; ?>

<?php if(array_key_exists ( 'del-emp' , $content )): ?>

<button class="btn btn-danger" id="delbtn<?php echo e($res[$r]->id); ?>" onclick=
'deleteEmp("<?php echo e($res[$r]->id); ?>",<?php echo e($res[$r]->status); ?>)'>

<i class="fa fa-trash"></i>

</button>


<?php endif; ?>

</td>

</tr>

<?php endfor; ?>
</tbody>
</table>

<?php if($search): ?>

<?php echo e($res->appends(request()->query())->links()); ?>


<?php endif; ?>

</div>
</div>
</div>
</div>

</section>

</div>
</div>
</div>
</div>

<div id="modals"></div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">

loc= new URLSearchParams(window.location.search);
$('#or-'+loc.get('q')).attr('selected',true);

function ordSelect(){

window.location = "http://127.0.0.1:8000/dashboard/employees?q="+$('#orderSelect').val();

}

loc= new URLSearchParams(window.location.search);
$('#filt-'+loc.get('q')).attr('selected',true);

function filtSelect(){

	window.location = "http://127.0.0.1:8000/dashboard/employees?q="+$('#filtSelect').val();

}
</script>

<script type="text/javascript">


//for displaying active on sidebar components

document.getElementById('dashboard').classList.remove('active');

document.getElementById('staff').classList.add('active');

document.getElementById('students').classList.remove('active');

document.getElementById('account_rights').classList.remove('active');

document.getElementById('verstudents').classList.remove('active');

document.getElementById('profile').classList.remove('active');

document.getElementById('log').classList.remove('active');

document.getElementById('setting').classList.remove('active');

//end 


function deleteEmp(id,status){


$('#delbtn'+id).attr('disabled',true);

$.get('<?php echo e(URL::to("/employees/delete")); ?>'+"?q="+id+"&status="+status,function(data){

$('#modals').empty().append(data);
$('#delemp').modal('toggle');
$('#delbtn'+id).attr('disabled',false);
});

}

function restoreEmp(id){


$('#resbtn'+id).attr('disabled',true);

$.get('<?php echo e(URL::to("/employees/restore")); ?>'+"?q="+id,function(data){

$('#modals').empty().append(data);
$('#resemp').modal('toggle');
$('#resbtn'+id).attr('disabled',false);

});

}

$('#modals').on('click','#submitdelete',function(){
$('#submitdelete').attr('disabled','disabled'); 
console.log('deleting');
document.getElementById("deleteform").submit();
});

function viewEmp(id,status){

$('#viewbtn'+id).attr('disabled',true);
$.get('<?php echo e(URL::to("/employees/view")); ?>'+"?q="+id+"&status="+status,function(data){

$('#modals').empty().append(data);
$('#viewemp').modal('toggle');
$('#viewbtn'+id).attr('disabled',false);
});

}

function editEmp(id){

$('#editbtn'+id).attr('disabled',true);
$.get('<?php echo e(URL::to("/employees/edit")); ?>'+"?q="+id,function(data){
$('#modals').empty().append(data);
$('#editempM').modal({backdrop: 'static', keyboard: false});
$('#editbtn'+id).attr('disabled',false);
});

}

function createEmp(){
$('#insbtn').attr('disabled',true);
$.get('<?php echo e(URL::to("/employee/create")); ?>', function(data){
$('#modals').empty().append(data);
$('#addemp').modal({backdrop: 'static', keyboard: false});
$('#insbtn').attr('disabled',false);
});

}


// edit modal role select behaviour
$('#modals').on('change','#roleSelect',function(){

divDoc1=document.getElementById('form');
divDoc2=document.getElementById('form1'); 
select=document.getElementById('roleSelect');
var roles=$(this).data('roles');
var prevs=$(this).data('prevs');

if(select.options[select.selectedIndex].text=='Custom role'){

divDoc1.style.display='flex';
divDoc2.style.display='flex';

$('#prevss').empty();

for(i=0;i<prevs.length;i++){

$('#prevss').append('<div class="row"><div class="form-group row ml-5 pl-5"><input class="form-check-input" type="checkbox" value=1 id= p'+prevs[i].id+' onchange="clicked(this.id,0)" name='+prevs[i].id+'><label class="form-check-label lead" for="label" style="font-size:1em;" id=pd'+prevs[i].id+'>'+prevs[i].prevDesc+'</label></div></div>');

}

}else{

divDoc1.style.display='none';
divDoc2.style.display='none';

$('#prevss').empty();

for(i=0;i<roles.length;i++){

if(select.options[select.selectedIndex].value== roles[i].id){
$('#prevss').append('<div class="row"><div class="form-group row ml-5 pl-5"><input class="form-check-input" type="checkbox" disabled value=1 id= p'+roles[i].prevId+' onchange="clicked(this.id,0)" name='+roles[i].prevId+'><label class="form-check-label lead" for="label" style="font-size:1em;" id=pd'+roles[i].prevId+'>'+roles[i].prevDesc+'</label></div></div>');    
}

}

for(i=0;i<roles.length;i++){

if (roles[i].id==select.options[select.selectedIndex].value) {

$('#p'+roles[i].prevId).attr('checked','checked')

}
}

}

});


$('#modals').on('change','#croleSelect',function(){
divDoc1=document.getElementById('cform');
divDoc2=document.getElementById('cform1'); 
select=document.getElementById('croleSelect');
var roles=$(this).data('roles');
var prevs=$(this).data('prevs');

if(select.options[select.selectedIndex].text=='Custom role'){

divDoc1.style.display='flex';
divDoc2.style.display='flex';

$('#cprevss').empty();

for(i=0;i<prevs.length;i++){

$('#cprevss').append('<div class="row"><div class="form-group row ml-5 pl-5"><input class="form-check-input" type="checkbox" value=1 id= cp'+prevs[i].id+' onchange="clicked(this.id,1)" name='+prevs[i].id+'><label class="form-check-label lead" for="label" style="font-size:1em;" id=cpd'+prevs[i].id+'>'+prevs[i].prevDesc+'</label></div></div>');

}

}else{

divDoc1.style.display='none';
divDoc2.style.display='none';

$('#cprevss').empty();


for(i=0;i<prevs.length;i++){

$('#cprevss').append('<div class="row"><div class="form-group row ml-5 pl-5"><input class="form-check-input" type="checkbox" disabled value=1 id= cp'+prevs[i].id+' name='+prevs[i].id+'><label class="form-check-label lead" for="label" style="font-size:1em;" id=cpd'+prevs[i].id+'>'+prevs[i].prevDesc+'</label></div></div>');

}

for(i=0;i<roles.length;i++){

if (roles[i].id==select.options[select.selectedIndex].value) {

$('#cp'+roles[i].prevId).attr('checked','checked')

}
}

}

});

function clicked(id,type){



if(type==0){

if(document.getElementById(id).checked){
document.getElementById('pd'+id.substring(1, id.length)).style="font-weight:bold;color:black;font-size:1em";
}else{
document.getElementById('pd'+id.substring(1, id.length)).style="font-weight:normal;font-size:1em";
}

}else if(type==1){
if(document.getElementById(id).checked){
document.getElementById('cpd'+id.substring(2, id.length)).style="font-weight:bold;color:black;font-size:1em";
}else{
document.getElementById('cpd'+id.substring(2, id.length)).style="font-weight:normal;font-size:1em";
}
}

}

$('#modals').on('input','#email',function(){

$('#passrules').hide();

})

$('#modals').on('input','#password',function(){

$('#passrules').show();

})

$('#modals').on('input','#password_confirmation',function(){

$('#passrules').show();

})

$('#modals').on('input','#role_name',function(){

$('#passrules').hide();

})

$('#modals').on('input','#role_desc',function(){

$('#passrules').hide();

})


//edit modal checkdata behaviour

$('#modals').on('click','#submitFormChanges',function(){

$('#submitFormChanges').attr('disabled','disabled');
error=document.getElementById('error');
error.style.display='none';
$prob=false;
select=document.getElementById('roleSelect');
prevs=$(this).data('prevs');


// password

if(document.getElementById('password').value!="" && document.getElementById('password_confirmation').value!=""){

if(document.getElementById('password').value.length >= 6){

var countNum=0;
var countUppercase=0;
var countLowercase=0;

var i=0;
var character='';

while (i <= document.getElementById('password').value.length){

character = document.getElementById('password').value.charAt(i);

if (!isNaN(character * 1)){

countNum++;

}else{

if (character == character.toUpperCase()) {

countUppercase++;

}

if (character == character.toLowerCase()){

countLowercase++;

}

}

i++;

}

if(countNum >= 1 && countUppercase >= 1 && countLowercase >= 1){

if(document.getElementById('password').value!=document.getElementById('password_confirmation').value){

$prob=true;

error.style+="display:block;color:white;";
error.innerHTML="Password do not match!";

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);

}

}else{

$prob=true;

error.style+="display:block;color:white;";
error.innerHTML="Your Password should have atleast one character one uppercase and one lowercase letter!";

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);

}

}else{

$prob=true;

error.style+="display:block;color:white;";
error.innerHTML="Password should be atleast 6 characters long!";

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);
}

}else if (document.getElementById('password').value=="" && document.getElementById('password_confirmation').value==""){

}


// image

if(document.getElementById('imgeerror')!=null && document.getElementById('imgeerror').style.display!='none'){

$prob=true;

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);

}

//email

if(document.getElementById('prev_email').value!=document.getElementById('email').value){

id=document.getElementById('empstaffid').value;
email=document.getElementById('email').value;

if(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)){

$.get('<?php echo e(URL::to("/employee/checkEmail")); ?>'+"?q="+email, function(data){

if(data==true){
//email exists 
console.log("checkemail "+data);
$prob=true;

document.getElementById('error').style+="display:block;color:white;";

document.getElementById('error').innerHTML="Email not available kindly enter another email!";

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);

}else{
//email doesnt exists
checkRoleName(prevs)
}
});

}else{
$prob=true;
document.getElementById('error').style+="display:block;color:white;";

document.getElementById('error').innerHTML="Enter a valid email!";

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);
}
}else{

checkRoleName(prevs);
}


});

function checkRoleName(){

if(select.options[select.selectedIndex].text=='Custom role'){

if($('#role_name').val().trim()==""){

error.style+="display:block;color:white;";
error.innerHTML="Enter the role name!"; 

$prob=true;

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);

}else{

// checking role
$.get('<?php echo e(URL::to("/employees/roles")); ?>'+"?q="+$('#role_name').val().trim(), function(data){

if(data==true){
// role exists

error.style+="display:block;color:white;";
error.innerHTML="Role name not available!"; 

$prob=true;

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);

}else{

//role doesn't exists

if($('#role_desc').val().trim()!=""){

count=0;

for(i=0;i<prevs.length;i++){

if(document.getElementById('p'+prevs[i].id).checked){

count=0;
break;

}else{

count=1;

}

}

if(count==1){
document.getElementById('error').style+="display:block;color:white;";

document.getElementById('error').innerHTML="Select privileges for this role!";

$prob=true;

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);

}else{

if($prob){

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);

}else{

count=0;
document.getElementById("editemp").submit();

}

}

}else{

error.style+="display:block;color:white;";
error.innerHTML="Enter the role description!"; 

$prob=true;

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);
}
}

});

}

}else{

if($prob){

$('#submitFormChanges').attr('disabled',false);
$('#editempM').scrollTop(0);

}else{

document.getElementById("editemp").submit();

}
}
}


$('#modals').on('input','#cempid',function(){

console.log('hello');

$('#passrules').hide();

})

$('#modals').on('input','#cemail',function(){

console.log('hello');

$('#passrules').hide();

})

$('#modals').on('input','#cpassword',function(){

console.log('pass');

$('#passrules').show();

})

$('#modals').on('input','#cpassword_confirmation',function(){

console.log('pass');

$('#passrules').show();

})

$('#modals').on('input','#crole_name',function(){

console.log('pass');

$('#passrules').hide();

})

$('#modals').on('input','#crole_desc',function(){

console.log('pass');

$('#passrules').hide();

})


// create modal check data behaviour

$('#modals').on('click','#csubmitFormChanges',function(){

$('#csubmitFormChanges').attr('disabled','disabled');
error=document.getElementById('cerror');
error.style.display='none';
$prob=false;
select=document.getElementById('croleSelect');
prevs=$(this).data('prevs');

//password check
password=document.getElementById('cpassword');
pass_confirm=document.getElementById('cpassword_confirmation')

if(password.value!=""){

if(password.value.length >= 6){

var countNum=0;
var countUppercase=0;
var countLowercase=0;

var i=0;
var character='';

while (i <= password.value.length){

character = password.value.charAt(i);

if (!isNaN(character * 1)){

countNum++;

}else{

if (character == character.toUpperCase()) {

countUppercase++;

}

if (character == character.toLowerCase()){

countLowercase++;

}

}

i++;

}

if(countNum >= 1 && countUppercase >= 1 && countLowercase >= 1){

if(password.value!=pass_confirm.value){

$prob=true;

error.style+="display:block;color:white;";
error.innerHTML="Password do not match!";

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}

}else{

$prob=true;

error.style+="display:block;color:white;";
error.innerHTML="Your Password should have atleast one character one uppercase and one lowercase letter!";

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}

}else{

$prob=true;

error.style+="display:block;color:white;";
error.innerHTML="Password should be atleast 6 characters long!";

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}

}else{

$prob=true;

error.style+="display:block;color:white;";
error.innerHTML="Enter employee password!";

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}

//image error check

if(document.getElementById('cimgeerror')!=null && document.getElementById('cimgeerror').style.display!='none'){

$prob=true;

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}

//checking if id exists
id=document.getElementById('cempid');
if (id.value!=null && id.value!=""){

$.get('<?php echo e(URL::to("/employee/checkId")); ?>'+"?q="+id.value,function(data){

if(data==true){

$('#csubmitFormChanges').attr('disabled',false);

$prob=true;

error.style+="display:block;color:white;";
error.innerHTML="Id not available kindly enter another id!";
$('#addemp').scrollTop(0);   

}else{

//id available for use 

//now check here email
email=document.getElementById('cemail');

if(email.value!="" && 
/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email.value)){


$.get('<?php echo e(URL::to("/employee/checkEmail")); ?>?q='+email.value, function(data){

if(data==true){

$prob=true;

error.style+="display:block;color:white;";

error.innerHTML="Email not available kindly enter another email!";  

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0); 

}else{
ccheckRoleName(prevs);
}

});

}else{

$('#csubmitFormChanges').attr('disabled',false);

$prob=true;

error.style+="display:block;color:white;";
error.innerHTML="Enter employee email!";
$('#addemp').scrollTop(0);

}                          
}
});
}else{
$prob=true

error.style+="display:block;color:white;";
error.innerHTML="Enter valid employee Id!";

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}    
});

function ccheckRoleName(prevs){

if(select.options[select.selectedIndex].text=='Custom role'){

if($('#crole_name').val().trim()==""){

error.style+="display:block;color:white;";
error.innerHTML="Enter the role name!"; 

$prob=true;

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}else{

// checking role
$.get('<?php echo e(URL::to("/employees/roles")); ?>'+"?q="+$('#crole_name').val().trim(), function(data){

if(data==true){
// role exists

error.style+="display:block;color:white;";
error.innerHTML="Role name not available!"; 

$prob=true;

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}else{

//role doesn't exists

if($('#crole_desc').val().trim()!=""){
count=0;

for(i=0;i<prevs.length;i++){

if(document.getElementById('cp'+prevs[i].id).checked){
count=0;
break;
}else{

count=1;
}


}
console.log('countend: '+count);

if(count==1){
error.style+="display:block;color:white;";

error.innerHTML="Select privileges for this role!";

$prob=true;

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}else{
if($prob){


console.log('countloop: '+count);

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}else{



console.log('countloop: '+count);

document.getElementById("createemp").submit();

}
}

}else{

error.style+="display:block;color:white;";
error.innerHTML="Enter the role description!"; 

$prob=true;

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);
}
}

});

}

}else{

if($prob){

$('#csubmitFormChanges').attr('disabled',false);
$('#addemp').scrollTop(0);

}else{

document.getElementById("createemp").submit();

}
}
}


function searchlist(){


value=$('#searchInput').val().trim();
console.log(value);
if(value.length>1) {

$.get('<?php echo e(URL::to("/employees/search")); ?>?q='+value, function(data){

console.log(data);

document.getElementById('searchlist').innerHTML=""
for( var j=0; j < data.length; j++ ){

var resformat="Id: "+data[j].id+" Name: "+data  [j].name+" Email: "+data[j].email+" Dept: "+  data[j].dept +" Role: "+  data[j].role;


var option = document.createElement('option');

// Set the value using the item in the JSON array.
option.value = resformat;

var jsonData='[{' +
'"id":'+data[j].id+
',"name":"'+data  [j].name+
' ","email":"'+data  [j].email+
' ", "dept":"'+data  [j].dept+
' ", "role":"'+data  [j].role+'", "status":"'+data  [j].status+'"}]';


option.title=jsonData;

document.getElementById("searchlist").appendChild(option);
}

});
}    
}

$("#searchInput").bind('input', function () {
var flag=checkExists( $('#searchInput').val() );
if( flag){

document.getElementById('sjson').value=flag;

window.location.assign("/employees/search/result?val="+flag);
}
});

function checkExists(inputValue) {

var x = document.getElementById("searchlist");
var i;
var flag;
var label;
for (i = 0; i < x.options.length; i++) {
if(inputValue == x.options[i].value){
flag = true;
label=x.options[i].title;
}
}

if(flag){
return label;
}
return flag;
}


function imagePreview(path,type){

//type=1 creation type=0 edit
//path.type for extendsion  image/jpeg image/png
//path .size for size .... max for blob 65535 bytes

if(path!=undefined){

if(type==0){

if(path.size < 65535 && (path.type == 'image/jpeg' || path.type == 'image/png')){

document.getElementById('user_pic_edit').src = window.URL.createObjectURL(path);

document.getElementById('imgeerror').style="display:none"; 
}else{

path=null;
document.getElementById('user_pic_edit').src = null;
document.getElementById('imgeerror').style="display:block";   
}          
}else{
if(path.size < 65535 && (path.type == 'image/jpeg' || path.type == 'image/png')){

document.getElementById('cuser_pic_edit').src = window.URL.createObjectURL(path);
document.getElementById('cimgeerror').style="display:none"; 
}else{

path=null;
document.getElementById('cuser_pic_edit').src = null;
document.getElementById('cimgeerror').style="display:block";   
}
}
}else{
if (type==0) {

document.getElementById('imgeerror').style.display="none"; 
}else{

document.getElementById('cimgeerror').style.display="none"; 
}
}

}


</script>

<?php $__env->stopSection(); ?>

</body>

</html>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>