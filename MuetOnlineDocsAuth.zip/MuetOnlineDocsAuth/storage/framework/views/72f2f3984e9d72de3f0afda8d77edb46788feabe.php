<div class="container-fluid">

<div class="container" style="background-color: white; font-family:sans-serif; color:black;">
<div class="row">
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">

</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
S.No <b> BE</b> 012345

</div>
</div>
<div class="row" style="margin-left:42%">
<div>
<img src="/img/logomuet.png" class="img-responsive" style="width: 80%; height:100%;" />
</div>
<div style="margin-left:10%">
<div>
<div style="margin-left: 70px;"><?php echo e($degreeInfo->algD); ?></div>
</div>
<div>
<div id="qrcode" style="margin-left: 80px;"></div>
</div>
</div>

</div>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;font-size: 170%;">
<p style="font-family: Old English Text MT; color:black">Mehran University<br>Of<br>Engineering & Technology</p>
</div>
</div>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
<p style="color:black"><br><br>It is here by certified that Mr/Ms...<?php echo e($pinfo->fullname); ?>....................................... S/o D/o ...<?php echo e($pinfo->fatherName); ?>.............................................<br> <br> Surname ...<?php echo e($pinfo->surname); ?>.............................................after
having certified that all the conditions prescribed by the<br> <br>university has beenduly admitted to the degree of <b>Bachelor Of  Engineering</b> in the discipline of
<br><br> ........<?php echo e($pinfo->name); ?>............................................................................................................ engineering .</p>
<p style="color:black"> He/She has secured ...<?php echo e($degreeInfo->cgpa); ?> C.G.P.A............................................... division in the final examination held in

<br>
<br>...<?php echo e($name); ?>..<?php echo e($year); ?>.......................................................................................................................................................
</p><br><br><br>


</div>
</div>
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
<p style="margin-left: 45%;color:black">...............................</p>
<p style="margin-left: 45%; color:black">Controller of
<br> examination</p>
<br><br>
<p style="margin-left: 15%; color:black">Jamshoro,Sindh-Pakistan.
<br> Dated the.......................</p>
</div>
<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
<p style="margin-left: 45%; color:black">.........................</p>
<p style="margin-left: 45%; color:black">Register</p>
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
<p style="margin-left: 45%; color:black">.............................</p>
<p style="margin-left: 45%; color:black" color:black>Vice Chancellor</p>
<img src="/img/logo12.png" style="margin-left: 45%;" />
</div>
</div>

</div>
</div>