<?php $__env->startSection('content'); ?>

<div class="content-wrap">
          <div class="main">
              <div class="container-fluid">
      
 <main role="main">
      <div class="d-flex align-items-center p-3 my-3 text-white-50 bg-purple rounded box-shadow web_back_color">
        <img class="mr-3" src="/img/logo.png" alt="" width="48" height="48">
        <div class="lh-100">
          <h6 class="mb-0 text-white lh-100" style="letter-spacing: 3px;">Notifications</h6>
        </div>
      </div>

      <div class="my-3 p-3 bg-white rounded box-shadow">
        <h5 class="border-bottom border-gray pb-2 mb-0" style="color:black;">My Notifications</h5>
        
        <?php $__empty_1 = true; $__currentLoopData = $result['myNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        
        <div class="media text-muted pt-3">
          <img src="<?php echo e(asset('storage/uploads/staff/'.$notification->pic)); ?>" alt="" class="mr-2 rounded" style="width:48px;height: 48px;">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:black; ">Updated  your <?php echo e($notification->colName); ?></strong>
            <?php echo e($notification->name); ?> - <?php echo e($notification->staffid); ?> updated your <?php echo e($notification->colName); ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <br>

            <p class="text-center media-body pb-3 mb-0 lh-125 border-bottom border-gray">
                No notifications in this section...
            </p>
        
        <?php endif; ?>

        <br>

        <?php if(session('accInfo')[0]->role==1): ?>

          <h5 class="border-bottom border-gray pb-2 mb-0" style="color:black">General Notifications</h5>

        <h6 class="border-bottom border-gray pb-2 mb-0 ml-1 mt-3" style="color:black">
          Employee related notifications
        </h6>

        <!-- creations -->
        
        <?php $__currentLoopData = $result['crNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">
          
          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:black; ">Created account with id - <?php echo e($notification->id); ?></strong>
            <?php echo e($notification->staffid); ?> created an employee account with id - <?php echo e($notification->id); ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- updations -->

        <?php $__currentLoopData = $result['upNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">
          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:black; ">Updation were made to account with id - <?php echo e($notification->id); ?></strong>
            <?php echo e($notification->staffid); ?> updated the <?php echo e($notification->colName); ?> of the account with id - <?php echo e($notification->id); ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- Activated -->

        <?php $__currentLoopData = $result['activeEmpNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:blue; ">Activated account with id - <?php echo e($notification->id); ?></strong>
            <?php echo e($notification->staffid); ?> activated the employee account with id - <?php echo e($notification->id); ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- deletions -->

        <?php $__currentLoopData = $result['delNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:orange; ">Deactivated account with id - <?php echo e($notification->id); ?></strong>
            <?php echo e($notification->staffid); ?> deactivated the employee account with id - <?php echo e($notification->id); ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


         <!-- permanent deletions -->

        <?php $__currentLoopData = $result['perDelNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:red; ">Deleted account with id - <?php echo e($notification->id); ?></strong>
            <?php echo e($notification->staffid); ?> permanently deleted the employee account with id - <?php echo e($notification->id); ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <h6 class="border-bottom border-gray mt-3 pb-2 mb-0 ml-1" style="color:black">
          Student related notifications
        </h6>

        <?php $__currentLoopData = $result['VerStd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:green; ">Verified student with Rollno - <?php echo e($notification->id); ?></strong>
            Employee - Id: <?php echo e($notification->staffid); ?> verified the student with rollno - <?php echo e($notification->id); ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $result['UpStdInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:black; "> Updated student - rollno:  <?php echo e($notification->id); ?> <?php echo e($notification->colName); ?> </strong>

            <?php if($notification->comment!=null): ?>

              Employee account - <?php echo e($notification->staffid); ?>

               updated 

              

               <?php echo e($notification->colName == 'markObtInTh' ? 'Theory marks' : ($notification->colName == 'markObtInPr' ? 'Practical marks' : '$notification->colName')); ?>



               in

               <?php echo e($result['courseName'][$notification->comment]); ?> 

               of student with rollno

               <?php echo e($notification->id); ?>


           <?php else: ?>

              Employee account - <?php echo e($notification->staffid); ?>

               updated <?php echo e($notification->colName); ?> 

               of student with rollno

               <?php echo e($notification->id); ?>


           <?php endif; ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $result['RepStd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">

          <div class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px;color:orange">
            <strong class="d-block text-gray-dark">Reported student with Rollno - <?php echo e($notification->id); ?></strong>
            Employee - Id: <?php echo e($notification->staffid); ?> Reported the student with rollno - <?php echo e($notification->id); ?>

            <br>

          <?php

          $jsonComment=json_decode($notification->comment)->problem;

          if($jsonComment[0]!=null || $jsonComment[1] !=null || $jsonComment[2] != null || $jsonComment[3]!=null ){

        ?>

        <br>

        <span style="color:gray;font-size: 12px;">
          Reasons mentioned for reporting are:
        </span>
        <?php

        }

        ?>

        <?php if($jsonComment[0]!=null ): ?>

           
            <p class="ml-1" style="color:black">   &bull; Mistakes in ' <?php echo e($jsonComment[0]); ?> ' information
           </p>
        
        <?php endif; ?>

        

        <?php if($jsonComment[1]!=null ): ?>

           <p class="ml-1" style="color:black">
              &bull; Mistakes in <?php echo e($jsonComment[1]); ?> information
           </p>
        
        <?php endif; ?>

        

         <?php if($jsonComment[2]!=null ): ?>

           <p class="ml-1" style="color:black">
              &bull; Mistakes in ' <?php echo e($jsonComment[2]); ?> ' information
           </p>
        
        <?php endif; ?>

        

         <?php if($jsonComment[3]!=null ): ?>

            <p class="ml-1" style="color:black">
              &bull; Mistakes in different sections of information
            </p>

        <?php endif; ?>

          <?php

              $jsonComment=json_decode($notification->comment)->comment;

          ?>
          
          <?php if($jsonComment!=null): ?>

          <p class="mt-3" style="color:black;">          

              Employee message for reporting this student:<span style="color:tomato;font-size: 12px">" <?php echo e($jsonComment); ?> "</span>

          </p>
          <?php endif; ?>


            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </div>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $result['ResStd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:teal; ">Restored student with Rollno - <?php echo e($notification->id); ?></strong>
            Employee - Id: <?php echo e($notification->staffid); ?> restored the student with rollno - <?php echo e($notification->id); ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <?php $__currentLoopData = $result['DelStd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:orange; ">Deleted student with Rollno - <?php echo e($notification->id); ?></strong>
            Employee - Id: <?php echo e($notification->staffid); ?> deleted the student with rollno - <?php echo e($notification->id); ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $result['PerDelStd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="media text-muted pt-3">

          <p class="media-body pb-3 mb-0 lh-125 border-bottom border-gray" style="font-size: 12px">
            <strong class="d-block text-gray-dark" style=" color:red; ">Permanently Deleted student with Rollno - <?php echo e($notification->id); ?></strong>
            Employee - Id: <?php echo e($notification->staffid); ?> permanently deleted the student with rollno - <?php echo e($notification->id); ?>

            <small class="pull-right"> 
              <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>

            </small> 
          </p>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
        </div>

    </main>
</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>