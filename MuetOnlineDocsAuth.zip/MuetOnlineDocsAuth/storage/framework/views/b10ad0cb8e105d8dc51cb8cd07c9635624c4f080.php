<!-- header -->

<div class="header web_back_color" style="background-color: #24273c;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="float-left">

                        <div class="hamburger sidebar-toggle text-white">
                            <span class="line"></span>
                            <span class="line"></span>
                            <span class="line"></span>
                        </div>

                    </div>

                     <?php echo $__env->yieldContent('tabs'); ?>
                    <!--add button hoverover appearence settings 5/5/18 -->
                    <div class="float-right mt-0">

                        <ul class="row">
                             
                            <?php echo $__env->yieldContent('buttons'); ?>

                            <li class="header-icon dib">

                                <?php if(session('accInfo')[0]->role!=1): ?>

                                    <?php if(count($result['myNotif'])!=0): ?>

                                        <i class="ti-bell" style="color:red;" onclick="checkedNotif()" id="notify"></i>

                                    <?php else: ?>

                                        <i class="ti-bell" style="color:white;" onclick="checkedNotif()" id="notify"></i>

                                    <?php endif; ?>

                                <?php else: ?>

                                    <?php if(count($result['myNotif'])!=0 || count($result['CrEmpNotif'])!=0 || count($result['UpEmpNotif'])!=0 || count($result['DelEmpNotif'])!=0 || 
                                    count($result['UpStdInfo'])!=0 || 
                                    count($result['VerStd'])!=0 ||
                                    count($result['RepStd'])!=0 || 
                                    count($result['DelStd'])!=0): ?> 
                                    
                                        <i class="ti-bell" style="color:red;" onclick="checkedNotif()" id="notify"></i>
                                    
                                    <?php else: ?>

                                        <i class="ti-bell" style="color:white;" onclick="checkedNotif()" id="notify"></i>

                                    <?php endif; ?>


                                <?php endif; ?>

                                
                                <div class="drop-down  dropdown-menuForNotif">
                                    <div class="dropdown-content-heading">
                                        <span class="text-left">


                                            <!-- checking if is admin or someone else -->

                                        <?php if(session('accInfo')[0]->role!=1): ?>

                                            <?php if(count($result['myNotif'])==0): ?>

                                                No
                                            
                                            <?php endif; ?>

                                                Recent Notifications
                                        
                                        <?php else: ?>

                                            <?php if(

                                            count($result['myNotif'])==0 && count($result['CrEmpNotif'])==0 && count($result['UpEmpNotif'])==0 && count($result['DelEmpNotif'])==0 && 
                                            count($result['UpStdInfo'])==0 && 
                                            count($result['VerStd'])!=0 &&
                                            count($result['RepStd'])!=0 && 
                                            count($result['DelStd'])!=0

                                            ): ?>

                                                No

                                            <?php endif; ?>            

                                                Recent Notifications

                                        <?php endif; ?> 

                                        

                                    </span>
                                    </div>
                                    <div class="dropdown-content-body"> 
                                        <ul>

                                            <legend style="font-size: 12px" class="ml-2">My Notifications</legend>

                                            <?php $__currentLoopData = $result['myNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                             <li style="display: flex;">
                                                <a >
                                                    <img  

                                                    class="rounded-circle" 

                                                    style="width:40px; height: 30px" 

                                                    alt="user pic"

                                                    src=  "<?php echo e(asset('storage/uploads/staff/'.$notification->pic)); ?>" />
                                                    
                                                    &nbsp;&nbsp;&nbsp;


                                                    <div class="notification-content" style="display: inline;">
                                                        
                                                        <div class="notification-heading" style="display: inline;color:gray;">
                                                            
                                                            <?php echo e($notification->name); ?>

                                                        </div>
                                                        <div class="notification-text" style="display: inline;color:gray;">updated your <?php echo e($notification->colName); ?></div>
                                                    </div>
                                                    <br>
                                                    <p class="pull-right">
                                                    <small class="notification-timestamp pull-right">

                                                            <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                    </small>
                                                    </p>
                                                </a>
                                            </li>
   

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php if(session('accInfo')[0]->role==1): ?>


                                                <legend style="font-size: 12px" class="ml-2">General Notifications</legend>

                                                <legend style="font-size: 12px;color:black;" class="ml-4">Employee related notifications</legend>

                                                <?php $__currentLoopData = $result['CrEmpNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a >

                                                        <div class="notification-content" style="display: inline;">
                                                            <div class="notification-text" style="display: inline;color:gray">
                                                                
                                                                 Employee account - 
                                                                <?php echo e($notification->staffid); ?>

                                                                 created the employee account with id <?php echo e($notification->id); ?>


                                                            </div>
                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                <?php $__currentLoopData = $result['UpEmpNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a >
                                                        
                                                        <div class="notification-content" style="display: inline;color:black;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:gray;">

                                                                 Employee account - <?php echo e($notification->staffid); ?>

                                                                 updated the employee's  '<?php echo e($notification->id); ?>'

                                                                 <?php echo e($notification->colName); ?> 
                                                                
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <!-- activated -->
                                                <?php $__currentLoopData = $result['ActiveEmpNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a >
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:blue">
                                                                
                                                                Employee account -  <?php echo e($notification->id); ?>

                                                                 has been activated by the employee account  with id <?php echo e($notification->staffid); ?>



                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php $__currentLoopData = $result['DelEmpNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a >
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:orange">
                                                                
                                                                Employee account -  <?php echo e($notification->id); ?>

                                                                 has been deactived by the employee account  with id <?php echo e($notification->staffid); ?>



                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                <?php $__currentLoopData = $result['PerDelEmpNotif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a >
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:red">
                                                                
                                                                Employee account -  <?php echo e($notification->id); ?>

                                                                 has been permanently deleted by the employee account  with id <?php echo e($notification->staffid); ?>



                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                <legend style="font-size: 12px;color:black;" class="ml-4">Students related notifications</legend>

                                                <?php $__currentLoopData = $result['VerStd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a >
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:green;">

                                                                 Student - rollno: <?php echo e($notification->id); ?> has been verified by the employee - id:<?php echo e($notification->staffid); ?>


                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php $__currentLoopData = $result['UpStdInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a>
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:gray;">
                                                                
                                                                <?php if($notification->comment!=null): ?>

                                                                    Employee account - <?php echo e($notification->staffid); ?>

                                                                     updated 

                                                                      <?php echo e($notification->colName == 'markObtInTh' ? 'Theory marks' : ($notification->colName == 'markObtInPr' ? 'Practical marks' : '$notification->colName')); ?> 

                                                                     in

                                                                     <?php echo e($result['courseName'][$notification->comment]); ?> 

                                                                     of student with rollno

                                                                     <?php echo e($notification->id); ?>


                                                                 <?php else: ?>

                                                                    Employee account - <?php echo e($notification->staffid); ?>

                                                                     updated <?php echo e($notification->colName); ?> 

                                                                     of student with rollno

                                                                     <?php echo e($notification->id); ?>


                                                                 <?php endif; ?>


                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php $__currentLoopData = $result['RepStd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a>
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:orange;">

                                                                 Student - rollno: <?php echo e($notification->id); ?> has been Reported by the employee - id:<?php echo e($notification->staffid); ?>


                                                                 <?php

                                                                    $jsonComment=json_decode($notification->comment)->problem;

                                                                    if($jsonComment[0]!=null || $jsonComment[1] !=null || $jsonComment[2] != null || $jsonComment[3]!=null ){

                                                                ?>

                                                                

                                                               <span style="color:gray"> Reasons mentioned for reporting are:
                                                                </span>
                                                                <?php

                                                                }

                                                                ?>

                                                                

                                                                    <?php if($jsonComment[0]!=null ): ?>

                                                                       
                                                                        <p class="ml-1" style="color:black">   &bull; Mistakes in ' <?php echo e($jsonComment[0]); ?> ' information
                                                                       </p>
                                                                    
                                                                    <?php endif; ?>

                                                                    

                                                                    <?php if($jsonComment[1]!=null ): ?>

                                                                       <p class="ml-1" style="color:black">
                                                                          &bull; Mistakes in <?php echo e($jsonComment[1]); ?> information
                                                                       </p>
                                                                    
                                                                    <?php endif; ?>

                                                                    

                                                                     <?php if($jsonComment[2]!=null ): ?>

                                                                       <p class="ml-1" style="color:black">
                                                                          &bull; Mistakes in ' <?php echo e($jsonComment[2]); ?> ' information
                                                                       </p>
                                                                    
                                                                    <?php endif; ?>

                                                                    

                                                                     <?php if($jsonComment[3]!=null ): ?>

                                                                        <p class="ml-1" style="color:black">
                                                                          &bull; Mistakes in different sections of information
                                                                        </p>

                                                                    <?php endif; ?>
                                                                    
                                                                <?php

                                                                    $jsonComment=json_decode($notification->comment)->comment;

                                                                ?>
                                                                
                                                                <?php if($jsonComment!=null): ?>

                                                                    <span style="color: gray;">Employee message for reporting this student:
                                                                    </span> 
                                                                    <blockquote style="color:tomato">
                                                                        " <?php echo e($jsonComment); ?> "
                                                                    </blockquote>
                                                                <?php endif; ?>

                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php $__currentLoopData = $result['ResStd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a>
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:teal;">

                                                                 Student - rollno: <?php echo e($notification->id); ?> has been restored by the employee - id:<?php echo e($notification->staffid); ?>


                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php $__currentLoopData = $result['DelStd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a>
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:orange">

                                                                 Student - rollno: <?php echo e($notification->id); ?> has been deleted by the employee - id:<?php echo e($notification->staffid); ?>


                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php $__currentLoopData = $result['PerDelStd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <li style="display: flex;">
                                                    <a>
                                                        <div class="notification-content" style="display: inline;">
                                                            
                                                            <div class="notification-text" style="display: inline;color:red">

                                                                 Student - rollno: <?php echo e($notification->id); ?> has been permanently deleted by the employee - id:<?php echo e($notification->staffid); ?>


                                                            </div>

                                                        </div>
                                                        <br>
                                                        <p class="pull-right">
                                                        <small class="notification-timestamp pull-right">

                                                                <?php echo e(\Carbon\Carbon::parse($notification->created_at)->toDayDateTimeString()); ?>


                                                        </small>
                                                        </p>
                                                    </a>
                                                </li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php endif; ?>    
                                            <li class="text-center">
                                                
                                                <a href="/notifications" class="more-link">See All</a>

                                            </li>
                                           
                                        </ul>
                                    </div>
                                </div>
                            </li>

                            <li class="header-icon dib">
                                <span class="user-avatar">
                                    
                                    <img 
                                    
                                    src=  "/img/logo1.png"

                                    title="company logo"

         
                                   class="rounded-circle" style="width:40px; height: 30px" alt="user pic"> 

                                </span>
                            </li> 
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


