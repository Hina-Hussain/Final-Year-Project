<!DOCTYPE html>
<html>
<head>
<title>Activity Log - <?php echo e(session('staffInfo')[0]->name); ?></title>
  <style type="text/css">
    
    .table-title {
        color: #fff;
        background: #4b5366;        
        padding: 16px 25px;
        margin: -20px -25px 10px;
        border-radius: 3px 3px 0 0;
    }

    .table-title h2 {
        margin: 5px 0 0;
        font-size: 24px;
    }

    .table-wrapper {
        background: #fff;
        padding: 20px 25px;
        margin: 30px auto;
        border-radius: 3px;
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }

    .table-filter .filter-group {
        float: right;
        margin-left: 15px;
    }
    .table-filter input, .table-filter select{
        height: 34px;
        border-radius: 3px;
        border-color: #ddd;
        box-shadow: none;
    }
    .table-filter {
        padding: 5px 0 15px;
    }
    .table-filter .btn {
        height: 34px;
    }
    .table-filter input, .table-filter select {
        display: inline-block;
        margin-left: 5px;
    }
    .table-filter input, .table-filter select {
        width: 200px;
        display: inline-block;
    }
    </style>
</head>
<body>

<?php $__env->startSection('content'); ?>

<div class="content-wrap">
<div class="main">
<div class="container-fluid">

<div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
                        <h2 class="text-white"><b>Activity Log</b></h2>
                    </div>
                </div>
            </div>

<!-- List View for Emp-->
<section id="posts">
<div>
<div class="row">

<div class="col" >
        <div class="table-filter">
            <div class="row">
                
                <div class="col-sm-3">

                    <?php if(session('accInfo')[0]->role==1): ?>
<span class="filter-icon"><i class="fa fa-filter">
     
 </i></span>
    <label>Filter &nbsp;</label>
 
                            <select class="form-control" style="display: inline-block;width: 120px;"id="orderSelect" onchange="ordSelect()">
                                        <option id="or-none">None</option>
                                       <option id="or-creations" value="creations">Creations</option>
                                <option id="or-updations" value="updations">Updations</option>
                                <option id="or-deletions" value="deletions">Deactivations</option>
                                <option id="or-verified" value="verified">Verified</option>
                                <option id="or-reported" value="reported">Reported</option>
                            </select>

                    <?php endif; ?>

                </div>
                    <div class="col-sm-9">
                     <?php if($search): ?>
                        <form class="form-inline pull-right" role="form" action="/logs/search" id="searchform">
                        
                        <?php echo csrf_field(); ?>
                        <div class="filter-group">
                            
                           <input type="date" class="form-control " placeholder="Search By Date" name="search">
                            
                            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>

                            <input type="hidden" class="form-control " name="sjson" id="sjson"> 

                            <datalist id="searchlist">
                                
                            </datalist>
                        </div>
                        </form>
                        <?php endif; ?>
                    </div>

            </div>
        </div>

    <div id="logs-details" style="background-color: white;margin-top: 0px" class="p-4">

    <table class="table table-borderless">
      <thead >
        <tr>

            <!-- account type -->
            <th scope="col" >Account Type</th>

            <!-- description -->
            <th scope="col" >Action Description</th>

            <!-- date -->
            <th scope="col" style="text-align: center;"><i class="ti-calendar"></i></th>
                
            </th>
      
        </tr>
      </thead>
    <tbody>

<?php for($r = 0; $r < count($res2['crud']); $r++ ): ?>

<tr>
<td>
                
<?php echo e(ucfirst($res2['changesMadeBy'][$r][0]->role)); ?>


</td>

<th>

<?php if($res2['crud'][$r]->status==1): ?>            

<!-- creation -->

<?php if($res2['crud'][$r]->tableName=='empaccountsinfo'): ?>

<!-- employee creation -->

<!-- checking whether the person who made the changes is deleted or not -->

<?php if($res2['changesMadeBy'][$r][0]->status==1): ?>


<a href="/employees/view?id=<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>" style="color:blue;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php elseif($res2['changesMadeBy'][$r][0]->status==0): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>&status=0" style="color:orange;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php else: ?>

<p style="color:red; display: inline-block" title=" This Employee has been deleted">

<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>


- id:

<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>


</p>

<?php endif; ?>


created an employee account with name and id 
<br>
<!-- checking whether the person added has been deleted or is still there (future case)-->

<?php if($res2['changesMadeOn'][$r][0]->status==1): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>" style="color:blue;">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>

</a>


<?php elseif($res2['changesMadeOn'][$r][0]->status==0): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>&status=0" style="color:orange;">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>

</a>

<?php else: ?>

<p style="color:red; display: inline-block" title=" This Employee has been deleted">

<?php echo e($res2['changesMadeOn'][$r][0]->name); ?>


- id:

<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>


</p>

<?php endif; ?>

<?php elseif($res2['crud'][$r]->tableName=='role'): ?>

<!-- role creation  -->

<!-- used here elseif so that this can be used for other tables.... -->

<!-- checking whether the person who made the changes is deleted or not -->

<?php if($res2['changesMadeBy'][$r][0]->status==1): ?>


<a href="/employees/view?id=<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>" style="color:blue;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php elseif($res2['changesMadeBy'][$r][0]->status==0): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>&status=0" style="color:orange;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php else: ?>

<p style="color:red; display: inline-block" title=" This Employee has been deleted">

<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>


- id:

<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>


</p>

<?php endif; ?> <!-- end empaccoutInfo-->

created a Role  

<!-- to add some url to redirect this to page account rights -->

<b style="color: blue;"><?php echo e($res2['changesMadeOn'][$r][0]->name); ?></b>

<?php endif; ?>  <!-- tablename = role-->

<!-- changes by hina-->
<?php elseif($res2['crud'][$r]->status==0): ?>

<!-- updation -->


<?php if($res2['crud'][$r]->tableName=='role'): ?>

<?php if($res2['changesMadeBy'][$r][0]->status==1): ?>


<a href="/employees/view?id=<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>" style="color:blue;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php elseif($res2['changesMadeBy'][$r][0]->status==0): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>&status=0" style="color:orange;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php else: ?>

<p style="color:red; display: inline-block" title=" This Employee has been deleted">

<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>


- id:

<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>


</p>

<?php endif; ?>   

deleted the role <?php echo e($res2['changesMadeOn'][$r]); ?>


<?php elseif($res2['crud'][$r]->tableName=='staff' || $res2['crud'][$r]->tableName=='empaccountsinfo'): ?>

<!-- checking whether the person made changes to their own account -->
<?php if($res2['crud'][$r]->id == $res2['crud'][$r]->staffid ): ?>


<!-- checking whether that person is currently logged in -->
<?php if($res2['crud'][$r]->id== session('accInfo')[0]->id ): ?>

You changed your  <?php echo e($res2['crud'][$r]->colName); ?>


<?php else: ?>

<!-- checking whether the person who made the changes is deleted or not -->

<?php if($res2['changesMadeBy'][$r][0]->status==1): ?>


<a href="/employees/view?id=<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>" style="color:blue;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php elseif($res2['changesMadeBy'][$r][0]->status==0): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>&status=0" style="color:orange;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php else: ?>

<p style="color:red; display: inline-block" title=" This Employee has been deleted">

<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>


- id:

<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>


</p>

<?php endif; ?>   

changed their <?php echo e($res2['crud'][$r]->colName); ?>


<?php endif; ?>  <!-- session end if-->

<?php else: ?>  <!-- This else of staffId-->

<!-- someone else made changes to someone else account -->

<!-- checking whether the person who made the changes is deleted or not -->

<?php if($res2['changesMadeBy'][$r][0]->status==1): ?>


<a href="/employees/view?id=<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>" style="color:blue;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php elseif($res2['changesMadeBy'][$r][0]->status==0): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>&status=0" style="color:orange;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php else: ?>

<p style="color:red; display: inline-block" title=" This Employee has been deleted">

<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>


- id:

<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>


</p>

<?php endif; ?>

<!-- checking if it was delete operation -->

<?php if($res2['crud'][$r]->colName=='status'): ?>

<?php if($res2['crud'][$r]->chVal==-1): ?>

permanently deleted employee

<?php elseif($res2['crud'][$r]->chVal==0): ?>

deactivated employee account

<?php elseif($res2['crud'][$r]->chVal==1): ?>

activated employee account

<?php endif; ?>

<?php else: ?>

updated 

<?php if($res2['crud'][$r]->colName=='email' ): ?>

<?php echo e($res2['crud'][$r]->colName); ?> from

<span style="font-weight: bold"><?php echo e($res2['crud'][$r]->prevVal); ?></span> to 
<br>
<span style="font-weight: bold"><?php echo e($res2['crud'][$r]->chVal); ?></span> of employee 

<?php elseif($res2['crud'][$r]->colName=='role'): ?>

<?php echo e($res2['crud'][$r]->colName); ?> from

<span style="font-weight: bold"><?php echo e(ucwords($res2['rolenames'][$res2['changesMadeOn'][$r][0]->id]['prevVal'])); ?></span> to 
<br>
<span style="font-weight: bold"><?php echo e(ucwords($res2['rolenames'][$res2['changesMadeOn'][$r][0]->id]['chVal'])); ?></span> of employee 

<?php else: ?>

<?php echo e($res2['crud'][$r]->colName); ?> 
of employee

<?php endif; ?>

<?php endif; ?>

<!-- checking whether the person added has been deleted or is still there (future case)-->

<?php if($res2['changesMadeOn'][$r][0]->status==1): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>" style="color:blue;">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==0): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>&status=0" style="color:orange;">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>

</a>


<?php else: ?>

<p style="color:red; display: inline-block" title=" This Employee has been deleted">

<?php echo e($res2['changesMadeOn'][$r][0]->name); ?>


- id:

<?php echo e($res2['changesMadeOn'][$r][0]->id); ?>


</p>

<?php endif; ?>




<?php endif; ?>  <!-- end of else of staffId-->


<!-- HINA ADDED-->

<?php elseif($res2['crud'][$r]->tableName=='stdinfo' || $res2['crud'][$r]->tableName=='stdexaminfo'): ?>
<!-- check status of employee-->

<?php if($res2['changesMadeBy'][$r][0]->status==1): ?>


<a href="/employees/view?id=<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>" style="color:blue;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php elseif($res2['changesMadeBy'][$r][0]->status==0): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>&status=0" style="color:orange;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php else: ?>

<p style="color:red; display: inline-block" title=" This Employee has been deleted">

<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>


- id:

<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>


</p>

<?php endif; ?>

<?php if($res2['crud'][$r]->chVal==-1): ?>

deleted  student

<?php if($res2['changesMadeOn'][$r][0]->status==-1): ?>

<?php if(session('accInfo')[0]->role==1): ?>

<a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:orange;" title="This student has been deleted">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php else: ?>

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 
<?php endif; ?>   

<?php elseif($res2['changesMadeOn'][$r][0]->status==-3): ?>

<p style="color:red; display: inline-block" title=" This Student has been permanently deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 

<?php elseif($res2['changesMadeOn'][$r][0]->status==-2): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:red;" title="This student has been reported">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==1): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:blue;" title="Pending Student">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==0): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:green;" title="This Student has been verified">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php endif; ?> <!-- end of student status check-->



<?php elseif($res2['crud'][$r]->chVal==-2): ?>
<!-- mean student is reported-->

reported student
<!--now check student is deleted or not in stdinfo table-->
<?php if($res2['changesMadeOn'][$r][0]->status==-1): ?>

<?php if(session('accInfo')[0]->role==1): ?>

<a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:orange;" title="This student has been deleted">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php else: ?>

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 
<?php endif; ?>   

<?php elseif($res2['changesMadeOn'][$r][0]->status==-3): ?>

<p style="color:red; display: inline-block" title=" This Student has been permanently deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 

<?php elseif($res2['changesMadeOn'][$r][0]->status==-2): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:red;" title="This student has been reported">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==1): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:blue;" title="Pending Student">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==0): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:green;" title="This Student has been verified">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php endif; ?> <!-- end of student status check-->



<?php elseif($res2['crud'][$r]->colName=='IsPass'): ?>

<!-- means student is failed in any subject-->

failed student in <?php echo e($res2['courseNames'][$res2['crud'][$r]->comment

]); ?> subject of <br> student

<?php if($res2['changesMadeOn'][$r][0]->status==-1): ?>

<?php if(session('accInfo')[0]->role==1): ?>

<a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:orange;" title="This student has been deleted">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php else: ?>

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p>   
<?php endif; ?>

<?php elseif($res2['changesMadeOn'][$r][0]->status==-3): ?>

<p style="color:red; display: inline-block" title=" This Student has been permanently deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 

<?php elseif($res2['changesMadeOn'][$r][0]->status==-2): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:red;" title="This student has been reported">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==1): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:blue;" title="Pending Student">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==0): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:green;" title="This Student has been verified">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php endif; ?> <!-- end of student status check-->



<?php elseif($res2['crud'][$r]->colName=='markObtInPr'||
$res2['crud'][$r]->colName=='markObtInTh'): ?>
<!-- else any type of updation performed-->
updated
<?php

if($res2['crud'][$r]->colName=='markObtInPr')
{$colname = 'Practical Marks';}

elseif($res2['crud'][$r]->colName=='markObtInTh')
{$colname = 'Theory Marks';}
else
{$colname = $res2['crud'][$r]->colName; }

?>

<?php echo e($colname); ?> of <?php echo e($res2['courseNames'][$res2['crud'][$r]->comment

]); ?> subject <br> 
from <?php echo e($res2['crud'][$r]->prevVal); ?> to
<?php echo e($res2['crud'][$r]->chVal); ?> of student

<!--student status check-->
<?php if($res2['changesMadeOn'][$r][0]->status==-1): ?>

<?php if(session('accInfo')[0]->role==1): ?>

<a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:orange;" title="This student has been deleted">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php else: ?>

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 
<?php endif; ?>   

<?php elseif($res2['changesMadeOn'][$r][0]->status==-3): ?>

<p style="color:red; display: inline-block" title=" This Student has been permanently deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p>    
<?php elseif($res2['changesMadeOn'][$r][0]->status==-2): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:red;" title="This student has been reported">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==1): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:blue;" title="Pending Student">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==0): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:green;" title="This Student has been verified">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php endif; ?> <!-- end of student status check-->



<?php elseif($res2['crud'][$r]->prevVal==-1 && ($res2['crud'][$r]->chVal==1 || $res2['crud'][$r]->chVal==-2)): ?>
restore  student

<!--now check student is deleted or not in stdinfo table-->
<?php if($res2['changesMadeOn'][$r][0]->status==-1): ?>

<?php if(session('accInfo')[0]->role==1): ?>

<a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:orange;" title="This student has been deleted">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php else: ?>

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 
<?php endif; ?>   

<?php elseif($res2['changesMadeOn'][$r][0]->status==-3): ?>

<p style="color:red; display: inline-block" title=" This Student has been permanently deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 

<?php elseif($res2['changesMadeOn'][$r][0]->status==-2): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:red;" title="This student has been reported">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==1): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:blue;" title="Pending Student">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==0): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:green;" title="This Student has been verified">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php endif; ?> <!-- end of student status check-->


<?php elseif($res2['crud'][$r]->chVal==-3): ?>
permanently deleted

<p style="color:red; display: inline-block" title=" This Student has been permanently deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 
<?php elseif($res2['crud'][$r]->colName=="pic(picture)"): ?>
updated picture of student 

<!--student status check-->
<?php if($res2['changesMadeOn'][$r][0]->status==-1): ?>

<?php if(session('accInfo')[0]->role==1): ?>

<a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:orange;" title="This student has been deleted">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php else: ?>

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 
<?php endif; ?>   

<?php elseif($res2['changesMadeOn'][$r][0]->status==-3): ?>

<p style="color:red; display: inline-block" title=" This Student has been permanently deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p>    
<?php elseif($res2['changesMadeOn'][$r][0]->status==-2): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:red;" title="This student has been reported">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==1): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:blue;" title="Pending Student">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==0): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:green;" title="This Student has been verified">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php endif; ?> <!-- end of student status check-->


<?php else: ?>

<!-- Any other updation-->
updated 
<?php echo e($res2['crud'][$r]->colName); ?> from
<?php echo e($res2['crud'][$r]->prevVal); ?>

<br> to <?php echo e($res2['crud'][$r]->chVal); ?>


of student 

<!--student status check-->
<?php if($res2['changesMadeOn'][$r][0]->status==-1): ?>

<?php if(session('accInfo')[0]->role==1): ?>

<a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:orange;" title="This student has been deleted">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php else: ?>

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 
<?php endif; ?>   

<?php elseif($res2['changesMadeOn'][$r][0]->status==-3): ?>

<p style="color:red; display: inline-block" title=" This Student has been permanently deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p>    
<?php elseif($res2['changesMadeOn'][$r][0]->status==-2): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:red;" title="This student has been reported">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==1): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:blue;" title="Pending Student">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==0): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:green;" title="This Student has been verified">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php endif; ?> <!-- end of student status check-->



<?php endif; ?>  <!-- end of colname and chval-->

<?php endif; ?> <!-- end of tablename=stdinfo or stdexaminfo or staff etc-->



<?php elseif($res2['crud'][$r]->status==2): ?>
<!--means student is verified-->

<!-- check status of employee-->

<?php if($res2['changesMadeBy'][$r][0]->status==1): ?>


<a href="/employees/view?id=<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>" style="color:blue;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php elseif($res2['changesMadeBy'][$r][0]->status==0): ?>

<a href="/employees/view?id=<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>&status=0" style="color:orange;">
<b>
<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>

</b>
- id:
<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>

</a>

<?php else: ?>

<p style="color:red; display: inline-block" title=" This Employee has been deleted">

<?php echo e($res2['changesMadeBy'][$r][0]->name); ?>


- id:

<?php echo e($res2['changesMadeBy'][$r][0]->id); ?>


</p>

<?php endif; ?>
verified the student 
<!--student status check-->
<?php if($res2['changesMadeOn'][$r][0]->status==-1): ?>

<?php if(session('accInfo')[0]->role==1): ?>

<a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:orange;" title="This student has been deleted">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php else: ?>

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 
<?php endif; ?>   

<?php elseif($res2['changesMadeOn'][$r][0]->status==-3): ?>

<p style="color:red; display: inline-block" title=" This Student has been permanently deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p> 

<p style="color:red; display: inline-block" title=" This Student has been deleted">
<b>
<?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</p>    
<?php elseif($res2['changesMadeOn'][$r][0]->status==-2): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:red;" title="This student has been reported">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==1): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:blue;" title="Pending Student">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>

<?php elseif($res2['changesMadeOn'][$r][0]->status==0): ?>

  <a href="/students/view?q=<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>" style="color:green;" title="This Student has been verified">
<b>
    <?php echo e($res2['changesMadeOn'][$r][0]->fullName); ?>

</b>
-id:
<?php echo e($res2['changesMadeOn'][$r][0]->rollNo); ?>

</a>
<?php endif; ?> <!-- end of student status check-->

<?php endif; ?>  <!-- first end of if creation updation status check-->
</th>


<td>

<?php echo e(\Carbon\Carbon::parse($res2['crud'][$r]->created_at)->toDayDateTimeString()); ?>


</td>
          
</tr>

<?php endfor; ?>

   
    </tbody>
    </table>                            

    <?php if($search): ?>

    <?php echo e($res2['crud']->appends(request()->query())->links()); ?>


    <?php endif; ?>
</div>
<!-- log end -->



</div>
</div>
</div>

</section>

</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>



<!-- bootstrap -->
<?php $__env->startSection('bootstrap'); ?>
<script src="/assets/js/lib/circle-progress/circle-progress.min.js"></script>
<script src="/assets/js/lib/circle-progress/circle-progress-init.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/js/jquery.min.js"></script>
<script src="/js/tether.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
 <script type="text/javascript">

        loc= new URLSearchParams(window.location.search);

        $('#or-'+loc.get('q')).attr('selected',true);
        
        function ordSelect(){

            if($('#orderSelect').val()=="or-none"){

                window.location = "http://127.0.0.1:8000/dashboard/log"+$('#orderSelect').val();

            }else{
            
                window.location = "http://127.0.0.1:8000/dashboard/log?q="+$('#orderSelect').val();

            }

        }
    </script>

<script type="text/javascript">


document.getElementById('dashboard').classList.remove('active');

document.getElementById('staff').classList.remove('active');

document.getElementById('students').classList.remove('active');

document.getElementById('account_rights').classList.remove('active');

document.getElementById('verstudents').classList.remove('active');

document.getElementById('profile').classList.remove('active');

document.getElementById('log').classList.add('active');

document.getElementById('setting').classList.remove('active');

</script>

<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>