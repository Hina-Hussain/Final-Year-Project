   
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title>Manage Students</title>

<style type="text/css">

.table-title {
color: #fff;
background: #4b5366;        
padding: 16px 25px;
margin: -20px -25px 10px;
border-radius: 3px 3px 0 0;
}

.table-title h2 {
margin: 5px 0 0;
font-size: 24px;
}

.table-wrapper {
background: #fff;
padding: 20px 25px;
margin: 30px auto;
border-radius: 3px;
box-shadow: 0 1px 1px rgba(0,0,0,.05);

}

.table-filter .filter-group {
float: right;
margin-left: 15px;
}
.table-filter input,.table-filter select{
height: 34px;
border-radius: 3px;
border-color: #ddd;
box-shadow: none;
}
.table-filter {
padding: 5px 0 15px;
border-bottom: 1px solid #e9e9e9;
margin-bottom: 5px;
}
.table-filter .btn {
height: 34px;
}
.table-filter input, .table-filter select {
display: inline-block;
margin-left: 5px;
}
.table-filter input, .table-filter select{
width: 200px;
display: inline-block;
}
</style>




 
<script src="/js/jquery-1.10.2.js"></script>
<script src="/js/jquery.mask.js"></script>

<script src="/assets/js/lib/jquery-ui/jquery-ui.min.js">
  
</script>
<script type="text/javascript">
function Mask() {
            $("#cnic").mask("99999-9999999-9", {
                placeholder: "       -          -   "
            });
        }
        Mask();
</script>
</head>

<body>


<?php $__env->startSection('content'); ?>
<div class="content-wrap">
<div class="main">
<div class="container-fluid">

<div class="table-wrapper">
<div class="table-title">
<div class="row">
<div class="col-sm-6">
<h2 class="text-white">Manage <b>Students</b></h2>

</div>

</div>
</div>
<?php if($search): ?>
<div class="table-filter">
<div class="row">

<div class="col-sm-3">

<label>Sort &nbsp;</label>

<select class="form-control" style="display: inline-block;width: 120px;"id="orderSelect" onchange="ordSelect()">
    <option id="or-rollno" value="rollno">RollNo</option>
    <option id="or-dept" value="dept">Department</option>
    <option id="or-batch" value="batch">Batch</option>
    <option id="or-system" value="system">System</option>
    <option id="or-status" value="status">Status</option>
</select>

</div>
<!--Filter-->
<div class="col-sm-3">
    <span class="filter-icon"><i class="fa fa-filter"></i></span>
             <label>Filter &nbsp;</label>

              <select class="form-control" style="display: inline-block;width: 120px;" id="filterSelect" onchange="filtSelect()">
             <option id="or-all" value="all">All</option>
            <option id="or-pending" value="pending">Pending</option>
            <option id="or-reported" value="reported">Reported</option>
               
            <?php if(session('accInfo')[0]->role==1): ?>
            <option id="or-deleted" value="deleted">Deleted</option>
            <?php endif; ?>
              </select>
            </div>
           

<div class="col-sm-6">

<form action="/students/search" class="form-inline pull-right" role="form" id="searchform" method="post">

<?php echo csrf_field(); ?>
<div class="filter-group">

<input type="text" class="form-control " placeholder="Search here" name="search" oninput ="searchlist()" 
id="searchInput" list="searchlist" autocomplete="off" >

<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>

<input type="hidden" class="form-control " name="sjson" id="sjson"> 

<datalist id="searchlist">

</datalist>
</div>
</form>
</div>

</div>
</div>

<?php endif; ?>
<?php if(session('message')): ?>

<div class="alert alert-success mt-4 ml-3" role="alert" style="color:white;">

<?php echo e(session('message')); ?>

</div>  
<?php endif; ?>


<?php if(session('anyerror')): ?>

<div class="alert alert-danger mt-4 ml-3" role="alert" style="color:white;">

<?php echo e(session('anyerror')); ?>

</div>  
<?php endif; ?>

<?php if(session('warning')): ?>

<div class="alert" role="alert" style="color:white;background-color:orange;">

<?php echo e(session('warning')); ?>

</div>  
<?php endif; ?>

<!-- List View for Students-->
<section id="posts">
<div>
<div class="row">

<div class="col">
<div>
<table class="table table-striped bg-fadded">
<thead>
<tr>
<th>#</th>
<th>Full Name</th>
<th>Roll no</th>
<th>Department</th>
<th>Batch</th>
<th>Status</th>

<th>Action</th>
</tr>
</thead>
<tbody id="emps">

<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>

<td scope="row"><?php echo e($loop->index+1); ?></td>
<td><?php echo e(ucwords($std->fullname)); ?></td>

<td><?php echo e(strtoupper($std->rollNo)); ?></td>

<td><?php echo e(ucwords($std->name)); ?></td>
<td><?php echo e($std->batch); ?></td>


<?php if($std->status==1): ?>
<td><span class="status"></span><i class="fa fa-circle" style="color: green;"> 
<p style="color:#333;display: inline;">Pending
</p></i></td>

<?php elseif($std->status==-2): ?>

<td><span class="status"></span><i class="fa fa-circle" style="color:red;"> 
<p style="color:#333;display: inline;">Reported
</p></i></td>


<?php elseif($std->status==-1 && session('accInfo')[0]->role==1): ?>

<td><span class="status"></span><i class="fa fa-circle" style="color:orange;"> 
<p style="color:#333;display: inline;">Deleted
</p></i></td>

<?php endif; ?>
<td>
<?php if($std->status==-1 && session('accInfo')[0]->role==1): ?>

<button class="btn text-white" style="background-color: orange"  title="restore student" data-toggle="modal" data-target="#resStd"
onclick="restore('<?php echo e($std->rollNo); ?>')">
<i class="fa fa-repeat"></i>
</button>

<?php if(array_key_exists('del-std',$content)): ?>

<button class="btn btn-danger fa fa-trash" data-toggle="modal" data-target="#DelSModal"  title="delete"
  onclick="getId('<?php echo e($std->rollNo); ?>')">
  </button>
<?php endif; ?>

<?php elseif($std->status==1 || $std->status==-2): ?>

<?php if(array_key_exists('edit-std',$content)): ?>

<button class="btn btn-success fa fa-edit" title="edit" id="edit<?php echo e($std->rollNo); ?>" onclick="showStd('<?php echo e($std->rollNo); ?>')" data-toggle="modal" data-target="#EditSModal" 
  >
</button>
<?php endif; ?>


<?php if(array_key_exists('del-std',$content)): ?>

<button class="btn btn-danger fa fa-trash" data-toggle="modal" data-target="#DelSModal"  title="delete"
  onclick="getId('<?php echo e($std->rollNo); ?>')">
  </button>
<?php endif; ?>

<?php endif; ?>
  

</td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>
</table>

<?php if($search): ?>

<?php echo e($results->appends(request()->query())->links()); ?>


<?php endif; ?>

</div>
</div>
</div>
</div>

</section>
</div>
</div>
</div>
</div>



<!-- Delete Student Conf MODAL 5/5/18-->
<div class="modal fade" id="DelSModal">
<div class="modal-dialog modal-md">
<div class="modal-content">
<div class="modal-header bg-danger text-white">
<h6 class="modal-title text-white" id="addEModalLabel">Are you sure?</h6>
<button class="close text-white" data-dismiss="modal">
   <span>&times;</span>
  </button>
</div>
<div class="modal-body">
<p>Do you really want to delete this student?</p>

<form class="form-horizontal" id="deleteForm" role="form" method="post" action="/student/delete">

<?php echo csrf_field(); ?>

<input type="hidden" name="id" value="" id="rollNo">

<div class="pull-right">

<button class="btn btn-danger" id="submitDel" type="submit" onclick="clickedDel()" style="border-radius:5px;">Yes</button>
<button type="button" class="btn btn-dark text-white" data-dismiss="modal" style="border-radius:5px;">Cancel</button>

</div>
</form>
</div>
</div>
</div>
</div>


<!-- restore model-->
<div class="modal fade" id="resStd">
<div class="modal-dialog modal-md">
<div class="modal-content">
<div class="modal-header text-white" style="background-color: orange;">
<h6 class="modal-title text-white" id="addEModalLabel">Are you sure?</h6>
<button class="close text-white" data-dismiss="modal">
   <span>&times;</span>
  </button>
</div>
<div class="modal-body">

<p>Do you really want to restore this student?
</p>

<form action="/student/restore" id="restoreForm" method="post" id="deleteform">

<input type="hidden" name="rollno" id="rollno" value="">

<?php echo csrf_field(); ?>

<div class="pull-right">                       

  <button type="submit" id="submitdelete" class="btn btn-success" onclick="clickedRes()" style="border-radius:5px;">Restore</button>

  <button type="button" class="btn btn-dark text-white" data-dismiss="modal" style="border-radius:5px;">Cancel</button>

</div>

</form>

</div>
</div>
</div>
</div>



<div id="modal">
    
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">

      function clickedDel(){

         $('#submitDel').attr('disabled',true);
         $('#deleteForm').submit();
      }

      function clickedRes(){

        $('#submitdelete').attr('disabled',true);

        $('#restoreForm').submit();

      }

        loc= new URLSearchParams(window.location.search);
        $('#or-'+loc.get('q')).attr('selected',true);
        
        function ordSelect(){

            window.location = "http://127.0.0.1:8000/dashboard/students?q="+$('#orderSelect').val();

        }
        function filtSelect(){
          window.location = "http://127.0.0.1:8000/dashboard/students?q="+$('#filterSelect').val();
        }
   
   </script>

   <script type="text/javascript"> 
 //for displaying active on sidebar components

document.getElementById('dashboard').classList.remove('active');

document.getElementById('staff').classList.remove('active');

document.getElementById('account_rights').classList.remove('active');

document.getElementById('profile').classList.remove('active');

document.getElementById('log').classList.remove('active');

document.getElementById('setting').classList.remove('active');
document.getElementById('verstudents').classList.remove('active');
document.getElementById('students').classList.add('active');

//end 


 
// function for delete modal
function getId(id){
document.getElementById('rollNo').value = id;
}
function restore(id)
{
  document.getElementById('rollno').value = id;
}
// function for getting rollNo
 function showStd(id)
 {
   $('#edit'+id).attr('disabled',true);
   $.get('<?php echo e(URL::to("/edit")); ?>/'+id, function(data) {
             $('#modal').empty().append(data);
             $('#EditSModal').modal({backdrop: 'static', keyboard: false});

             $('#edit'+id).attr('disabled',false);
          });
   }
  
 // when personal info form submit
   $(function(){
   
   $("#modal").on('submit','#pinfoform',
    function(e){
  e.preventDefault();
  var form  = new FormData(this);
  
   $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
 });

    $.ajax({
      url:'<?php echo e(URL::to("/pinfo/update")); ?>',
      type: "POST",
      data: form,
      processData: false,
      contentType: false
    })
     .done(function(data) {
   
   location.reload();
      })

   .fail(function(response) {
    if(response.status == 422)
    {
      var $error = $.parseJSON(response.responseText);
      var fail = $error['errors'];

    $("#fail").removeClass('hidden');
    $("#fail").empty();
   
    // The root nodes are field names, with an array of error messages

    $.each(fail,function(key,value){
      
       $("#fail").append(value);
         $("#EditSModal").scrollTop(0);
 });
 }// end of if
   
    }); // end of fail function

 });

 }); // end of pinfotab 
 


// when transcript first year form submit

  $(function(){
   
   $("#modal").on('submit','#firstform',
    function(e){
    e.preventDefault();
    var marksData = $(this).serialize();

     $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
 });

    $.ajax({
     url:'<?php echo e(URL::to("/transcript/update")); ?>',
     type: "POST",
     data :marksData
    
    })
       .done(function(data) {
     if(data[0]==0)
     {
       location.reload();
       //console.log(data[1]);

     }

     else if(data[0]==1 || data[0]==2 || data[0]==6)
     {
      $("#markserr1").removeClass('hidden');
      $("#markserr1").empty().append(data[1]);
      $("#EditSModal").scrollTop(0);
     }

     else if(data[0]==3)
     {
      location.reload();
  
     }

     else if(data[0]==4)
     {
     location.reload();
     }
    

      })

   .fail(function(response) {
   
   
    }); // end of fail function

 });

 });

// when second year submit

$(function(){
   
   $("#modal").on('submit','#secondform',
    function(e){
    e.preventDefault();
    var marksData = $(this).serialize();

     $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
 });

    $.ajax({
     url:'<?php echo e(URL::to("/transcript/update")); ?>',
     type: "POST",
     data :marksData
    
    })
       .done(function(data) {
     if(data[0]==0)
     {
       location.reload();
     
     }

     else if(data[0]==1 || data[0]==2 || data[0]==6)
     {
      $("#markserr2").removeClass('hidden');
      $("#markserr2").empty().append(data[1]);
      $("#EditSModal").scrollTop(0);
     }

     else if(data[0]==3)
     {
      location.reload();
  
     }

     else if(data[0]==4)
     {
     location.reload();
     }
    

      })

   .fail(function(response) {
   
   
    }); // end of fail function

 });

 });

// when third year form submit

$(function(){
   
   $("#modal").on('submit','#thirdform',
    function(e){
    e.preventDefault();
    var marksData = $(this).serialize();

     $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
 });

    $.ajax({
     url:'<?php echo e(URL::to("/transcript/update")); ?>',
     type: "POST",
     data :marksData
    
    })
       .done(function(data) {
     if(data[0]==0)
     {
       location.reload();
     
     }

     else if(data[0]==1 || data[0]==2 || data[0]==6)
     {
      $("#markserr3").removeClass('hidden');
      $("#markserr3").empty().append(data[1]);
      $("#EditSModal").scrollTop(0);
     }

     else if(data[0]==3)
     {
      location.reload();
  
     }

     else if(data[0]==4)
     {
     location.reload();
     }
    

      })

   .fail(function(response) {
   
   
    }); // end of fail function

 });

 });

// when four year submit

$(function(){
   
   $("#modal").on('submit','#fourform',
    function(e){
    e.preventDefault();
    var marksData = $(this).serialize();

     $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
 });

    $.ajax({
     url:'<?php echo e(URL::to("/transcript/update")); ?>',
     type: "POST",
     data :marksData
    
    })
       .done(function(data) {
     if(data[0]==0)
     {
       location.reload();
     
     }

     else if(data[0]==1 || data[0]==2 || data[0]==6)
     {
      $("#markserr4").removeClass('hidden');
      $("#markserr4").empty().append(data[1]);
      $("#EditSModal").scrollTop(0);
     }

     else if(data[0]==3)
     {
      location.reload();
  
     }

     else if(data[0]==4)
     {
     location.reload();
     }
    

      })

   .fail(function(response) {
   
   
    }); // end of fail function

 });

 });




// when otherInfo form is submit

$(function(){
   
  $("#modal").on('submit','#otherInfo',
  function(e){
   e.preventDefault();
  var degreeInfo = $(this).serialize();

$.ajax({
     url :'<?php echo e(URL::to("/student/insert")); ?>',
    type : "POST",
    data : degreeInfo
  })
   .done(function(data){
      // reload the page
      location.reload();
     
   }) // end of done function

   .fail(function(response){
     if(response.status == 422)
    {
      var $error = $.parseJSON(response.responseText);
      var fail = $error['errors'];

    $("#degreefail").removeClass('hidden');
    $("#degreefail").empty();
   
    // The root nodes are field names, with an array of error messages

    $.each(fail,function(key,value){
      
         $("#degreefail").append(value);
         $("#EditSModal").scrollTop(0);
 });
 
 }// end of if
 
   }); // end of fail function
  
  });
 
 }); // end of otherInfoTab

 // end of document function 


function searchlist(){
var query = $('#searchInput').val().trim();
console.log(query);
if(query.length>1)
{
  $.get('<?php echo e(URL::to("/students/search")); ?>?q='+query,function(data){

    console.log(data);
  document.getElementById('searchlist').innerHTML="";
    for(var i=0;i<data.length;i++)
    {
      var resultSet = "Name: "+data[i].fullname+" RollNo: "+data[i].rollNo+" Department: "+data[i].name+" Batch: "+data[i].batch+" Status: "+data[i].status;
      var option = document.createElement('option');
      
      option.value = resultSet;
 var jsonData='[{' +
'"rollNo":"'+data[i].rollNo+
'","fullname":"'+data[i].fullname+
' ","name":"'+data[i].name+
' ", "batch":"'+data[i].batch+
' ", "status":'+data[i].status+'}]';



option.title=jsonData;

document.getElementById("searchlist").appendChild(option);
    }

  });
}
}


$("#searchInput").bind('input', function () {
var flag=checkExists( $('#searchInput').val() );
if(flag){

document.getElementById('sjson').value=flag;

window.location.assign("/students/search/results?val="+flag);
console.log(flag);
}
});

function checkExists(inputValue) {
console.log(inputValue);

var x = document.getElementById("searchlist");
var i;
var flag;
var label;
for (i = 0; i < x.options.length; i++) {
if(inputValue == x.options[i].value){
flag = true;
label=x.options[i].title;
}
}

if(flag){
return label;
}

return flag;
}

 


</script> 

<?php $__env->stopSection(); ?>

</body>

</html>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>