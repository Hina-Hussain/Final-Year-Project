<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/css/style.css">
    <title>Reset Your Password - Validator</title>
    
    <link rel="stylesheet" type="text/css" href="/css/style2.css">
    
</head>

<body class="web_back_color">
  
            <hr class="nav1" style="margin-top: 150px;">
        
                        
    <div class="col-md-12 col-md-6">
        <div class="pos1 ">
                <h4  style="color: #ffffff;text-align: center; font-size: 35px;"> Reset your password </h4>

                <br>
    
                <p style="font-size: 17px;">
                    Enter a new password for your account. We highly
                    recommend you create a unique password - one that you
                    don't use for any other websites.
                </p>
 </div>

<br>

           <div class="col-md-5" >

            <form action="/login/resetPassword" method="post" class="pos" style="margin-top: -240px;" id="resetPassForm">

                <?php if($flash=session('danger')): ?>
                
                    <div class="alert alert-danger" role="alert" style="color:white;">
                                                    
                        <?php echo e($flash); ?>   
                                                
                    </div>

                <?php endif; ?>

                <div class="alert alert-danger" role="alert" id="error" style="display:none;color:white;">
                    <!-- display errors here  -->
                </div>

                <div class="alert alert-primary" id="passrules" style="color:white;;text-align: left;font-size: 0.9em;border: 1px solid transparent;border-radius: 5px;">
                                               
                    <ul>
                        <li>
                            &bull; Password should have atleast 6 characters.
                        </li>
                        <li>
                            &bull; Password should have one Uppercase character.
                        </li>
                        <li>
                            &bull; Password should have one Lowercase character.
                        </li>
                    </ul>

                </div>

                <?php echo csrf_field(); ?> 

                <div class="input-group">

                    <?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                </div>

                <div class="input-group" >
                    
                    <span class="input-group-addon"><i class="fa fa-lock "></i></span>
                    
                    <input  type="password"  name="password" class="btn btn-outline-secondary btn-block text-white text-left" id="pass" placeholder="enter your password" required minlength="6">

                </div>

                <br><br>

                <div class="input-group">
                    
                    <span class="input-group-addon"><i class="fa fa-lock "></i></span>
                    
                    <input  type="password" id="cpass" name="password_confirmation" class="btn btn-outline-secondary btn-block text-white text-left" placeholder="enter your password again" required minlength="6">
                
                </div>

                <br> <br>
                
                <div class="text-center">
                        <button class="col-md-12 login-btn-blue" type="button" onclick="check()">RESET YOUR PASSWORD</button>
                </div>
                
                <br><br>
                
                
            </form>
            </div>
        </div>


<!--===========================================================================================-->
    <script type="text/javascript">
        
        function check() {

            console.log('checking');
            var password = document.getElementById('pass').value;
            var password_confirmation = document.getElementById('cpass').value;

            var error=document.getElementById('error')

            // password

             if(password!="" && password_confirmation!=""){

                if(password.length >= 6){

                    var countNum=0;
                    var countUppercase=0;
                    var countLowercase=0;
                    
                    var i=0;
                    var character='';

                    while (i <= password.length){
                        
                        character = password.charAt(i);
                        
                        if (!isNaN(character * 1)){

                            countNum++;

                        }else{
                            
                            if (character == character.toUpperCase()) {
                                
                                countUppercase++;

                            }
                            
                            if (character == character.toLowerCase()){

                                countLowercase++;

                            }

                        }

                        i++;

                    }

                    if(countNum >= 1 && countUppercase >= 1 && countLowercase >= 1){

                        if(password!=password_confirmation){

                            error.style="display:block;color:white;"
                            error.innerHTML="Password do not match!";
                            console.log('invalid pass');

                        }else{

                            error.style.display="none"

                            document.getElementById('resetPassForm').submit();
                            console.log('ok pass');
                        }

                    }else{

                        error.style="display:block;color:white;"
                        error.innerHTML="Your Password should have atleast one character one uppercase and one lowercase letter.";
                        console.log('invalid pass');

                    }

                }else{

                    error.style="display:block;color:white;"
                    error.innerHTML="Password should be atleast 6 characters long!";

                    console.log('invalid pass length');

                }

            }else if (password=="" || password_confirmation==""){

                error.innerText='Enter the password!';
                error.style="display:block;color:white;"
                console.log('empty');

            }


        }

    </script>

        <script src="/js/jquery.min.js"></script>
        <script src="/js/tether.min.js"></script>
        <script src="/js/bootstrap.min.js"></script>

    </header>

</body>

</html>