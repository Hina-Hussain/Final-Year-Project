<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use App\CommonCode;

class DegreeInfo extends Model
{

   //calculate cgpa
    public static function getCgpa($id)
    {
     
     
     // first get the deptId and batch
     $res     = CommonCode::getBatchDept($id);
     $batch   = $res->batch;
     $deptId  = $res->deptId;

      // get total practical credit hour

      $creditPr = DB::table('credit_mode')
                ->join('practicals','credit_mode.courseCode','=','practicals.courseCode')
                ->join('courses','credit_mode.courseCode','=','courses.courseCode')
                ->where([
         ['courses.deptId','=',$deptId],
         ['credit_mode.batch','=',$batch],
         ['credit_mode.IsPractical','=',1]
       ])
       ->sum('practicals.creditHour');
    

    // get total theory credit hour

    $creditTh = DB::table('credit_mode')
                ->join('courses','credit_mode.courseCode','=','courses.courseCode')
                ->where([
           ['courses.deptId','=',$deptId],
           ['credit_mode.batch','=',$batch],
           ['credit_mode.IsTheory','=',1]
            ])
            ->sum('courses.creditHr');

         // total credith hour 1st to final year

          $totalcredit =   $creditPr+$creditTh;
       
       // get total and obtain marks

      $marksdata = DB::table('credit_mode')
          ->join('courses','credit_mode.courseCode','=','courses.courseCode')
         ->leftjoin('practicals','credit_mode.courseCode','=',
         'practicals.courseCode')
        ->join('stdexaminfo','credit_mode.courseCode','=','stdexaminfo.courseId')
       ->where([
         ['stdexaminfo.rollNo','=',$id],
         ['credit_mode.batch',$batch]
       ])
       ->select('courses.courseCode','courses.maxMarks','courses.creditHr','stdexaminfo.markObtInTh','practicals.maximumMarks','practicals.creditHour','stdexaminfo.markObtInPr','credit_mode.IsTheory','credit_mode.IsPractical')
       ->get();

    // obtain quality point

           $qualityPointTh = 0;
           $qualityPointPr = 0;
     
             foreach($marksdata as $value)
          {
      
       $qualityPointTh = DegreeInfo::qualityPoint($value->maxMarks,$value->creditHr,$value->markObtInTh,$value->IsTheory)
               +$qualityPointTh;

       $qualityPointPr = DegreeInfo::qualityPoint($value->maximumMarks,$value->creditHour,$value->markObtInPr,$value->IsPractical) + $qualityPointPr;
        
      }
       
           $cgpa = ($qualityPointPr+$qualityPointTh)/$totalcredit;

        return round($cgpa,2);    
  
   } // end of function


public static function qualityPoint($maxMarks,$creditHr,$marksobt,$status)
  {
    if($status==1)
    {
        $gradeId = DB::table('gradingmarks')->select('gradeId')
           ->where([
           ['totalMarks','=',$maxMarks],
            ['minMarks','<=',$marksobt],
            ['maxMarks','>=',$marksobt],
           ])->first();
           
         $id= $gradeId->gradeId;

     $point  = DB::table('gradingpoint')->select('point')
           ->where('id',$id)->first();
        $p=$point->point;
          
           return ($creditHr*$p);
  }// end of if
} // end of function



// add keys and other info into database

public static function addInfo($id,$degreekey,$passkey,$transkey,$position,$dop,$doe,$dod)
{
      // get cgpa
      $cgpa = self::getCgpa($id);
      $res = 0;
  try {
    
     DB::transaction(function () use($id,$degreekey,$passkey,$transkey,$position,$dop,$doe,$dod,$cgpa,$res)
      {
         
        
 // now  insert data in documents table

       DB::table('documents')->insert(
     ['rollNo'   =>  $id,
        'algD'   =>  $degreekey,
        'algP'   =>  $passkey,
       'algT'    =>  $transkey,
       'dod'     =>  $dod, 
      'position' =>  $position,
        'cgpa'   =>  $cgpa,
        'dop'    =>  $dop,
        'doe'    =>  $doe,
        'status' =>   1]
  );
     
     //first get status of student
    $res =  DB::table('stdinfo')->select('status')
       ->where('rollNo',$id)->first();
     $res = $res->status;
       
     // change status in stdinfo table

        DB::table('stdinfo')->where('rollNo',$id)
      ->update(['status'=> 0]);


       // entry in crud table for insert record

        DB::table('crud')->insert([
        
        'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'tableName'=> 'documents',
        'status'=> 2 
         ]);

       

     // now  entry in notification table for insert record or verified students
      
       DB::table('notification')->insert([

        'type'   => 0,
        'status' => 2,
        'staffId' => session('accInfo')[0]->id,
         'id'     => $id
       ]);
        

       

      });// end of db function
  } // end of try 

  catch (Exception $e) {
    return FALSE;
  }

   return TRUE;

} // end of function 




// get degree info of reported student

public static function getDegreeInfo($id)
{
    $res =   DB::table('documents')
          ->select('dod','position','cgpa','dop','doe')
          ->where([
            ['rollNo','=',$id],
            ['status','=',0]
          ])
          ->orderBy('created_at','dsc')
           ->first();
  return $res;
} // end of function


} 

  


