<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;



class View extends Model
{
    public static function changeMob($id,$mobno,$prevmob)
    {
      try {
        DB::transaction(function () use($id,$mobno,$prevmob)

        {
          DB::table('stdinfo')->where('rollNo',$id)
          ->update(['mbNo'=>$mobno]);

          // insert in crud table
          DB::table('crud')->insert([
        
        'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'colName'=> 'mbNo(mobile number)',
        'chVal'=> $mobno,
        'prevVal'=> $prevmob,
        'tableName'=> 'stdinfo',
        'status'=> 0 

          ]);
        
        // insert in notification table

      
       DB::table('notification')->insert([

        'type'   => 0,
        'status' => 0,
       'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=> 'mbNo(mobile number)'
        
       ]);

        });


      } 
      catch (Exception $e) {
        return FALSE;
      }
      return TRUE;
    }

 public static function changeEmail($id,$mail,$oldmail)
 {
  try {
    
    DB::transaction(function() use($id,$mail,$oldmail)
      {
       DB::table('stdinfo')->where('rollNo',$id)
       ->update(['email'=>$mail]);

      
         // insert in crud table
          DB::table('crud')->insert([
        
        'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'colName'=> 'email',
        'chVal'=> $mail,
        'prevVal'=> $oldmail,
        'tableName'=> 'stdinfo',
        'status'=> 0 

          ]);
        
        // insert in notification table

      
       DB::table('notification')->insert([

        'type'   => 0,
        'status' => 0,
       'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=> 'email'
        
       ]);

      });  
  } 
  catch (Exception $e) {
   return FALSE; 
  }
 return TRUE; 
 }   


public static function changeAddr($id,$address,$oldaddr)
{
  try {
   DB::transaction(function() use($id,$address,$oldaddr)
   {
     
    DB::table('stdinfo')->where('rollNo',$id)
    ->update(['addr'=>$address]);


      // insert in crud table
          DB::table('crud')->insert([
        
        'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'colName'=> 'addr(address)',
        'chVal'=> $address,
        'prevVal'=> $oldaddr,
        'tableName'=> 'stdinfo',
        'status'=> 0 

          ]);
        
        // insert in notification table

      
       DB::table('notification')->insert([

        'type'   => 0,
        'status' => 0,
       'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=> 'addr(address)'
        
       ]);


   });  
  } 

  catch (Exception $e) {
    return FALSE;
  }
  return TRUE;
}

public static function changeCP($id,$currPos,$prevPos)
{ $changeValue = "";
  try {
    
   DB::transaction(function() use($id,$currPos,$prevPos,$changeValue)
   {
    $changeValue = View::convertData($id,$currPos);

    DB::table('stdinfo')->where('rollNo',$id)
    ->update(['currentPosition'=>$changeValue]);


     
      // insert in crud table
          DB::table('crud')->insert([
        
        'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'colName'=> 'currentPosition',
        'chVal'=> $currPos,
        'prevVal'=> $prevPos,
        'tableName'=> 'stdinfo',
        'status'=> 0 

          ]);
        
        // insert in notification table

      
       DB::table('notification')->insert([

        'type'   => 0,
        'status' => 0,
       'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=> 'currentPosition'
        
       ]);
    });

  } catch (Exception $e) {
    return FALSE;
  }
return TRUE;
}


public static function convertData($id,$currPos)
{
   $res =  DB::table('stdinfo')->select('currentPosition')
        ->where('rollNo',$id)->first();
   $orgName = json_decode($res->currentPosition)->orgName;
   $orgType = json_decode($res->currentPosition)->type;

   $data    = array("curPos" =>$currPos,"orgName"=>$orgName,"type"=>$orgType);

   return json_encode($data);    
}


public static function changeOrg($id,$orgName,$prevName,$orgType)
{

$changeValue = "";
  try {
    
   DB::transaction(function() use($id,$orgName,$prevName,$orgType,$changeValue)
   {
    $changeValue = View::changeFormat($id,$orgName,$orgType);

    DB::table('stdinfo')->where('rollNo',$id)
    ->update(['currentPosition'=>$changeValue]);


     
      // insert in crud table
          DB::table('crud')->insert([
        
        'staffId'=>session('accInfo')[0]->id,
        'id'=> $id,
        'colName'=> 'currentPosition',
        'chVal'=> $orgName,
        'prevVal'=> $prevName,
        'tableName'=> 'stdinfo',
        'status'=> 0 

          ]);
        
        // insert in notification table

      
       DB::table('notification')->insert([

        'type'   => 0,
        'status' => 0,
       'staffId' => session('accInfo')[0]->id,
        'id'     => $id,
        'colName'=> 'currentPosition'
        
       ]);
    });

  } catch (Exception $e) {
    return FALSE;
  }
return TRUE;
}


public static function changeFormat($id,$orgName,$type)
{
  $res = DB::table('stdinfo')->select('currentPosition')
          ->where('rollNo',$id)->first();

 $currentPos = json_decode($res->currentPosition)->curPos;
 $data = array("curPos"=>$currentPos,"orgName"=>$orgName,"type"=>$type);
 return json_encode($data);            
}

}



