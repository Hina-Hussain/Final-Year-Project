<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Search extends Model
{
    //checked
    public static function scopeSearchEmp($query, $searchEmp){

    	$res=DB::table('empaccountsinfo')
    		
                ->select('staff.id','staff.name','empaccountsinfo.email','dept.name as dept','role.name as role','staff.status as staffstat','empaccountsinfo.status')
    		
                ->join('staff','staff.id','=','empaccountsinfo.staffid')
    		
                ->join('dept','dept.id','=','staff.deptId')

                ->join('role','role.id','=','empaccountsinfo.role')
    		
                ->orwhere('empaccountsinfo.email','LIKE','%'.$searchEmp['val'].'%')
    		
                ->orwhere('staff.name','LIKE','%'.$searchEmp['val'].'%')
    		  
                ->orwhere('staff.id','LIKE','%'.$searchEmp['val'].'%')
    		
                ->orwhere('dept.name','LIKE','%'.$searchEmp['val'].'%')

                ->orwhere('role.name','LIKE','%'.$searchEmp['val'].'%')

                ->limit(5)
    		
                ->get();

    	$res2=array();

    	foreach($res as $val){

        if(session('accInfo')[0]->role==1){

          if ($val->staffstat==1 && ($val->status==1 || $val->status==0)) {
            array_push($res2, $val);
          }

        }else{

          if ($val->staffstat==1 && $val->status==1) {
            array_push($res2, $val);
          }

        }

    	}

    	return $res2;
    }

// student Search Added By Hina
    public static function searchStudent($query)
{
   $res1 = array();     

   $res   = DB::table('stdinfo')
          ->join('dept','stdinfo.deptId','=','dept.id')
          ->join('batch','stdinfo.doa','=','batch.year')
          ->join('stdedustatus','stdedustatus.rollNo','=','stdinfo.rollNo')
          ->join('edusystem','edusystem.fromBatch','=','batch.batch')

          ->select('stdinfo.fullname','stdinfo.rollNo','dept.name','batch.batch','stdinfo.status')

          ->where('stdinfo.fullname','LIKE','%'.$query.'%')
          ->orwhere('stdinfo.rollNo','LIKE','%'.$query.'%')
          ->orwhere('dept.name','LIKE','%'.$query.'%')
          ->orwhere('batch.batch','LIKE','%'.$query.'%')
          ->groupBy('stdedustatus.rollNo')
          ->havingRaw('SUM(stdedustatus.semsStatus)= 8')
            ->limit(5)
          ->get();

foreach ($res as $value) {
  
if(session('accInfo')[0]->role==1){
if($value->status==1 || $value->status==-1 || $value->status==-2)
{
  array_push($res1,$value);
}
}
else
{
  if($value->status==1 || $value->status==-2)
  {
    array_push($res1,$value);
  }
}
}


return $res1;

}

// search verified students
public static function searchVerified($query)

{
 $res = array();
  $std = DB::table('stdinfo')
             ->join('dept','stdinfo.deptId','=','dept.id')
             ->join('batch','stdinfo.doa','=','batch.year')
             ->join('edusystem','edusystem.fromBatch','=','batch.batch')
             ->select('stdinfo.fullname','stdinfo.rollNo','dept.name','batch.batch','stdinfo.status')
         
              ->where('stdinfo.fullname','LIKE','%'.$query.'%')
             ->orwhere('stdinfo.rollNo','LIKE','%'.$query.'%')
            ->orwhere('dept.name','LIKE','%'.$query.'%')
            ->orwhere('batch.batch','LIKE','%'.$query.'%')->orwhere('stdinfo.rollNo','LIKE','%'.$query.'%')
            ->orwhere('dept.name','LIKE','%'.$query.'%')
            ->orwhere('batch.batch','LIKE','%'.$query.'%')
            ->get();

foreach ($std as  $value) {
  
  if($value->status==0)
  {
    array_push($res,$value);
  }

}
      return $res;      
}

}

