<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use App\StudentDetail;
use App\CommonCode;
use App\DegreeInfo;



class Certificate extends Model
{
   public static function getPInfo($id)
    {
    $data  =   DB::table('stdinfo')
         ->join('dept','stdinfo.deptId','=','dept.id')
         ->select('stdinfo.rollNo','stdinfo.fullname','stdinfo.fatherName','stdinfo.surname','dept.name','stdinfo.enrollmentNo','stdinfo.doa','stdinfo.gender')
          ->where('rollNo','=',$id)->first();
    
 return $data;

    }

  public static function getDegree($id)
  {
    $data = DB::table('documents')
            ->select('algD','algP','algT','dod','position','cgpa','dop','doe')
            ->where([
           ['rollNo','=',$id],
           ['status','=',1]
           ])->first();

       return $data;     
  } 
  
  public static function getSems($id)
  {
    $res     = CommonCode::getBatchDept($id);
  $batch     = $res->batch;
   $deptId   = $res->deptId;
    
 $semester  =  CommonCode::totalSems($deptId,$batch);

       $Totalsubj = [];        
       foreach ($semester as $value) {
  
  $TH  =     DB::table('courses')
              ->join('credit_mode','courses.courseCode','=','credit_mode.courseCode')
             ->where([
             ['credit_mode.batch',$batch],
             ['credit_mode.sems',$value->sems],
             ['courses.deptId',$deptId],
             ['credit_mode.IsTheory',1]
             ])
             ->count('IsTheory');

  $PR =      DB::table('courses')
              ->join('credit_mode','courses.courseCode','=','credit_mode.courseCode')
             ->where([
             ['credit_mode.batch',$batch],
             ['credit_mode.sems',$value->sems],
             ['courses.deptId',$deptId],
             ['credit_mode.IsPractical',1]
            ])
            ->count('IsPractical');
          $Totalsubj[$value->sems]= $TH+$PR;
            }

   return $Totalsubj;
   // dd($Totalsubj);       
  }   

  public static function getGrade($id)
  {
      $marksdata  =  StudentDetail::getMarks($id);
      $Thgrade = [];
      $Prgrade = [];
        foreach ($marksdata as $value) {
        if($value->IsTheory==1)
    {
     $Thgrade[$value->courseCode] = Certificate::grade($value->maxMarks,$value->markObtInTh);
        }
        if($value->IsPractical==1)
        {
     $Prgrade[$value->courseCode] = Certificate::grade($value->maximumMarks,$value->markObtInPr);
        }
      }
       $res = array($Thgrade,$Prgrade);
   
      return $res;
  }


  // get grade
  public static function grade($maxMarks,$obtMarks)
  {
    $gradeId = DB::table('gradingmarks')->select('gradeId')
           ->where([
           ['totalMarks','=',$maxMarks],
            ['minMarks','<=',$obtMarks],
            ['maxMarks','>=',$obtMarks],
           ])->first();
           
         $id= $gradeId->gradeId;

      $grade  = DB::table('gradingpoint')->select('grade')
           ->where('id',$id)->first();
        $grade = $grade->grade;
          
           return $grade;
  }

  public static function semsGpa($id)
  {
    $res     = CommonCode::getBatchDept($id);
  $batch     = $res->batch;
   $deptId   = $res->deptId;
  $semCreditHr = [];
  $qualityPoint = [];
  $semesterGpa = [];  
 $semester  =  CommonCode::totalSems($deptId,$batch);
 foreach ($semester as $value) {
  
  $semCreditHr[$value->sems] = Certificate::totalCreditHr($value->sems,$batch,$deptId);

 $qualityPoint[$value->sems] = Certificate::totalQualityPoint($value->sems,$id);
  $gpa = $qualityPoint[$value->sems]/$semCreditHr[$value->sems];

   $semesterGpa[$value->sems] = round($gpa,2);
 
 }
   return $semesterGpa;
  }


  // get each semester credith Hour
  public static function totalCreditHr($sems,$batch,$deptId)
  {
     // get total theory credit hour

    $creditTh = DB::table('credit_mode')
                ->join('courses','credit_mode.courseCode','=','courses.courseCode')
                ->where([
           ['courses.deptId','=',$deptId],
           ['credit_mode.batch','=',$batch],
           ['credit_mode.IsTheory','=',1],
           ['credit_mode.sems','=',$sems]
            ])
            ->sum('courses.creditHr');

 // get total theory credit hour

            $creditPr = DB::table('credit_mode')
                ->join('practicals','credit_mode.courseCode','=','practicals.courseCode')
                ->join('courses','credit_mode.courseCode','=','courses.courseCode')
                ->where([
         ['courses.deptId','=',$deptId],
         ['credit_mode.batch','=',$batch],
         ['credit_mode.IsPractical','=',1],
         ['credit_mode.sems','=',$sems]
       ])
       ->sum('practicals.creditHour');

  return $creditTh+$creditPr;
  }

// get each semester quality point

 public static function totalQualityPoint($semester,$id)
 {
   $marksdata  =  StudentDetail::getMarks($id);
   $ThQPoint = 0;
   $PrQPoint = 0;

   foreach ($marksdata as $marks) {
     if($marks->sems==$semester)
     {
    $ThQPoint  = DegreeInfo::qualityPoint($marks->maxMarks,$marks->creditHr,$marks->markObtInTh,$marks->IsTheory)+$ThQPoint;

    $PrQPoint = DegreeInfo::qualityPoint($marks->maximumMarks,$marks->creditHour,$marks->markObtInPr,$marks->IsPractical)+$PrQPoint;
    
     }
   }

return $ThQPoint+$PrQPoint;
 }

}
