<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Input;
use DB;

class Student extends Model
{
    public static function reteriveInfo($sort)

    {
    // reterive all students'info
      if(session('accInfo')[0]->role==1){
   
    $allstd = DB::table('stdinfo')
               ->join('dept','stdinfo.deptId','=','dept.id')
               ->join('batch','stdinfo.doa','=','batch.year')
               ->join('stdedustatus','stdedustatus.rollNo','=','stdinfo.rollNo')
                ->join('edusystem','edusystem.fromBatch','=','batch.batch')

               ->select('stdinfo.fullname','stdinfo.rollNo','dept.name','batch.batch','stdinfo.status')
                ->where('stdinfo.status',1)
                ->orWhere('stdinfo.status',-2)
                ->orWhere('stdinfo.status',-1)
               ->groupBy('stdedustatus.rollNo')
              ->havingRaw('SUM(stdedustatus.semsStatus)= 8')
              ->orderBy($sort,'asc')
              ->paginate(10);
             }
          else
          {

             $allstd = DB::table('stdinfo')
               ->join('dept','stdinfo.deptId','=','dept.id')
               ->join('batch','stdinfo.doa','=','batch.year')
               ->join('stdedustatus','stdedustatus.rollNo','=','stdinfo.rollNo')
                ->join('edusystem','edusystem.fromBatch','=','batch.batch')

               ->select('stdinfo.fullname','stdinfo.rollNo','dept.name','batch.batch','stdinfo.status')
                ->where('stdinfo.status',1)
                ->orWhere('stdinfo.status',-2)
               ->groupBy('stdedustatus.rollNo')
              ->havingRaw('SUM(stdedustatus.semsStatus)= 8')
              ->orderBy($sort,'asc')
              ->paginate(10);
   
          }    

       return $allstd;
    }

public static function getFewStd($filter)
{
$fewStd   = DB::table('stdinfo')
               ->join('dept','stdinfo.deptId','=','dept.id')
               ->join('batch','stdinfo.doa','=','batch.year')
               ->join('stdedustatus','stdedustatus.rollNo','=','stdinfo.rollNo')
                ->join('edusystem','edusystem.fromBatch','=','batch.batch')

               ->select('stdinfo.fullname','stdinfo.rollNo','dept.name','batch.batch','stdinfo.status')
                ->where('stdinfo.status','=',$filter)
               ->groupBy('stdedustatus.rollNo')
              ->havingRaw('SUM(stdedustatus.semsStatus)= 8')
              ->paginate(10);
   
   return $fewStd;           
}
    
 // getting list of verified student!   
public static function getVerified($filter)
{
  $std = DB::table('stdinfo')
             ->join('dept','stdinfo.deptId','=','dept.id')
               ->join('batch','stdinfo.doa','=','batch.year')
                ->join('edusystem','edusystem.fromBatch','=','batch.batch')
               ->select('stdinfo.fullname','stdinfo.rollNo','dept.name','batch.batch')
                ->where('stdinfo.status','=',0)
                 ->orderBy($filter,'asc')
                ->paginate(10);
  return $std;         
}

// getting list of recent verified

public static function getRecentVerified()
{
   $std = DB::table('stdinfo')
               ->join('dept','stdinfo.deptId','=','dept.id')
               ->join('batch','stdinfo.doa','=','batch.year')
                ->join('edusystem','edusystem.fromBatch','=','batch.batch')
                ->join('documents','stdinfo.rollNo','=','documents.rollNo')
               ->select('stdinfo.fullname','stdinfo.rollNo','dept.name','batch.batch')
                ->where([
                [ 'stdinfo.status','=',0],
                ['documents.status','=',1]
                ])
                 ->orderBy('documents.created_at','dsc')
                 ->limit(4)
                 ->get(); 
  return $std;         

}

public static function graduatingStd()
{
  $res = DB::table('stdinfo')
               ->join('dept','stdinfo.deptId','=','dept.id')
               ->join('batch','stdinfo.doa','=','batch.year')
               ->join('stdedustatus','stdedustatus.rollNo','=','stdinfo.rollNo')
                ->join('edusystem','edusystem.fromBatch','=','batch.batch')

               ->select('stdinfo.fullname','stdinfo.rollNo','dept.name','batch.batch','stdinfo.status')
                ->where('stdinfo.status',1)
               ->groupBy('stdedustatus.rollNo')
              ->havingRaw('SUM(stdedustatus.semsStatus)= 8')
              ->orderBy('stdedustatus.created_at','dsc')
               ->limit(4)
                 ->get();

       return $res;
}
} // end of class
