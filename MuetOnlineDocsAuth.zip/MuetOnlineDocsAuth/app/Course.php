<?php

namespace App;
use DB;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    public static function scopeGetCourseName($query,$courseCode){

    	 $res=DB::table('courses')->select('courseName')

    	 		->where('courseCode',$courseCode['code'])

    	 		->get();


    	return $res;

    }

}
