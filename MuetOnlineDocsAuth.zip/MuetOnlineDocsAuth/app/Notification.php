<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use App\Prevs;

class Notification extends Model
{

    //checked
    public static function scopeUpdateEmpInfo($query,$data){

    	$res=DB::table('notification')->insert([
            
            'staffid' => $data['staffid'],
            'id' =>  $data['id'],
            'colName' =>  $data['col'],
            'status' =>  0,
            'type' =>  1
        ]);

        return $res;
    }

    //checked
    public static function scopeCreateEmp($query,$data){

    	$res=DB::table('notification')->insert([
            
            'staffid' => $data['staffid'],
            'id' =>  $data['id'],
            'status' =>  1,
            'type' =>  1
        ]);

        return $res;
    }

    public static function lastCheckDate(){
        $res=DB::table('emp_notification')->insert([

            'staffid' => session('accInfo')[0]->id
        
        ]);

        return $res;
    }

    public static function scopeSetLastCheckDate($query,$data){
        $res=DB::table('emp_notification')->insert([

            'staffid' => $data['id']
        
        ]);

        return $res;
    }

    public static function scopeDelEmp($query,$data){

        $res=DB::table('notification')->insert([
            
            'staffid' => $data['staffid'],
            'id' =>  $data['id'],
            'status' =>  -1,
            'type' =>  1
        ]);

        return $res;
    }

    public static function scopePerDelEmp($query,$data){

        $res=DB::table('notification')->insert([
            
            'staffid' => $data['staffid'],
            'id' =>  $data['id'],
            'status' =>  -2,
            'type' =>  1
        ]);

        return $res;
    }

    public static function scopeActivateEmp($query,$data){

        $res=DB::table('notification')->insert([
            
            'staffid' => $data['staffid'],
            'id' =>  $data['id'],
            'status' =>  2,
            'type' =>  1
        ]);

        return $res;
    }

    public static function scopeGetUpdToMyAcc($query,$data){

        $res=DB::table('notification')

                ->join('staff','staff.id','=','notification.staffid')
                
                ->select('notification.staffid','notification.colName','notification.created_at','staff.pic','staff.name')
                
                ->where(['notification.status' => 0, 'notification.type' => 1, 'notification.id' => session('accInfo')[0]->id])
                
                ->where('notification.created_at','>',$data['date'])

                ->orderBy('notification.created_at', 'desc')
                
                ->get();

        return $res;
    }

    public static function getLastChecked(){

        $res=DB::table('emp_notification')
                ->select('checkDate')
                ->where(['staffid' => session('accInfo')[0]->id])
                ->orderBy('checkDate', 'desc')
                ->limit(1)
                ->get();

        return $res;   
    }

    public static function scopeGetCrEmpNotif($query,$data){

        $res=DB::table('notification')
                
                ->select('notification.srno','notification.id','notification.colName','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => 1, 'notification.type' => 1])
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')

                ->get();

        return $res;
    }

    public static function scopeGetDelEmpNotif($query,$data){

        $res=DB::table('notification')
                
                ->select('notification.srno','notification.id','notification.colName','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => -1, 'notification.type' => 1])
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')

                ->get();

        return $res;

    }

    public static function scopeGetEmpActivateNotif($query,$data){

        $res=DB::table('notification')
                
                ->select('notification.srno','notification.id','notification.colName','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => 2, 'notification.type' => 1])
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')

                ->get();

        return $res;

    }

    public static function scopeGetPerDelEmpNotif($query,$data){

        $res=DB::table('notification')
                
                ->select('notification.srno','notification.id','notification.colName','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => -2, 'notification.type' => 1])
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')

                ->get();

        return $res;

    }

    public static function scopeGetUpEmpNotif($query,$data){

        $res=DB::table('notification')
                
                ->select('notification.srno','notification.id','notification.colName','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => 0, 'notification.type' => 1])
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.id','!=',session('accInfo')[0]->id)

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function scopeUpStdInfoNotif($query,$data){

        //for updation of student information

        $res=DB::table('notification')
                
                ->select('notification.srno','notification.id','notification.colName','notification.created_at','notification.staffid','notification.comment')
                
                ->where(['notification.status' => 0, 'notification.type' => 0])
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function scopeVerStdNotif($query,$data){

        // for verfied student

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => 2, 'notification.type' => 0])
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function scopeRepStdNotif($query,$data){

        // for reporting student

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid','notification.comment')
                
                ->where(['notification.status' => -2, 'notification.type' => 0])
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function scopeDelStdNotif($query,$data){

        // for deleting student

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => -1, 'notification.type' => 0])

                ->where('notification.colName','=','status')
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function scopePerDelStdNotif($query,$data){

        // for deleting student

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => -3, 'notification.type' => 0])

                ->where('notification.colName','=','status')
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function scopeResStdNotif($query,$data){

        // for deleting student

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => -1, 'notification.type' => 0])

                ->where('notification.colName','=',null)
                
                ->where('notification.created_at','>',$data['date'])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }


    public static function getAllMyNotif(){

        $res=DB::table('notification')

                ->join('staff','staff.id','=','notification.staffid')
                
                ->select('notification.staffid','notification.colName','notification.created_at','staff.pic','staff.name')
                
                ->where(['notification.status' => 0, 'notification.type' => 1, 'notification.id' => session('accInfo')[0]->id])

                ->orderBy('notification.created_at', 'desc')
                
                ->get();

        return $res;
    
    }

    public static function getAllCrEmpNotif(){

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => 1, 'notification.type' => 1])
                
                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')

                ->get();

        return $res;
    }

    public static function getAllDelEmpNotif(){

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => -1, 'notification.type' => 1])
                
                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function getAllActEmpNotif(){

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => 2, 'notification.type' => 1])
                
                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }


    public static function getAllPerDelEmpNotif(){

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => -2, 'notification.type' => 1])
                
                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function getAllUpEmpNotif(){

        $res=DB::table('notification')
                
                ->select('notification.id','notification.colName','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => 0, 'notification.type' => 1])
                
                ->where('notification.id','!=',session('accInfo')[0]->id)

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

     public static function getAllupStdInfoNotif(){

        $res=DB::table('notification')
                
                ->select('notification.srno','notification.id','notification.colName','notification.created_at','notification.staffid','notification.comment')
                
                ->where(['notification.status' => 0, 'notification.type' => 0])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function getAllVerStd(){

        // for verfied student

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => 2, 'notification.type' => 0])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function getAllRepStd(){

        // for reporting student

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid','notification.comment')
                
                ->where(['notification.status' => -2, 'notification.type' => 0])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function getAllDelStd(){

        // for deleting student

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => -1, 'notification.type' => 0])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                 ->where('notification.colName','=','status')

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function getAllPerDelStd(){

        // for deleting student

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => -3, 'notification.type' => 0])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                 ->where('notification.colName','=','status')

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }

    public static function getAllResStd(){

        // for deleting student

        $res=DB::table('notification')
                
                ->select('notification.id','notification.created_at','notification.staffid')
                
                ->where(['notification.status' => -1, 'notification.type' => 0])

                ->where('notification.staffid','!=',session('accInfo')[0]->id)

                 ->where('notification.colName','=',null)

                ->orderBy('created_at', 'desc')
                
                ->get();

        return $res;

    }



}
