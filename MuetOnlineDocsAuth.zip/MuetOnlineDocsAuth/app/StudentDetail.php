<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use App\CommonCode;


class StudentDetail extends Model
{
      // reterive student info
    public static function reterive($id)
    {
      $std = DB::table('stdinfo')
             ->select('rollNo','fullname','fatherName','addr','cnic','dob','country','province','domicile','email','mbNo','enrollmentNo','deptId','pic','doa','gender','surname')
              ->where('rollNo','=',$id)->first();
        
      return $std;
    }

    public static function scopeGetData($query, $data){
      
      $std = DB::table('stdinfo')

              ->join('dept','dept.id','=','stdinfo.deptId')

              ->select('stdinfo.rollNo','stdinfo.fullname','stdinfo.fatherName','stdinfo.addr','stdinfo.cnic','stdinfo.dob','stdinfo.country','stdinfo.province','stdinfo.domicile','stdinfo.email','stdinfo.mbNo','stdinfo.enrollmentNo','stdinfo.pic','stdinfo.programme','stdinfo.doa','stdinfo.currentPosition','stdinfo.gender','stdinfo.surname','dept.name as dept')

              ->where('rollNo','=',$data['id'])->first();
      
      return $std;

    }
  

    // get Student Marks

   public static function getMarks($id)

   {
   
     //  get student batch
       $res   = CommonCode::getBatchDept($id);
       $batch   = $res->batch;
             
       // now I can fetch courses,maxmarks and obtainMarks with the help of batch!

    $marksdata = DB::table('credit_mode')
                ->join('courses','credit_mode.courseCode','=','courses.courseCode')
               ->leftjoin('practicals','credit_mode.courseCode','=',
               'practicals.courseCode')
              ->join('stdexaminfo','credit_mode.courseCode','=','stdexaminfo.courseId')
             ->where([
            ['stdexaminfo.rollNo','=',$id],
            ['credit_mode.batch',$batch]
             ])
          
            ->select('stdexaminfo.rollNo','courses.courseName',
              'credit_mode.courseCode',
              'courses.maxMarks',
              'stdexaminfo.markObtInTh',
               'practicals.maximumMarks',
              'stdexaminfo.markObtInPr','credit_mode.IsTheory','credit_mode.IsPractical','credit_mode.sems','courses.creditHr','practicals.creditHour','credit_mode.sems')
               ->orderBy('credit_mode.sems','asc')
               ->get();
   
          
           return $marksdata;
       //dd($marksdata);        
          
   }

   public static function getEduSystem($id)
   {
    $system = DB::table('stdinfo')
                ->join('batch','stdinfo.doa','batch.year')
                ->join('edusystem','batch.batch','edusystem.fromBatch')
                ->select('edusystem.name')
                ->where('rollNo',$id)->first();
        return $system;   
   }

   public static function getPloProgress($rollNo)
   { 
      $totalmarks = array();
      $obtainmarks = array();
      $percentage = array();
    
     // first get the no of plo for student
     
     $ploId = DB::table('std_plo')->distinct('ploId')
              ->select('ploId')
              ->where('rollNo',$rollNo)
             ->get();
       
    // now get the obtained marks of student in plo
      foreach ($ploId as $id) {
        
  $obtmarks = DB::table('std_plo')
                ->where([
                 ['rollNo','=',$rollNo],
                 ['ploId','=',$id->ploId],
                ])
                ->sum('marksObt');
              array_push($obtainmarks,$obtmarks);
      }

      // now get the total marks of plo  
         
         foreach($ploId as $id)
    {
     $totmarks = DB::table('clo')
              ->join('std_plo','clo.id','=','std_plo.cloId')
              ->where([
              ['rollNo','=',$rollNo],
              ['ploId','=',$id->ploId],
              ])
              ->sum('clo.totalMarks');

              array_push($totalmarks, $totmarks);
    }

    // now calculate the percentage
     $length = count($totalmarks);

      for($i=0;$i<$length;$i++)
    {
    $perc = round(($obtainmarks[$i]/$totalmarks[$i])*100,2); 
     
      array_push($percentage,$perc);
    } 

    return $percentage;
    
   }


// get all dept
      public static function getDept()
      {
        $all = DB::table('dept')
               ->select('id','name')->get();

          return $all;
      }

   // Added for Activity Logs
public static function getLogInfo($id)
    {
      $std = DB::table('stdinfo')
              ->select('rollNo','fullName','status')
              ->where('rollNo','=',$id)->get();
        
        return $std;
    }   
   
}