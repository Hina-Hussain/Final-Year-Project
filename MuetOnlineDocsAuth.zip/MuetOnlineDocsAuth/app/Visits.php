<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Visits extends Model
{
   public static function getVisits()
    {
   $sms =	DB::table('visits')->where('medium','=',0)
    	->count('medium');

    $web = DB::table('visits')->where('medium','=',1)
    	->count('medium');	
    
     $mobile = DB::table('visits')->where('medium','=',2)
    	->count('medium');
  
 

  $res = array('sms'=>$sms,'web'=>$web,'mobile'=>$mobile);
  return $res;
   }

   public static function certificateSearch()
   {
   	$degree = DB::table('visits')->where('docType','=',1)
   	           ->count('docType'); 

   	$pass = DB::table('visits')->where('docType','=',2)
   	           ->count('docType'); 

   $trans = DB::table('visits')->where('docType','=',3)
   	           ->count('docType');

   	$res = array("degree"=>$degree,"pass"=>$pass,"trans"=>$trans);
   	return $res;                       
   } 

}
