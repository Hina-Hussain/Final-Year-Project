<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Prevs;
use App\Notification;
use App\Course;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //for restricting the elements emp can see in the ui based on prev
        
        view()->composer(['layouts.layout'],function($view){
    
            $prevs= Prevs::rolePrevs(['id' => session('accInfo')[0]->role]); 
            $result=[];

            foreach($prevs as $prev){

                if($prev->id ==13 || $prev->id ==8 || $prev->id ==9 || $prev->id ==10){

                    $result['emp']=true;
                    
                }

                if( $prev->id ==11 || $prev->id ==5 || $prev->id ==6 || $prev->id ==7 ){

                    $result['std']=true;
                    
                }

                if($prev->id ==1 || $prev->id ==2 || $prev->id ==3 || $prev->id ==4 || $prev->id==12){

                    $result['vstd']=true;
                    
                }

                if($prev->id == 8 || $prev->id == 9){
                     $result['acc_rights']=true;
                }
            
            }
    
            $view->with('result',$result);
            
        });

        view()->composer(['dashboard.employees','students.manageStudent','students.verifiedStudent'],function($view){
            
            // checking previleges of the employee online...
            $previleges=Prevs::rolePrevs(['id' => session('accInfo')[0]->role]);

            $content=[];

            foreach($previleges as $prev){
                
                if($prev->id == 8){
                        
                    $content['add-emp']=true;

                }

                if($prev->id == 9){

                    $content['edit-emp']=true;
                        
                }

                if($prev->id == 10){

                    $content['del-emp']=true;
                        
                }

                if($prev->id == 13){

                    $content['view-emp']=true;
                        
                }
               
                 if($prev->id==11){
            
               $content['del-std'] = true;
                }
        
        if($prev->id==5 || $prev->id==6 || $prev->id==7)
        {
          $content['edit-std'] = true;
        }

        if($prev->id==1){

            $content['view-std'] = true;
        }
        if($prev->id==12){

            $content['report-std'] = true;
        }
        if($prev->id==2 || $prev->id==3 || $prev->id==4){

            $content['certificate'] = true;
        }

            }
        
                $view->with('content',$content);
            
        });

        // Added By hina

       /* view()->composer(['students.manageStudent'],function($view){

          // checking previleges of the employee online...
            $previleges=Prevs::rolePrevs(['id' => session('accInfo')[0]->role]);

            $content1 = [];

            foreach($previleges as $prev){

          if($prev->id==11){
            $content1['del-std'] = true;
                }
        if($prev->id==5 || $prev->id==6 || $prev->id==7)
        {
          $content1['edit-std'] = true;
        }
        
         }
        $view->with('content1',$content1);

        });

*/

        view()->composer(['layouts.header'],function($view){

            $res=Notification::getLastChecked();
            
            //changes made to active account by someone else
            $res2=Notification::getUpdToMyAcc([ 'date' => $res[0]->checkDate ]);

            if(session('accInfo')[0]->role!=1){

                $res=['myNotif'=> $res2];

            }else{

                $res3=Notification::getCrEmpNotif([ 'date' => $res[0]->checkDate ]);

                $res4=Notification::getUpEmpNotif([ 'date' => $res[0]->checkDate ]);

                $res5=Notification::getDelEmpNotif([ 'date' => $res[0]->checkDate ]);

                $perDel=Notification::getPerDelEmpNotif([ 'date' => $res[0]->checkDate ]);

                $activeNotif=Notification::getEmpActivateNotif([ 'date' => $res[0]->checkDate ]);

                // updated std info

                $res6=Notification::upStdInfoNotif([ 'date' => $res[0]->checkDate ]);

                $courseNames=[];
                
                foreach($res6 as $updation){

                    if($updation->comment !=null){

                        if(count($courseNames)==0 || !(array_key_exists($updation->comment, $courseNames))){

                            $name=Course::getCourseName([ 'code' => $updation->comment]);

                            $courseNames[$updation->comment] = $name[0]->courseName;

                        }
                    }

                }

                $res7=Notification::verStdNotif([ 'date' => $res[0]->checkDate ]);

                $res8=Notification::repStdNotif([ 'date' => $res[0]->checkDate ]);

                $res9=Notification::delStdNotif([ 'date' => $res[0]->checkDate ]);

                $resStd=Notification::resStdNotif([ 'date' => $res[0]->checkDate ]);

                $perDelStd=Notification::perDelStdNotif([ 'date' => $res[0]->checkDate ]);

                $res=[  'myNotif'=> $res2,
                        'CrEmpNotif' => $res3, 
                        'UpEmpNotif' => $res4, 
                        'DelEmpNotif' => $res5,
                        'ActiveEmpNotif' =>$activeNotif,
                        'PerDelEmpNotif' => $perDel, 
                        'UpStdInfo' => $res6,
                        'courseName' => $courseNames, 
                        'VerStd' => $res7, 
                        'RepStd' => $res8, 
                        'DelStd' => $res9,
                        'ResStd' => $resStd,
                        'PerDelStd' => $perDelStd
                    ];

            }

            $view->with('result',$res);

        });

    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
