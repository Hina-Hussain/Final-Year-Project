<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Search;
use App\Employees;

class SearchController extends Controller
{

  public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);

        $this->middleware('authorized')->only(['index','searchAjax','search']);
        

        $this->middleware('ajax')->only(['searchAjax','verifiedSearchAjax','stdSearchAjax']);
    }

    public function index(){

      //when the form is not submitted rather autocomplete item is selected by the user

        if(request('val')==null){

            return redirect('/dashboard/employees');
            
        }

        $res=json_decode (request ('val'));

        if(! is_array($res)){

            return redirect('/dashboard/employees');

        }
      
        if($res==null){

            session()->flash('noResult','0 results found!');

            return redirect('/dashboard/employees');

        }

        $search=false;

        return view('dashboard.employees',compact("res","search"));

    }

    public function searchAjax(){

        if(request('q')==null){

            return redirect('/dashboard/employees');
        }

      $res=Search::searchEmp(['val' => request('q')]);

      return response()->json($res);
    }

    public function search(Request $req){

        $res=$this->validate($req, [
            'search' => 'required' 
        ]);
        
        //search using form

        $res=Search::searchEmp(['val' => request('search')]);

        $search=false;

        if(count($res)==0){

            session()->flash('danger','0 results found!');

            return redirect('/dashboard/employees');
        }

        return view('dashboard.employees',compact("res","search"));

    }

    // serach for students Added By Hina

    public function searchStd(Request $request)
    {
      $results = $this->validate($request,[
      'search'=>'required'
      ]);

    $results = Search::searchStudent(request('search'));
    $search = false;
  
      if(count($results)==0)
      {
        session()->flash('anyerror','0 results found!');
        return redirect('/dashboard/students');
      }
      return view('students.manageStudent',compact('results','search'));
    }


public function stdIndex(Request $request)
{
  
        if(request('val')==null)
        {
         
           return redirect('/dashboard/students');
        }

         $results = json_decode(request('val'));
      
     if(! is_array($results))

       {
        session()->flash('anyerror','0 results found!');
        return redirect('/dashboard/students');
       } 

    $search = false;
  return view('students.manageStudent',compact('results','search'));
  
}


public function stdSearchAjax()
{
    if(request('q')==null)
    {
        return redirect('/dashboard/students');
    }

$results = Search::searchStudent(request('q'));


return response()->json($results);
}


/* 
    verified student searching!*/

public function verifiedSearchAjax()
{
     if(request('q')==null)
    {
        return redirect('/dashboard/verifiedStudents');
    }

$results = Search::searchVerified(request('q'));


return response()->json($results);
}

public function verifiedStd(Request $request)
{ 
  $results = $this->validate($request,[
      'search'=>'required'
      ]);

    $results = Search::searchVerified(request('search'));
    $search = false;
  
      if(count($results)==0)
      {
        session()->flash('anyerror','0 results found!');
        return redirect('/dashboard/verifiedStudents');
      }
      return view('students.verifiedStudent',compact('results','search'));
}


public function verifiedIndex()
{
     if(request('val')==null)
        {
         
        return redirect('/dashboard/verifiedStudents');
        }

         $results = json_decode(request('val'));
       

       if($results==null)
       {
        session()->flash('anyerror','0 results Found!');
        return redirect('/dashboard/verifiedStudents');
       } 

    $search = false;
  return view('students.verifiedStudent',compact('results','search'));
  
}
}
