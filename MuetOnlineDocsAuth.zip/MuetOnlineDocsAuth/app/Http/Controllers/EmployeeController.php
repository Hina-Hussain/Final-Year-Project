<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employees;
use DB;
use App\CRUD;
use App\Roles;
use App\Prevs;
use App\Search;
use Hash;
use App\notification;



class EmployeeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);

        $this->middleware('authorized')->except([]);

        $this->middleware('ajax')->only(['checkRoleName','checkEmail','checkId','create','getData','deleteModal','restoreModal']);

    }

    public function index(){

        //employee info is here 

        if(request('q')==null || request('q')=='roles' || request('q')=='all' ){

            $res=Employees::employees(['q'=> 'role.id']);

            $search=true;
                
        }else if(request('q')=='staffid'){

            $res=Employees::employees(['q'=> 'staffid']);

            $search=true;

        }else if(request('q')=='deptId'){

            $res=Employees::employees(['q'=> 'staff.deptId']);

            $search=true;

        }else if(request('q')=='activated'){

            $res=Employees::employeesFilt(['status'=> 'activated']);

            $search=true;

        }else if(request('q')=='deactivated'){
            
            if(session('accInfo')[0]->role==1)
            {$res=Employees::employeesFilt(['status'=> 'deactivated']);}
           else
            {abort(404);}

            $search=true;

        }else{
            return redirect('/dashboard/employees');
        }

        return view('dashboard.employees',compact("res","search"));

    }

    public function destroy(Request $req){

        if($req->id==null){
            return redirect('/dashboard/employees');
        }

         if($req->status!=0){

            $res=Employees::empRole(['id'=>$req->id]);

            if($res==1){

                if(session('accInfo')[0]->role==1){

                    EmployeeController::delete();

                }else{
                    session()->flash('danger','You can not delete the super admin!');
                }

            }else if($res>1){

                EmployeeController::delete();
            }
            

        }else{

            DB::transaction(function () {

                $res=Employees::perDelEmp(['id'=> request('id')]);

                if ($res==1) {

                    //deletion successfull

                    Notification::perDelEmp(['staffid' => session('accInfo')[0]->id,
                        'id' => request('id')]);

                     //insert into crud about the updation....

                     $res=CRUD::perEmpDelete(['id'=> request('id')]);

                     if ($res) {
                         
                         //insertion successfull

                        session()->flash('success','Employee has been permanently deleted!');

                     }else{

                        //insetion unsuccessfull 

                        session()->flash('danger','Problem deleting employee!');

                        //rollback query the change as crud was not updated successfully

                     }

                }else{

                     session()->flash('danger','Problem deleting employee!');
                }

            });

        }

        return redirect('/dashboard/employees');
    }

    public static function delete(){
        DB::transaction(function () {

                $res=Employees::deleteEmp(['id'=> request('id')]);

                if ($res==1) {

                    //deletion successfull

                    Notification::delEmp(['staffid' => session('accInfo')[0]->id,
                        'id' => request('id')]);

                     //insert into crud about the updation....

                     $res=CRUD::empDelete(['id'=> request('id')]);

                     if ($res) {
                         
                         //insertion successfull

                        session()->flash('success','Employee account deactivated successfully!');

                     }else{

                        //insetion unsuccessfull 

                        session()->flash('danger','Problem deleting employee!');

                        //rollback query the change as crud was not updated successfully

                     }

                }else{

                     session()->flash('danger','Problem deleting employee!');
                }
            });
    }

    public function getData(){

        if(request('q')==null){

            return redirect('/dashboard/employees');

        }

        $r=Employees::getData(['id'=>request('q')]);

        $res2=Roles::getRoles();

        $res5=array();//final roles

        $res3=Prevs::prevs();

        $res4=Prevs::rolePrevs(['id' => session('accInfo')[0]->role]);

        $prevs=array();

        foreach ($res4 as  $value) {
            
            array_push($prevs,$value->id);
        }

        foreach($res2 as $value1){

            $roles=array();

            foreach ($res3 as $value2) {
                
                if($value1->id==$value2->id){

                    array_push($roles,$value2->prevId);
                }
            }

            if(array_diff($roles,$prevs)==[] && $value1->id!=$r[0]->roleId){
                array_push($res5,$value1);
            }
        }

        $res=array('empDetails' => $r, 'roles' => $res5, 'rolePrevs' => $res3,'prevs'=>$res4);

        return view('modals.edit_emp',compact("res"));
    }

    public function viewData(Request $req){

        if (request('id')!=null) {

            $res=EmployeeController::getEmpProfile(request('id'));
            $id=request('id');
            $status=request('status');
            return view('employees.view_data',compact("res","id","status"));

        }

        if(request('q')==null){
            return redirect('/dashboard/employees');
        }

        if(!$req->ajax()){

            abort(404);
            
        }
        
        $res=EmployeeController::getEmpProfile(request('q'));

        $status=request('status');

        return view('modals.view_emp',compact("res","status"));
    }

    public static function getEmpProfile($id){
        
        $res=Employees::getDetData(['id'=>$id,'status' => request('status')]);

        $res2=Prevs::rolePrevs(['id'=>$res[0]->roleId]);

        $res3=CRUD::crudOp(['id' =>$id]);

        $empCr=array();
        $empUp=array();
        $empDel=array();
        $roleCr=array();
        $stdUp=array();
        $stdDel=array();
        $stdVer=array();
        $stdRep=array();
        

        foreach ($res3 as $value) {

            if($value->id != $id){

                if ($value->status==1) {
                    
                    if ($value->tableName=="empaccountsinfo" || $value->tableName=="staff"){

                        array_push($empCr, $value);

                    }else if ($value->tableName=="role") {

                        array_push($roleCr, $value);

                    }
                
                }else if($value->status==0){

                    if ($value->tableName=="empaccountsinfo" || $value->tableName=="staff"){

                        if($value->colName=="status"){

                            array_push($empDel, $value);

                        }else{

                            array_push($empUp, $value);

                        }
                    
                    }else if($value->tableName=="stdinfo" || $value->tableName=="stdexaminfo"){

                        if($value->chVal==-1){

                            // deletion

                            array_push($stdDel, $value);


                        }else if($value->chVal==-2){

                            // reported

                            array_push($stdRep, $value);

                        }else{

                            //updation

                            array_push($stdUp, $value);

                        }

                    }

                }else if($value->status==2){

                    // verified

                    array_push($stdVer, $value);

                }
            }
        }

        $crud=['empCr' => count($empCr), 'roleCr' => count($roleCr), 'empUp' => count($empUp), 'stdUp' => count($stdUp), 'empDel' => count($empDel), 'stdDel' => count($stdDel), 'stdVer' => count($stdVer), 'stdRep' => count($stdRep)];

        $result=array('empDetails' => $res, 'rolePrevs' => $res2, 'crud' => $crud);

        return $result;

    }

    public function checkRoleName(){

        if(request('q')==null){
            return redirect('/dashboard/employees');
        }

        $res=Roles::exist(['val'=>request('q')]);

        return response()->json($res);
    }

    public function checkEmail(){
        
        if(request('q')==null){
            return redirect('/dashboard/employees');
        }

        return response()->json(Employees::existByEmail(['email'=>request('q')]));
    }

    public function checkId(){

        if(request('q')==null){
            return redirect('/dashboard/employees');
        }
        return response()->json(Employees::existId(['id'=>request('q')]));
    }

    public function saveChanges(Request $req){

        session(['empe' => 0,'empp'=>0,'empimg'=>0,'emprole'=>0]);

        //dd($req->all());

       if($req->password!="" && $req->password_confirmation!=""){
        
            //password
            
            $res=$this->validate($req, [
            'password' => 'required|confirmed|min:6' 
            ]);

            EmployeeController::passwordValidation();

            //update pass
            DB::transaction(function () {
            
                $old=Employees::passById(['id'=>request('id')]);


                if (Hash::check(request('password'),$old[0]->pass)) {

                    //if password is the same as the old so no need to change the password

                    session()->flash('info',"Password was not updated as you entered the same password!");


                }else{

                   $res=Employees::updatePass(['pass'=>request('password'),'id'=>request('id')]); 

                   //notification

                   Notification::updateEmpInfo(['staffid'=>session('accInfo')[0]->id,'id'=>request('id'),'col'=>'pass(password)']);

                  $res2=CRUD::passReset(['staffid'=>session('accInfo')[0]->id,'id'=>request('id'),'old' => $old[0]->pass,'new' => request('password')]);
                  
                    $empp=session('empp')+1;
                    session(['empp' => $empp]);

                    
                }

            });

       }

       if($req->email!=$req->prev_email){

            //email

            DB::transaction(function () {

                $res=Employees::updateEmail(['email'=>request('email'),'id'=>request('id')]);

                //notification

               Notification::updateEmpInfo(['staffid'=>session('accInfo')[0]->id,'id'=>request('id'),'col'=>'email']);

                if ($res=='-1') {

                    //email invalid

                }else{

                    if ($res==1) {

                        $res2=CRUD::updateEmail(['staffid'=>session('accInfo')[0]->id,'id'=>request('id'),'old' => request('prev_email'),'new' => request('email')]);

                        $empe=session('empe')+1;

                        session(['empe' => $empe]);

                    }
                    
                }
            });
       }

       if($req->image!=null){

            //pic

            $res=$this->validate($req, [
                'pic'  => 'image:jpeg,jpg,png | max:64'
            ]);

            DB::transaction(function () { 

                //old pic
                $pic=Employees::pic(['id'   => request('id') ]);

                //checking if request has pic

                if (request()->hasFile('image')) {
                    
                    //storing file to the directory

                    request()->file('image')->store('public/uploads/staff');

                    //storing the file uri to the database

                    $file_name = request()->file('image')->hashName();


                    //storing the file uri to the database

                    $res=Employees::setPic(['id'=> request('id') , 'pic'=> $file_name]);


                    if($res!=1){

                        // error saving picture

                    }else{
                        

                //notification

               Notification::updateEmpInfo(['staffid'=>session('accInfo')[0]->id,'id'=>request('id'),'col'=>'pic(picture)']);

                        if($pic!=null ){
                            
                            //CRUD entry because emp pic is updated

                            $res2=CRUD::staffPic(['staffid' => session('accInfo')[0]->id, 'id' =>  request('id'),'new'=> $file_name,'old' => $pic]);
                                
                        }else{

                            //CRUD entry because emp pic is not updated and the prev pic value was null

                            $res2=CRUD::staffPic(['staffid' => session('accInfo')[0]->id, 'id' => request('id') ,'new'=> $file_name,'old' => "null"]);

                                
                        }
 
                        $empimg=session('empimg')+1;

                        session(['empimg' => $empimg]);

                    }
                }

            });

       }

       if(request('select')!=request('prev_select')){

            if(session('accInfo')[0]->role!=1){

                if(request('prev_select')==1){

                    session()->flash('danger',"You cannot update super admin's role only a super admin can do that!");

                }else if(request('select')=='Custom role'){
                    
                    $res=$this->validate($req, [
                        'role-name'        => 'required',
                        'role-desc'     => 'required',
                    ]);
                    EmployeeController::assignCustomRole(0);

                }else{

                    EmployeeController::editEmpAcc();

                }


            }else{

                if(request('select')=='Custom role'){

                    $res=$this->validate($req, [
                        'role-name'        => 'required',
                        'role-desc'     => 'required',
                    ]);
                    EmployeeController::assignCustomRole(0);

                }else{

                    EmployeeController::editEmpAcc();

                }

            }
       }


       $changes=session('empp')+session('empe')+session('empimg')+session('emprole');
       if($changes>1){

            session()->flash('success','Changes have been made to the account with employee id '.request('id').'!');

       }else if($changes==1){

            if(session('empp')==1){

                session()->flash('success','Password has been changed of the account with employee id '.request('id').'!');
            }

            else if(session('empe')==1){

                session()->flash('success','Email has been changed of the account with employee id '.request('id').'!');
            }

            else if(session('empimg')==1){

                session()->flash('success','Picture has been changed of the account with employee id '.request('id').'!');
            }

            else if(session('emprole')==1){

                session()->flash('success','Rights has been changed of the account with employee id '.request('id').'!');
            }

       }else{

            session()->flash('info',"No updations were made to employee account as you did not make changes!");

       }

      return redirect('/dashboard/employees');
    }

    public static function assignCustomRole($type){

            DB::transaction(function ()  use ($type){   

                $newRoleId=  Roles::getRoles()->last()->id;

                $newRoleId++;

                $prevs= Prevs::getAllPrevs();

                $prevsTot= count($prevs);

                $roleprevs= array();
                
                for($i=0;$i<$prevsTot;$i++){

                    if(request($prevs[$i]->id)==1){    
                        array_push($roleprevs,$prevs[$i]->id);
                    }

                }

                if(count($roleprevs)>0){

                    //checking role name is unique
                    
                    $res1=Roles::getRoles();
                
                    $count=0;

                    foreach ($res1 as $value) {

                        if(request('role-name')==$value->name){

                            $count=1;
                            break;
                        }    
                    } 

                     if($count==0){
                        
                        //create role as role name is unique

                        $res=Roles::roleCreate(['id' => $newRoleId, 'name' => request('role-name'), 'desc' => request('role-desc')]);


                        if($res){

                            //CRUD entry because new role is created

                            $res2=CRUD::roleCreate(['staffid' => session('accInfo')[0]->id, 'id' => $newRoleId ]);

                            $res=Prevs::assignRolePrev(['id' => $newRoleId, 'roleprevs' => $roleprevs]);

                            if($res){

                                if($type==0){
                                    //now update employee role

                                    $res=Employees::updateRole(['id'=>request('id'),'role'=> $newRoleId]);

                                    if ($res==0) {

                                        //same role

                                    }else{

                                //notification

                                Notification::updateEmpInfo(['staffid'=>session('accInfo')[0]->id,'id'=>request('id'),'col'=>'role']);


                                        if ($res==1) {

                                            $res2=CRUD::updateRole(['staffid'=>session('accInfo')[0]->id,'id'=>request('id'),'old' => request('prev_select'),'new' => $newRoleId]);

                                            $emprole=session('emprole')+1;

                                            session(['emprole' => $emprole]);

                                        }
                                        
                                    }
                                }else if($type==1){

                                    EmployeeController::passwordValidation();

                                    //create logic

                                    $res=Employees::empCreate(['id' => request('staffid'),'email' => request('email'), 'pass' => request('password'),'role' => $newRoleId]);

                                    //dd($res);

                                    if($res){

                                        //notification

                                        Notification::createEmp(['staffid'=> session('accInfo')[0]->id, 'id'=> request('staffid')]);

                                        Notification::setLastCheckDate(['id' => request('staffid')]);

                                        $res=CRUD::empCreate(['staffid' => session('accInfo')[0]->id, 'id' => request('staffid') ]);

                                        session()->flash('success','Employee created successfully - Id: '.request('staffid'));

                                    }else{
                                        
                                        session()->flash('danger','Could not create employee account try again!');
                                    }

                                }
                            }

                        }

                    }

                       
                }

            });
    }

    public static function editEmpAcc(){
        
        DB::transaction(function () {

                    $res=Employees::updateRole(['id'=>request('id'),'role'=> request('select')]);

                    if ($res==0) {

                        //same role

                    }else{

                        if ($res==1) {

                            //notification

               Notification::updateEmpInfo(['staffid'=>session('accInfo')[0]->id,'id'=>request('id'),'col'=>'role']);

                            $res2=CRUD::updateRole(['staffid'=>session('accInfo')[0]->id,'id'=>request('id'),'old' => request('prev_select'),'new' => request('select')]);

                            $emprole=session('emprole')+1;

                            session(['emprole' => $emprole]);

                        }
                        
                    }
                });
    }

    
    public function create(){

        $res2=Roles::getRoles();

        $res3=Prevs::prevs();

        $res4=Prevs::rolePrevs(['id' => session('accInfo')[0]->role]);

        $res5=array();//final roles according to the employees role as we want to ensure that employee can only assigns role that are equal to his previleges or less than them not the higher ones like a student can not assign any other employee super admin previlege

        $prevs=array();

        foreach ($res4 as  $value) {
            
            array_push($prevs,$value->id);
        }

        //prevs will have only the id of the res4 result which returns previlege of the active employee

        //next we are going to fetch previlege id of each role and compare them with prev if there is no differnce it will be added to $res5 'the final roles' 

        foreach($res2 as $value1){
            
            $roles=array();
            
            foreach ($res3 as $value2) {
                
                if($value1->id==$value2->id){

                    array_push($roles,$value2->prevId);
                }
            }

            if(array_diff($roles,$prevs)==[]){
                array_push($res5,$value1);
            }
        }


        $res=array('roles' => $res5, 'rolePrevs' => $res3, 'prevs'=>$res4);

        return view('modals.insert_emp',compact('res'));

    }

    public function store(Request $req){

        $res=$this->validate($req, [
            'staffid' => 'required',
            'email' => 'required|email',
            'password' => 'required|confirmed|min:6',
            'select' => 'required'
        ]);

        //image not null
         if($req->image!=null){                 

                //pic

                // dd('image');

                $res=$this->validate($req, [
                    'image'  => 'image:jpeg,jpg,png | max:64'
                ]);

                DB::transaction(function () { 

                    //old pic
                    $pic=Employees::pic(['id'   => request('staffid') ]);

                    //checking if request has pic

                    if (request()->hasFile('image')) {
                        
                        //storing file to the directory

                        request()->file('image')->store('public/uploads/staff');

                        //storing the file uri to the database

                        $file_name = request()->file('image')->hashName();


                        //storing the file uri to the database

                        $res=Employees::setPic(['id'=> request('staffid') , 'pic'=> $file_name]);


                        if($res!=1){

                            // error saving picture

                            session()->flash('danger','Error saving employee picture!');
                            
                        }else{

                            //notification

                            Notification::updateEmpInfo(['staffid'=> session('accInfo')[0]->id, 'id'=> request('staffid'), 'col'=> 'pic(picture)']);

                            
                            if($pic!=null ){
                                
                                //CRUD entry because emp pic is updated

                                $res2=CRUD::staffPic(['staffid' => session('accInfo')[0]->id, 'id' =>  request('staffid'),'new'=> $file_name,'old' => $pic]);

                                    
                            }else{

                                //CRUD entry because emp pic is not updated and the prev pic value was null

                                $res2=CRUD::staffPic(['staffid' => session('accInfo')[0]->id, 'id' => request('staffid') ,'new'=> $file_name,'old' => "null"]);
                                    
                            }
     
                            
                        }
                    }

                });

            }

        if($req->select=='Custom role'){
            
            //role has to be created before creating employee

            //dd($req->all());
            $res=$this->validate($req, [
                'role-name' => 'required',
                'role-desc' => 'required'
            ]);

            EmployeeController::assignCustomRole(1);

            
        }else{

            if(request('select')==1){

                if(session('accInfo')[0]->role==1){

                    EmployeeController::createEmpAcc(0);

                    session()->flash('success','Employee Account created successfully with Staff id: '.request('staffid').'!');

                }else{

                    EmployeeController::createEmpAcc(1);

                     session()->flash('info','Only a super admin can create a super admin account so reviewer role was assigned to this employee account!');

                }
            }else{

                EmployeeController::createEmpAcc(0);

                session()->flash('success','Employee Account created successfully with Staff id: '.request('staffid').'!');
                  
            }
        }

        return redirect('/dashboard/employees');
    }

    public static function passwordValidation(){
        $countNum=0;
        $countUppercase=0;
        $countLowercase=0;
        
        $i=0;
        $char='';

        while ($i < strlen(request('password'))){

            $char=request('password')[$i];

            if (is_numeric($char)) {

                $countNum++;

            } else {

                if($char==strtoupper($char)){

                    $countUppercase++;

                }else if($char==strtolower($char)){

                    $countLowercase++;

                }

            }

            $i++;
            
        }                

        if($countNum < 1  || $countUppercase < 1 || $countLowercase < 1){

            session()->flash('danger','Invalid password!');

            return redirect('/dashboard/employees');

        }
    }

    public static function createEmpAcc($type){


        EmployeeController::passwordValidation();

        if($type==1){

            DB::transaction(function () {
                
                    $res=Employees::empCreate(['id' => request('staffid'),'email' => request('email'), 'pass' => request('password'),'role'=> 2]);

                    //dd($res);

                    if($res){

                        //notification

                        Notification::setLastCheckDate(['id' => request('staffid')]);

                        Notification::createEmp(['staffid'=> session('accInfo')[0]->id, 'id'=> request('staffid')]);

                        $res=CRUD::empCreate(['staffid' => session('accInfo')[0]->id, 'id' => request('staffid') ]);

                    }else{
                        
                        session()->flash('danger','Problem in creating Employee Account try again later!');
                    }

                });

        }else{

            DB::transaction(function () {
                
                    $res=Employees::empCreate(['id' => request('staffid'),'email' => request('email'), 'pass' => request('password'),'role' => request('select')]);

                    //dd($res);

                    if($res){

                        //notification

                        Notification::setLastCheckDate(['id' => request('staffid')]);

                        Notification::createEmp(['staffid'=> session('accInfo')[0]->id, 'id'=> request('staffid')]);

                        $res=CRUD::empCreate(['staffid' => session('accInfo')[0]->id, 'id' => request('staffid') ]);

                    }else{
                        
                        session()->flash('danger','Problem in creating Employee Account try again later!');
                    }

            });

        }
    }


    public function deleteModal(Request $req){

        if($req->q == null){

            return redirect('/dashboard/employees');

        }

        $res=Employees::existEmpId(['id'=>$req->q]);
        
        $status=$req->status;

        return view('modals.delete_emp',compact("res","status"));

    }

    public function restoreModal(){

        if(request('q') == null){

            return redirect('/dashboard/employees');

        }

        $id=request('q');

        $name=Employees::empName(['id'=>$id]);

        return view('modals.restore_emp',compact("id","name"));
    }

    public function restore(){

        DB::transaction(function(){

            $res=Employees::empActivate(['id'=>request('id')]);

            if($res==1){

                CRUD::empActivate(['staffid'=> session('accInfo')[0]->id , 'id' => request('id')]);

                Notification::activateEmp(['staffid' => session('accInfo')[0]->id , 'id' => request('id')]);

                 session()->flash('success','Employee account activated');

            }else{

                 session()->flash('danger','Could not activate employee account!');

            }

        });

        return redirect('/dashboard/employees');

    }
}
