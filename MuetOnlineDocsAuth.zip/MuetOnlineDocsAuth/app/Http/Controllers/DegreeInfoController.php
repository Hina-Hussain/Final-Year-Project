<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DegreeInfo;
use Session;
use Keygen\Keygen;

class DegreeInfoController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);
    }


     public function addDegreeInfo(Request $request)

  {
  	       $id = $request->id;
          
           // get data from form 

           $position = $request->position;
           $dop = $request->dop;
           $doe = $request->doe;
           $dod = $request->dod;
           // validate data
           $this->validation($request);
           
           // generate unique keys
         $key1 = Keygen::numeric(33)->generate();
         $key1 = str_replace('.', '1', bcrypt($key1));
         $key1 = substr($key1,7,14);  

          $key2 = Keygen::numeric(33)->generate();
          $key2 = str_replace('.', '2', bcrypt($key2));
          $key2 = substr($key2,7,14);           
        
          $key3 = Keygen::numeric(33)->generate();
          $key3 = str_replace('.', '3', bcrypt($key3));
          $key3 = substr($key3,7,14);           
 
         
           $degreekey = strtoupper($key1.'d');
           $passkey   = strtoupper($key2.'p');
           $transkey  = strtoupper($key3.'t');

      $insert = DegreeInfo::addInfo($id,$degreekey,$passkey,$transkey,$position,$dop,$doe,$dod);

      if($insert)
      {
      	 
        Session::flash('message', 'Student with rollno - '.$id.' has been verified!'); 
          return response()->json([$id,'SUCCESSFULLY ADD IN VERIFIED STUDENT LIST']);

      }
      else
      {
        return redirect('/dashboard/students')->withErrors([
         'message' => 'Error verifying student']);
      }
      
  } // end of function 


public function validation($request)
{
	return $this->validate($request,[
    'dop' => 'required|date',
    'doe' => 'required|date',
    'dod' => 'required|date', 

	]);
} 

public function test()
{
      $key1 = Keygen::numeric(33)->generate();
      $key1 = str_replace('.', '1', bcrypt($key1));

       $key1 = substr($key1,7,14);  

          $key2 = Keygen::numeric(33)->generate();
          $key2 = str_replace('.', '2', bcrypt($key2));
          $key2 = substr($key2,7,14);           
        
          $key3 = Keygen::numeric(33)->generate();
          $key3 = str_replace('.', '3', bcrypt($key3));
          $key3 = substr($key3,7,14);           
 

           $degreekey = strtoupper($key1.'d');
           $passkey   = strtoupper($key2.'p');
           $transkey  = strtoupper($key3.'t');

      return $degreekey;
}
}
