<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\StudentDetail;
use App\Certificate;
use App\View;


class ViewController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);

        $this->middleware('ajax');

    }
    
    public function showViewModal($id)
    {

      $res = StudentDetail::getData(['id'=>$id]);
      $degree = Certificate::getDegree($id);

   return view('students.viewStudent',compact('res','degree'));
}

public function updateMobNo($id)
{
   $res   = View::changeMob($id,request('mobno'),request('prevmobno'));
  
  if($res)
  { return response()->json(['0'=>'TRUE']);}

return response()->json(['0'=>'FALSE']);
}


public function updateMail($id)
{
  $res = View::changeEmail($id,request('mail'),request('prevmail'));

  if($res)
  {
    return response()->json(['0'=>'TRUE']);
  }

  return response()->json(['0'=>'FALSE']);
}


public function updateAddr($id)
{
  $res = View::changeAddr($id,request('addr'),request('prevaddr'));

  if($res)
  {
    return response()->json(['0'=>'TRUE']);
  }

  return response()->json(['0'=>'FALSE']);
}

public function updateCP($id)
{

  $res = View::changeCP($id,request('currPos'),request('prevPos'));

  if($res)
  {
    return response()->json(['0'=>'TRUE']);
  }

  return response()->json(['0'=>'FALSE']); 
}

public function updateOrgName($id)
{
  $res = View::changeOrg($id,request('orgName'),request('prevOrg'),request('orgType'));

    if($res)
  {
    return response()->json(['0'=>'TRUE']);
  }

  return response()->json(['0'=>'FALSE']); 
}
}