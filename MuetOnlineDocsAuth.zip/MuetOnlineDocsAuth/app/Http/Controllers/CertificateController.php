<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\StudentDetail;
use App\Http\Controllers\GetPrevController;
use App\Certificate;


class CertificateController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);
         $this->middleware('certificate')->only(['showInfo']);   
    }

     public function showInfo(Request $request)
    {
         $id      = base64_decode(request('q'));
         $pinfo   = Certificate::getPInfo($id);
      $degreeInfo = Certificate::getDegree($id);
      $marksInfo  = StudentDetail::getMarks($id);
   
          $prev   =  GetPrevController::getStaffPrev();
      $semester   = Certificate::getSems($id); 
      $grades     = Certificate::getGrade($id);
      $semGpa     = Certificate::semsGpa($id);


   return view('students.stdCertificate',compact('pinfo','degreeInfo','prev','marksInfo','semester','grades','semGpa'));
    }

    
}
