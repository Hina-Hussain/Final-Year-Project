<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Delete;
use App\CommonCode;


class DeleteController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);
    }


    public function delete(Request $request){
    	
    	$id = $request->id;
      // first check student previous status
      $prevStatus = CommonCode::getStatus($id);
      if($prevStatus==-1)
      {
        $permDel = Delete::permanDel($id,$prevStatus);
        if($permDel)
        {
           return redirect('/dashboard/students')->with('message','Student with rollno - '.$id." has been permanently deleted!"); 
        }
        else
        {
          return redirect('/dashboard/students')
        ->withErrors(['message' => 'Problem deleting student permanently!']);
        }
      }
      else
      {
        $delete = Delete::deleteStd($id,$prevStatus);

      if($delete){
        return redirect('/dashboard/students')->with('message','Student with rollno - '.$id."  has been deleted!");
       }
     else
     {
         return redirect('/dashboard/students')
        ->withErrors(['message' => 'Problem deleted student!']);
     }  
      }
    	
     
    }

    public function reportStudent(Request $request)
    {
      $id = $request->id;
      $comment = array('problem'=>[$request->pinfo,$request->transcript,$request->degree,$request->other],
      'comment'=> $request->comment);

         $comment = json_encode($comment);

   $report = Delete::report($id,$comment);
  
if($report)
{
  return redirect('/dashboard/verifiedStudents')->with('message','Student with rollno - '.$id." has been reported!");
}
else
{
      return redirect('/dashboard/verifiedStudents')
            ->withErrors(['message' => 'Problem reporting student!']);  
}


} // end for function 


public function restoreStd(Request $request)
{
  $res = Delete::restore($request->rollno);
  if($res)
  {
      return redirect('/dashboard/students')->with('message','Student with rollno - '.$request->rollno." has been restored successfully!");
    }

  else
      {
        return redirect('/dashboard/students')
        ->withErrors(['message' => 'Problem restoring student!']);
      }
}
}