<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UpdateMarks;
use Validator;
use Session;


class EditMarksController extends Controller
{
   // update Marks!

    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);
          $this->middleware('ajax')->only(['updateMarks']);
    }

    public function updateMarks(Request $request)
  {  
        $id = $request->id;
       
       // theory subject info

        $courseIdTH = $request->THcode;
        $maxmarksTH = $request->maxmarksTH;
        $marksobtTH = $request->marksobtTH;
        $oldmarksTH = $request->oldmarksobtTH;
        $THsemester = $request->THsems;    

        // practical subject info

        $courseIdPR = $request->PRcode;
        $maxmarksPR = $request->maxmarksPR;
        $marksobtPR = $request->marksobtPR;
        $oldmarksPR = $request->oldmarksobtPR;
        $PRsemester = $request->PRsems;
      
    // confirm any field is changed or not
     $changeTH  = array_diff_assoc($marksobtTH,$oldmarksTH);
     $changePR  = array_diff_assoc($marksobtPR, $oldmarksPR);

    if(count($changeTH) == 0 && count($changePR) == 0)
    {
      Session::flash('message',"No updations were made to this student information as you did not make changes!");

    	return response()->json(['0'=> 0]);
    	
    }

    else
   { 	
        $rules1 = [];
        $rules2 = [];
        $rules3 = [];
       
        // check for required fields!
  foreach($request->input('marksobtPR') as $key => $value) {
        $rules1["marksobtPR.{$key}"] = 'required|numeric';
      
        }

        foreach($request->input('marksobtTH') as $key => $value) {
           $rules2["marksobtTH.{$key}"] = 'required|numeric';
        }

   // validate input data
    $validator1 = Validator::make($request->all(), $rules1);
    $validator2 = Validator::make($request->all(), $rules2);
      
    if ($validator1->fails() || $validator2->fails())
    {
    	return response()->json(['0'=> 1 ,'1' => "Fields are required and must be numeric"]);
    }

     // now check marks should not greater than maximum marks

    $check1 = $this->customValidate($maxmarksTH,$marksobtTH);
    $check2 = $this->customValidate($maxmarksPR,$marksobtPR);
 
   if($check1 || $check2)
   {
    return response()->json(['0'=> 2 ,'1' => "Marks obtained can not be greater than maximnum marks!"]);
    
   }
 
    $fail1 = $this->IsFail($maxmarksTH,$marksobtTH);
    $fail2 = $this->IsFail($maxmarksPR,$marksobtPR);
   
   // any course fail!

 if($fail1 || $fail2)
{
  if(count($changeTH)!=0 && count($changePR)!=0)
{
     // get old marks of changed field  
       $oldchangeTH  = array_diff_assoc($oldmarksTH,$marksobtTH);
 
    $updateTH = UpdateMarks::updateThMarks($id,$courseIdTH,$marksobtTH,$changeTH,$oldchangeTH);

   // get old marks of changed field     
      $oldchangePR  = array_diff_assoc($oldmarksPR,$marksobtPR);
  
  $updatePR = UpdateMarks::updatePrMarks($id,$courseIdPR, $marksobtPR,$changePR,$oldchangePR);
     
  // get courseId and semester of fail subject
  $result = $this->checkFail($id,$changeTH,$maxmarksTH,$courseIdTH,$THsemester,$changePR,$maxmarksPR,$courseIdPR,$PRsemester);
  
  if($updateTH && $updatePR && $result)
  {
      Session::flash('message','Marks updated successfully, but student with rollno - '.$id.' failed in subject!');

  return response()->json(['0'=> 3]);
  }
  else
  {
    Session::flash('error','Problem updating marks of student!');

    return response()->json(['0'=> 6]);
  }

} // end of count() if

// if theory marks change but not practical 
else if(count($changeTH)!=0 && count($changePR)==0)
{
  
  $oldchangeTH  = array_diff_assoc($oldmarksTH,$marksobtTH);
 
  $updateTH = UpdateMarks::updateThMarks($id,$courseIdTH,$marksobtTH,$changeTH,$oldchangeTH);

  $result = $this->checkFail($id,$changeTH,$maxmarksTH,$courseIdTH,$THsemester,$changePR,$maxmarksPR,$courseIdPR,$PRsemester);

  if($updateTH && $result)
  {
     Session::flash('message','Marks updated successfully, but student with rollno - '.$id.' failed in subject!');

     return response()->json(['0'=> 3]);
  }

  else
  {
    Session::flash('error','Problem updating marks of student!');

    return response()->json(['0'=> 6]);
  }
  
  } // end of else if
 
 // if practical marks change

 else if(count($changeTH)==0 && count($changePR)!=0)
{

    // get old marks of changed field     
  $oldchangePR  = array_diff_assoc($oldmarksPR,$marksobtPR);
  $updatePR = UpdateMarks::updatePrMarks($id,$courseIdPR, $marksobtPR,$changePR,$oldchangePR);
    
    $result = $this->checkFail($id,$changeTH,$maxmarksTH,$courseIdTH,$THsemester,$changePR,$maxmarksPR,$courseIdPR,$PRsemester);
if($updatePR && $result)
{
   Session::flash('message','Marks updated successfully, but student with rollno - '.$id.' failed in subject!');
   
   return response()->json(['0'=> 3]);
}
else
{
  Session::flash('error','Problem updating marks of student!');
  return response()->json(['0'=> 6]);
}
}// end of else if

} // end of fail1||fail1



if($validator1->passes() && $validator2->passes() && !$check1 && !$check2 && !$fail1 && !$fail2)
  {
    if(count($changeTH)!=0 && count($changePR)!= 0)
   {
       // get old marks of changed field     
  $oldchangeTH  = array_diff_assoc($oldmarksTH,$marksobtTH);
 
 $updateTH = UpdateMarks::updateThMarks($id,$courseIdTH,$marksobtTH,$changeTH,$oldchangeTH);

    // get old marks of changed field     
  $oldchangePR  = array_diff_assoc($oldmarksPR,$marksobtPR);
  $updatePR = UpdateMarks::updatePrMarks($id,$courseIdPR, $marksobtPR,$changePR,$oldchangePR);


  if($updateTH && $updatePR)

{ 
 Session::flash('message','Marks of student with rollno - '.$id.' has been successfully updated!');

  return response()->json(['0'=> 4]);}

else if($updateTH)
{
  Session::flash('message',"Theory marks successfully updated but some error occured in updating practical marks!");

  return response()->json(['0'=> 5]);
}
else if($updatePR)
{
  Session::flash('message',"Practical marks successfully updated but some error occured in updating theory marks!");

  return response()->json(['0'=> 5]);
}
else
{
  Session::flash('error','Problem updating marks of student!');
  return response()->json(['0'=> 6]);
}

}   // end of if 
  
  // check if theory marks are changed but not practical

 else if(count($changeTH)!=0 && count($changePR)==0)
  
  {
  
  $oldchangeTH  = array_diff_assoc($oldmarksTH,$marksobtTH);
 
  $updateTH = UpdateMarks::updateThMarks($id,$courseIdTH,$marksobtTH,$changeTH,$oldchangeTH);

    if($updateTH)

{ 
  Session::flash('message','Marks of student with rollno - '.$id.' has been successfully updated!');

  return response()->json(['0'=> 4]);
}

else
{
  Session::flash('error','Problem updating marks of student!');

  return response()->json(['0'=> 6]);
}
 
  }// end of else if
 
else if(count($changeTH)==0 && count($changePR)!=0)
{

    // get old marks of changed field     
  $oldchangePR  = array_diff_assoc($oldmarksPR,$marksobtPR);
  $updatePR = UpdateMarks::updatePrMarks($id,$courseIdPR, $marksobtPR,$changePR,$oldchangePR);

  if($updatePR)
  {
   Session::flash('message','Marks of student with rollno - '.$id.' has been successfully updated!');
    
    return response()->json(['0'=> 4]);
  }

  else
{
  Session::flash('error','Problem updating marks of student!');

  return response()->json(['0'=> 6]);
}
  
}  // end of else if

 } // end of if validator

} // end of else

} //end of function 



// custom validation of marks to check marksobt greater than maximum marks or not!

 public function customValidate($maxmarks,$marksobt)
    {
       $counter = 0;
        for($i=0;$i<count($maxmarks);$i++)
        {
      
      if($marksobt[$i]>$maxmarks[$i])

           {$counter++;}

        } // end of loop
        
        if($counter==0)
        {
            return FALSE;
        }
        else
        {
            return TRUE;
        }

 } // end of function 

// to check for fail
public function IsFail($maxmarks,$marksobt)
{
	$counter = 0;
   
   for($i=0;$i<count($maxmarks);$i++)
   {
  
  if($marksobt[$i]<($maxmarks[$i]/2))
      	
      	{$counter++;}

}// end of loop

if($counter==0)
{
	return FALSE;
}
else
{
	return TRUE;
}

}// end of function

// now check which course is fail

public function checkFail($id,$Thchange,$Thmaxmarks,$ThId,$Thsemester,$Prchange,$Prmaxmarks,$PrId,$Prsemester)
{
    $THfail      = array();
    $THsem       = array();  
    $PRfail      = array();
    $PRsem       = array();
  $bothfail      = array();
   $bothfailsem  = array();

   // first find out which theory subjects are failed
   if(count($Thchange)!=0)
 {
  foreach ($Thchange as $key => $value) {
    
    if($value<($Thmaxmarks[$key]/2))
    {
      array_push($THfail,$ThId[$key]);
      array_push($THsem,$Thsemester[$key]);
    }
  } // end of first loop
  } // if end

// now find out which practical subjects are failed
  if(count($Prchange)!=0)
  {
   foreach ($Prchange as $key => $value) {
    
    if($value<($Prmaxmarks[$key]/2))
    {
      array_push($PRfail,$PrId[$key]);
      array_push($PRsem,$Prsemester[$key]);
    }
  } // end of second loop
 
 } // end of if
 
  // now find out which course is completely fail!
  if(count($THfail)!=0 && count($PRfail)!=0)
  {

     foreach ($THfail as $key => $value) {
    
    if(in_array($value,$PRfail))
      {
        array_push($bothfail,$value);
        array_push($bothfailsem,$THsem[$key]);

        // now that courseCode is remove from Theory and practical array!
        unset($THfail[$key]);
        unset($THsem[$key]);

        // now find key in practical array to remove
        $key1 = array_search($value,$PRfail);
        unset($PRfail[$key1]);
        unset($PRsem[$key1]);
      }
  
  } // end of third loop
  
  if(count($bothfail)==0)
  {
    //for theory status
$res1 =  UpdateMarks::changeStatus($id,$THfail,$THsem,3);

     // for practical status
 $res2 = UpdateMarks::changeStatus($id,$PRfail,$PRsem,2);

 if($res1 && $res2)
  {return TRUE;}
  
  }

  elseif(count($bothfail)!=0 && count($THfail)==0 && count($PRfail)==0)
  {
    // both fail status
   $res1 = UpdateMarks::changeStatus($id,$bothfail,$bothfailsem,0);
  
   if($res1)
    {return TRUE;}
  }

  elseif(count($bothfail)!=0 && count($PRfail)!=0 && count($THfail)==0)
  {
   $res1 = UpdateMarks::changeStatus($id,$PRfail,$PRsem,2);
  $res2 = UpdateMarks::changeStatus($id,$bothfail,$bothfailsem,0);

  if($res1 & $res2)
    {return TRUE;}
}
 
 elseif(count($bothfail)!=0 && count($THfail)!=0 && count($PRfail)==0)
 {

$res1 = UpdateMarks::changeStatus($id,$THfail,$THsem,3);
$res2 = UpdateMarks::changeStatus($id,$bothfail,$bothfailsem,0);
if($res1 && $res2)
{return TRUE;} 

}

elseif(count($bothfail)!=0 && count($THfail)!=0 && count($PRfail)!=0)
  {
    
$res1 = UpdateMarks::changeStatus($id,$THfail,$THsem,3);
$res2 = UpdateMarks::changeStatus($id,$PRfail,$PRsem,2); $res3 = UpdateMarks::changeStatus($id,$bothfail,$bothfailsem,0);

if($res1 && $res2 && $res3)
{return TRUE;}
  
}

 } // end of if
 
 elseif(count($THfail)!=0 && count($PRfail)==0)
 {
$res1 = UpdateMarks::changeStatus($id,$THfail,$THsem,3);
 if($res1)
 {return TRUE;}  
 }

 elseif(count($PRfail)!=0 && count($THfail)==0)
 {
$res1 = UpdateMarks::changeStatus($id,$PRfail,$PRsem,2); 
if($res1)
  {return TRUE;}
 }
 
 elseif(count($THfail)==0 && count($PRfail)==0)
 {
    return FALSE; 
 }
} // end of function 

}  // end of controller
