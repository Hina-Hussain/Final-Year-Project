<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DegreeInfo;
use App\StudentDetail;
use App\Http\Controllers\GetPrevController;




class StdDetailController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);

        $this->middleware('ajax')->only(['stdDetail']);

    }

    public function index(Request $req){
      
      if (request('q')!=null) {

        $res=StudentDetail::getData(['id'=>request('q')]);

      return view('students.view_data',compact("res"));
        }

        if(request('q')==null){
             return redirect('/dashboard/log');
        }

        if(!$req->ajax()){

            abort(404);
            
        }
    }
    
    public function stdDetail($id){
     	
     	$user     =  StudentDetail::reterive($id);
    	$system   =  StudentDetail::getEduSystem($id);
      $ploRes   =  StudentDetail::getPloProgress($id);
      $dept     =  StudentDetail::getDept();
      $examinfo =  StudentDetail::getMarks($id);
      $cgpa     =  DegreeInfo::getCgpa($id);
      $degInfo  = DegreeInfo::getDegreeInfo($id);
      $prev   =  GetPrevController::getStaffPrev();

   
        return view('students.studentModal',compact('user','system','ploRes','dept','examinfo','degInfo','prev'))
          ->with('cgpa',$cgpa);
    }
}
