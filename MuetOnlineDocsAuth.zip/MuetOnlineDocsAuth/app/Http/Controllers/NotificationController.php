<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Notification;
use App\Course;

class NotificationController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);

        $this->middleware('ajax')->only(['lastChecked']);
    }


    public function lastChecked(){

    	return response()->json(Notification::lastCheckDate());

    }

    public function index(){

        $myNotif=Notification::getAllMyNotif();

        $crNotif=Notification::getAllCrEmpNotif();

        $upNotif=Notification::getAllUpEmpNotif();

        $delNotif=Notification::getAllDelEmpNotif();

        $perDelNotif=Notification::getAllPerDelEmpNotif();

        $ActEmpNotif=Notification::getAllActEmpNotif(); 

        $res6=Notification::getAllupStdInfoNotif();

       // dd($res6);

        $courseNames=[];
        
        foreach($res6 as $updation){

            if($updation->comment !=null){

                if(count($courseNames)==0 || !(array_key_exists($updation->comment, $courseNames))){

                    $name=Course::getCourseName([ 'code' => $updation->comment]);

                    $courseNames[$updation->comment] = $name[0]->courseName;

                }
            }

        }

        $res7=Notification::getAllVerStd();

        $res8=Notification::getAllRepStd();

        $res9=Notification::getAllDelStd();

        $resStd=Notification::getAllResStd();

        $perDelStd=Notification::getAllPerDelStd();


        $result=[
                    'myNotif'=> $myNotif,
                    'crNotif' => $crNotif, 
                    'upNotif' => $upNotif, 
                    'delNotif' => $delNotif,
                    'activeEmpNotif' => $ActEmpNotif,
                    'perDelNotif' => $perDelNotif, 
                    'UpStdInfo' => $res6,
                    'courseName' => $courseNames, 
                    'VerStd' => $res7, 
                    'RepStd' => $res8, 
                    'DelStd' => $res9,
                    'ResStd' => $resStd,
                    'PerDelStd' => $perDelStd
                ];

        //dd($result);

    	return view('dashboard.notifications',compact("result"));

    }
}
