<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;
use Illuminate\Support\Facades\Input;




class StudentController extends Controller
{
   
    public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);

        $this->middleware('stdRequest')->only(['showStudent']);
        
        $this->middleware('VerifiedStd')->only(['verifiedStudents']); 

    }


    public function showStudent()
    {
  if(request('q')=='dept') 
    	{
        $results = Student::reteriveInfo('dept.name');}

 elseif (request('q')==null || request('q')=='rollno' || request('q')=="all") {
     $results = Student::reteriveInfo('stdinfo.rollNo');
 }

 elseif (request('q')=='batch') {
    
    $results = Student::reteriveInfo('batch.batch');
 }

 elseif (request('q')=='system') {
 
  $results = Student::reteriveInfo('edusystem.name');
 }

 elseif (request('q')=='status') {
     
     $results = Student::reteriveInfo('stdinfo.status');
 }
 elseif (request('q')=='pending') {
   $results = Student::getFewStd(1);
 }
 elseif(request('q')=="reported")
 {
  $results = Student::getFewStd(-2);
 }
 elseif(request('q')=="deleted")
 {
    if(session('accInfo')[0]->role==1)
 { $results = Student::getFewStd(-1);}
 else
 
 {abort(404);}
 }

   $search = true;
    
return view('students.manageStudent',compact('results','search'));

 } // end of function 


 // get list of verified student
 public function verifiedStudents()
 {
 	
 if( request('q')=='dept') 
   {
       $results = Student::getVerified('dept.name');}

 
 elseif (request('q')==null || request('q')=='rollno') {
    $results = Student::getVerified('stdinfo.rollNo');
 }

 elseif (request('q')=='batch') {
    
    $results = Student::getVerified('batch.batch');
 }

 elseif (request('q')=='system') {
 
 $results = Student::getVerified('edusystem.name');
 }
$search = true;
  
return view('students.verifiedStudent',compact('results','search'));
 }
 


} // end of controller
