<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Roles;
use App\Prevs;
use DB;
use App\CRUD;

class AccountsRightsController extends Controller
{

	public function __construct()
    {
        $this->middleware('auth_false')->except([]);

        $this->middleware('account_expire_confirm')->except([]);

        $this->middleware('authCrEdit')->except([]);

        $this->middleware('ajax')->only(['create','accRightsInfo','deleteModal']);

    }

    public function index(){

        $res=Roles::getRoles();

        $res2=Prevs::getAllPrevs();

        return view('dashboard.account_rights',compact("res","res2"));
    }

    public function accRightsInfo(){

        if(request('q')==null){
            return redirect('/dashboard/account_rights');
        }

        $res=Prevs::rolePrevs(['id' => request('q')]);

        $res2=Roles::roleName(['role'=>request('q')]);

        return view('modals.view_acc_rights',compact("res","res2"));
    }

    public function create(){

        $res=Prevs::rolePrevs(['id' => session('accInfo')[0]->role]);

        return view('modals.insert_acc_rights',compact("res"));
    }

    public function store(Request $req){

        $res=$this->validate($req, [
            'role_name' => 'required',
            'role_desc' => 'required' 
        ]);

        DB::transaction(function () {   

            $newRoleId=  Roles::getRoles()->last()->id;

            $newRoleId++;

            $prevs= Prevs::getAllPrevs();

            $prevsTot= count($prevs);

            $roleprevs= array();
                
            for($i=0;$i<$prevsTot;$i++){

                if(request($prevs[$i]->id)==1){    
                    array_push($roleprevs,$prevs[$i]->id);
                }

            }

            if(count($roleprevs)>0){

                //checking role name is unique
                    
                $res1=Roles::getRoles();
                
                    $count=0;

                    foreach ($res1 as $value) {

                        if(request('role_name')==$value->name){

                            $count=1;
                            break;
                        }    
                    } 

                     if($count==0){
                        
                        //create role as role name is unique

                        $res=Roles::roleCreate(['id' => $newRoleId, 'name' => request('role_name'), 'desc' => request('role_desc')]);


                        if($res){

                            //CRUD entry because new role is created

                            $res2=CRUD::roleCreate(['staffid' => session('accInfo')[0]->id, 'id' => $newRoleId ]);

                            $res=Prevs::assignRolePrev(['id' => $newRoleId, 'roleprevs' => $roleprevs]);

                            if($res){

                                session()->flash('success','New role has been created!');

                            }else{

                                session()->flash('delete','Problem creating role!');

                            }
                          
                        }

                    }

                       
                }

            });

        return redirect('/dashboard/account_rights');
    }

    public function deleteModal(){

        $name=Roles::roleName(['role' => request('q')])[0]->name;

        $id=request('q');

        return view('modals.delete_acc_rights',compact("id","name"));
    }

    public function destroy(){

        //check if role is assigned to any employee

        $res=Roles::checkEmpRole(['role' => request('id')]);

        if($res > 0){

            session()->flash('delete','Problem deleting role because this role is already given to employees!');
            
            return redirect('/dashboard/account_rights');

        }

        $roleName=Roles::roleName(['role' => request('id')])[0]->name;

        $res=Roles::roleDel(['id' => request('id')]);

        if($res){

            CRUD::roleDelete(['staffid' => session('accInfo')[0]->id, 'id' => request('id'), 'name' => $roleName ]);

            session()->flash('success','Role deleted successfully!');

        }else{

            session()->flash('delete','Problem deleting role!');

        }

        return redirect('/dashboard/account_rights');

    }
}
