<?php

namespace App\Http\Middleware;

use Closure;
use App\Profile;

class account_expire_confirm
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        //status of account has been changed i.e made 0 or staff status is changed to 0

        if(count(Profile::accountExpireCheck())<1){
           
            session()->flush();

            return redirect()->route('login');

        }
        return $next($request);
    }
}
