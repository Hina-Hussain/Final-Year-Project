<?php

namespace App\Http\Middleware;

use Closure;
use App\Prevs;


class StudentRequest
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
       
        $content = Prevs::rolePrevs(['id' => session('accInfo')[0]->role]); 
         
         foreach($content as $value){
            
            if($value->id==5 || $value->id==6 || $value->id==7 || $value->id==11){
                
                return $next($request);

            }

         }
          abort(404);
    }
}
