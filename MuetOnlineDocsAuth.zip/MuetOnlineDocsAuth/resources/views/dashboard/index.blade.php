@extends('layouts.layout')
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Welcome {{session('staffInfo')[0]->name}}</title>



<!-- Styles -->
@section('styles1')
<link href="/assets/css/lib/weather-icons.css" rel="stylesheet" />
<link href="/assets/css/lib/owl.carousel.min.css" rel="stylesheet" />
<link href="/assets/css/lib/owl.theme.default.min.css" rel="stylesheet" />

@endsection

@section('styles2')
<link href="/assets/css/lib/helper.css" rel="stylesheet">
@endsection

</head>

<body >

@section ('content')

<div class="content-wrap">
<div class="main">
<div class="container-fluid">

<main role="main">

<header id="main-header" class="content-wrap  text-white">
<div class="main">
<div class="container-fluid">
<div class="col-md-12">
  <br>
<h2> <b>Dashboard</b> </h2>
</div>

@if(Session::has('successfull'))

<div  class="alert alert-success m-2" role="alert" style="color:white;">

{{ Session::pull('successfull') }} 

</div>

@endif

</div>
</div>
</header>

<!-- graph -->
<canvas style="margin-left: 10px;" class="my-4 w-100" id="myChart" width="1000" height="380"></canvas>
<br>

<canvas id="pie-chart" width="1500" height="400">
    
</canvas>


 <!-- end graph -->            

<br><br>
@if(array_key_exists ( 'emp-details' , $result ))
<!-- Newly added Employes -->
<div class="container-fluid">
<br>
<!-- List View for Emp-->
<section id="posts">
<div>
<div class="row">
<div class="col">
<div>
<div class="card-header web_back_color">
<div class="row">
<div class="col-sm-6">
<h4 class="text-white">Newly <b>Added Employees</b>
</h4>
</div>

</div>

</div>

<table class="table table-striped bg-fadded">
<thead>
<tr>
<th>Id</th>
<th>Name</th>
<th>Email</th>
<th>Role</th>
<th style="text-align: left;">Dept Name</th>
</tr>
</thead>

<tbody id="emps">
@forelse($result['emp-details'] as $value)
<tr>

<td scope="row">

{{$value->id}}

</td>

<td>

{{ucwords($value->name)}}

</td>

<td>{{$value->email}}</td>

<td>{{ucwords($value->role)}}</td>

<td style="text-align: left;">{{ucwords($value->dept)}}</td>

</tr>

@empty

<tr></tr>

@endforelse

</tbody>
</table>

</div>

<div class="card-header bg-fadded mt-0">

<div style="float:right;display: block;">
<a href="/dashboard/employees"><button class="btn2" >Show more</button>
</a>
</div>

<br>
<br>

</div>


</div>
</div>
</div>
</section>
</div>

<br>

@endif


@if(array_key_exists ( 'verified' , $result ))
<!-- Newly added Students -->
<div class="container-fluid">
<br>
<!-- List View for Emp-->
<section id="posts">
<div>
<div class="row">
<div class="col">
<div>
<div class="card-header web_back_color">
<div class="row">
<div class="col-sm-6">
<h4 class="text-white">Recently <b>Verified Students</b></b>
</h4>
</div>

</div>

</div>

<table class="table table-striped bg-fadded">
<thead>
<tr>
<th>#</th>
<th>Full Name</th>
<th>Roll no</th>
<th>Department</th>
<th>Batch</th>
</tr>
</thead>

<tbody id="emps">
@forelse($result1 as $std)
<tr>
<td scope="row">{{$loop->index+1}}</td>
<td>{{ucwords($std->fullname)}}</td>
<td>{{strtoupper($std->rollNo)}}</td>
<td>{{ucwords($std->name)}}</td>
<td>{{$std->batch}}</td>

</tr>
@empty

<tr></tr>
@endforelse
</tbody>
</table>

</div>

<div class="card-header bg-fadded mt-0">

<div style="float:right;display: block;">
<a href="/dashboard/verifiedStudents"><button class="btn2" >Show more</button>
</a>
</div>

<br>
<br>

</div>


</div>
</div>
</div>
</section>
</div>

<br>

@endif

@if(array_key_exists ( 'student' , $result ))
<!-- Newly added Students -->
<div class="container-fluid">
<br>
<!-- List View for Emp-->
<section id="posts">
<div>
<div class="row">
<div class="col">
<div>
<div class="card-header web_back_color">
<div class="row">
<div class="col-sm-6">
<h4 class="text-white">Recently <b>Graduating Students</b></b>
</h4>
</div>

</div>

</div>

<table class="table table-striped bg-fadded">
<thead>
<tr>
<th>#</th>
<th>Full Name</th>
<th>Roll no</th>
<th>Department</th>
<th>Batch</th>
</tr>
</thead>

<tbody id="emps">
@forelse($result2 as $user)
<tr>
<td scope="row">{{$loop->index+1}}</td>
<td>{{ucwords($user->fullname)}}</td>
<td>{{strtoupper($user->rollNo)}}</td>
<td>{{ucwords($user->name)}}</td>
<td>{{$user->batch}}</td>

</tr>
@empty

<tr></tr>
@endforelse
</tbody>
</table>

</div>

<div class="card-header bg-fadded mt-0">

<div style="float:right;display: block;">
<a href="/dashboard/students"><button class="btn2" >Show more</button>
</a>
</div>

<br>
<br>

</div>


</div>
</div>
</div>
</section>
</div>

<br>

@endif


</main>
</div>
</div>
</div>


<!-- List of Graduating students-->



@endsection 



<!-- Graphs -->
@section('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>


<script type="text/javascript">

document.getElementById('dashboard').classList.add('active');

document.getElementById('staff').classList.remove('active');

document.getElementById('students').classList.remove('active');

document.getElementById('account_rights').classList.remove('active');

document.getElementById('verstudents').classList.remove('active');

document.getElementById('profile').classList.remove('active');

document.getElementById('log').classList.remove('active');

document.getElementById('setting').classList.remove('active');
</script>

@if(array_key_exists ( 'graph' , $result ))

<script>


new Chart(document.getElementById("myChart"), {
    type: 'horizontalBar',
    data: {
      labels: ["Website","Mobile Application"],
      datasets: [{
        
        backgroundColor: ['#34DDDD','#ffc107'],
        borderColor: ['#34DDDD','#ffc107'],
        data: [{{$visits['web']}},{{$visits['mobile']}}]
      }]
    },
    options: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Requests For Verification Using Different Mediums'
      }
    }
});

new Chart(document.getElementById("pie-chart"), {
    type: 'pie',
    data: {
      labels: ["Degree","Pass Certificate","Transcript"],
      datasets: [{
        
        backgroundColor: ["#fb5d7c", "#8e5ea2","#c45850"],
        data: [{{$certificate['degree']}},{{$certificate['pass']}},{{$certificate['trans']}}]
      }]
    },
    options: {
      title: {
        display: true,
        text: 'Certificate Serach By User'
      }
    }
});

</script>
@endif


@endsection
</body>

</html>