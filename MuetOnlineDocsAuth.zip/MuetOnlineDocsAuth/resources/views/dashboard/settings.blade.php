@extends('layouts.layout')
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Account - Settings</title>
   <meta name="csrf-token" content="{{ csrf_token() }}">
</head>

<body>

    @section('content')
 <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <main role="main">
        
        <div class="col-sm-12"> 
            <br>

            <div class="alert alert-danger" role="alert" id="imgeerror" style="display: none;color:white;">

                Image should be less than 64 kb in size and image should have jpg or png extension!

            </div>

            <center>
                <img 
                
                src=

                @if(session('staffInfo')[0]->pic!=null)
                  "{{ asset('storage/uploads/staff/'
                .session('staffInfo')[0]->pic)}}"

                @else

                "/img/avatar.png"

                @endif


                alt="image" class="img-fluid mb-3  rounded-circle" width="150px" height="150px" id="preview">
                <div class="form-group-row" id="selectFile">
                    <form action="/dashboard/settings/editPic" method="post" enctype="multipart/form-data" id="changePicForm">
                        @csrf
                        <input type="file" class=" ml-5 form-control-file" name="pic"required onchange="imagePreview(this.files[0])" id="imgfile">
                        <br>
                        <input type="button" value="Upload Picture" 
                         class="btn btn-primary" onclick='checkPic()'>
                    </form>
                </div>
            </center>

            <br><br>

            @include('layouts.error')

            @if(Session::has('Unsuccessfull'))
                    
                    <div  class="alert alert-danger m-2" role="alert" style="color:white;">
                                                    
                        {{ Session::pull('Unsuccessfull') }} 
                                                
                    </div>

                @endif

            @if(Session::has('Successfull'))
                    
                    <div  class="alert alert-success m-2" role="alert" style="color:white;" >
                                                    
                       {{ Session::pull('Successfull') }}  
                                                
                    </div>

            @endif

            @if(Session::has('Message'))
        
                <div  class="alert alert-primary m-2" role="alert" style="color:white;" >
                                                
                   {{ Session::pull('Message') }}  
                                            
                </div>

            @endif
    
    
                <div class="text-center">
                    <div class="row">
                            <br>

                            <table class="table">
                                <tbody>
                                <tr>
                                    <form action="/dashboard/settings/edit" id="emailSubmitForm">
                                        <input type="hidden" value="{{session('accInfo')[0]->email}}" id="emailprev">
                                    <th scope="row">
                                        <div class="col-sm-6" style="font-size: 1.25em;">
                                        Email</div>
                                    </th>

                                    <td>
                                        <div class="col-sm-12">
                                            <input type="email" name="email" class="form-control" id="email" placeholder="enter email" value="{{session('accInfo')[0]->email}}" required style="display: none;width: 100%">

                                            <p style="font-size: 1.25em;" class="lead" id="prevEmail">{{session('accInfo')[0]->email}}</p>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="col-sm-1 mr-5" id="editSaveB">

                                            <a href="#" onclick="edit()" id="edit" ><i class="btn fa fa-edit" title="Edit"></i></a>

                                            <button id="saveEmail" style="background-color: transparent;border: none;display: none;" type="button">
                                                <i class="btn fa fa-check-circle-o" title="Change" style="color:green;"></i>
                                            </button>

                                        </div>
                                    </td>
                                    </form>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <div class="col-sm-6" style="font-size: 1.25em;">Password</div>
                                    </th> 
                                    <form action="/dashboard/settings/editPass" method="post" id="passwordChForm">
                                        @csrf
                                    <td>
                                        <div class="col-sm-12">
                                            
                                            <p style="font-size: 1.25em;" class="lead" id="prevPass">xxxxxxx</p>

                                            <input type="password" name="password-curr" class="form-control" id="curr_password" placeholder="enter your current password" required style="display: none;width: 100%">

                                            <div class="form-group row">
                                            
                                                <div class="alert alert-primary" id="passrules" style="color:white;;text-align: left; width: 80%;margin-left: 5%;font-size: 0.9em;border: 1px solid white;border-radius: 5px;display: none;">
                                                   
                                                    <ul>
                                                        <li>
                                                            &bull; Password should have atleast 6 characters.
                                                        </li>
                                                        <li>
                                                            &bull; Password should have one Uppercase character.
                                                        </li>
                                                        <li>
                                                            &bull; Password should have one Lowercase character.
                                                        </li>
                                                    </ul>
                                                </div>

                                            </div>

                                            <input type="password" name="password" class="form-control" id="password" placeholder="enter your new password" required style="display: none">
                                                
                                            <br>

                                            <input type="password" name="password_confirmation" class="form-control" id="password_confirmation" placeholder="enter your new  password again" required style="display: none">

                                            
                                        </div>
                                    </td>
                                    <td>
                                        <div class="col-sm-1 mr-5" id="editSaveB">
                                            <a href="#" onclick="editPass()" id="editP" ><i class="btn fa fa-edit" title="Edit"></i></a>
                                            <a href="#" onclick="savePass()" id="saveP" style="display: none;"><i  class="btn fa fa-sign-in" title="Save" style="color:teal;"></i></a>
                                            <button onclick="changePass()" id="changeP" style="background-color: transparent;border: none;display: none;" type="button">
                                                <i class="btn fa fa-check-circle-o" title="Change" style="color:green;"></i>
                                            </button>
                                        </div>
                                    </td>
                                    </form>
                                    <td>
                                        <p class="mb-1" style="width:100%;color:red;display: none;" id="errors" width="200px"></p>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                    </div>

                </div>
        </div>
    </main>
</div>
</div>
</div>
    @endsection

    @section('scripts')
     <script>

        document.getElementById('dashboard').classList.remove('active');

        document.getElementById('staff').classList.remove('active');
        
        document.getElementById('students').classList.remove('active');
        
        document.getElementById('account_rights').classList.remove('active');
        
        document.getElementById('verstudents').classList.remove('active');
        
        document.getElementById('profile').classList.remove('active');
        
        document.getElementById('log').classList.remove('active');
        
        document.getElementById('setting').classList.add('active');

        $('#saveEmail').on('click',function(){

            if($('#email').val().trim()==$('#emailprev').val()){
               
                document.getElementById('edit').style="display:block;"
                document.getElementById('email').style="display:none;"
                document.getElementById('prevEmail').style="font-size: 1.25em;display:inline-block;"
                document.getElementById('saveEmail').style="display:none;"

            }else{

               document.getElementById('emailSubmitForm').submit();

            }

        });

       function edit(){

            $('#passrules').hide();

            document.getElementById('edit').style="display:none;"
            document.getElementById('email').style="display:inline-block;"
            document.getElementById('prevEmail').style="display:none;"
            document.getElementById('saveEmail').style="background-color: transparent;border: none;display:inline-block;"

       }

       function editPass(){

            $('#passrules').hide();

            document.getElementById('editP').style="display:none;"
            document.getElementById('curr_password').style="display:inline-block;"
            document.getElementById('prevPass').style="display:none;"
            document.getElementById('saveP').style="display:inline-block;"

       }

       function savePass(){

            $.ajax({
                type: "post",
                url: "/settings/checkPass",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {'curr_password': document.getElementById('curr_password').value},
                dataType: "text",
                success: function( response ) {
                   if (response=="true") {
                        document.getElementById('errors').style="display:none;"
                         document.getElementById('saveP').style="display:none;"
                          document.getElementById('changeP').style="background-color: transparent;border: none;display: inline-block;"
                        document.getElementById('curr_password').style="display:none;"
                        document.getElementById('password').style="display:block;"
                        document.getElementById('password_confirmation').style="display:block;"

                        $('#passrules').show();
                   }else{
                        document.getElementById('errors').innerText='Password incorrect';
                        document.getElementById('errors').style="color:red;display:inline-block;"
                   }
                }
            })

       }

       function changePass(){

            var password=document.getElementById('password').value
            var password_confirmation=document.getElementById('password_confirmation').value

            var error=document.getElementById('errors')

            // password

             if(password!="" && password_confirmation!=""){

                if(password.length >= 6){

                    var countNum=0;
                    var countUppercase=0;
                    var countLowercase=0;
                    
                    var i=0;
                    var character='';

                    while (i <= password.length){
                        
                        character = password.charAt(i);
                        
                        if (!isNaN(character * 1)){

                            countNum++;

                        }else{
                            
                            if (character == character.toUpperCase()) {
                                
                                countUppercase++;

                            }
                            
                            if (character == character.toLowerCase()){

                                countLowercase++;

                            }

                        }

                        i++;

                    }

                    if(countNum >= 1 && countUppercase >= 1 && countLowercase >= 1){

                        if(password!=password_confirmation){

                            error.style="color:red;display:inline-block;"
                            error.innerHTML="Password do not match!";

                        }else{

                            document.getElementById('errors').innerText='Password matched!';
                            document.getElementById('errors').style="color:red;display:inline-block;"
                            document.getElementById('password').style="display:none;"
                            document.getElementById('password_confirmation').style="display:none;"
                            $('#passrules').hide();
                            document.getElementById('editP').style="display:inline-block;"
                            document.getElementById('changeP').style="display:none;"
                            document.getElementById('prevPass').style="display:inline-block;"

                            document.getElementById('passwordChForm').submit();

                        }

                    }else{

                        error.style="color:red;display:inline-block;"
                        error.innerHTML="Your Password should have atleast one character one uppercase and one lowercase letter!";

                    }

                }else{

                    error.style="color:red;display:inline-block;"
                    error.innerHTML="Password should be atleast 6 characters long..";

                    console.log('invalid pass length');

                }

            }else if (password=="" || password_confirmation==""){

                error.innerHTML='Enter the password!';
                error.style="color:red;display:inline-block;"
                console.log('empty');

            }

            
       }

       function imagePreview(path){
            

            //path.type for extendsion  image/jpeg image/png
            //path .size for size .... max for blob 65535 bytes
            if(path.size < 65535 && (path.type == 'image/jpeg' || path.type == 'image/png')){
                document.getElementById('preview').src = window.URL.createObjectURL(path);
                document.getElementById('imgeerror').style="display:none;color:white";

            }else{

                path=null;
                document.getElementById('preview').src = null;
                document.getElementById('imgeerror').innerHTML="Image should be less than 64 kb in size and image should have jpg or png extension!"
                document.getElementById('imgeerror').style="display:block;color:white";   
            }
        }

        function checkPic(){

            if(document.getElementById('imgeerror').style.display == 'none'
                && $('#imgfile').val()!=""){

                document.getElementById('changePicForm').submit();

            }else{
                if ($('#imgfile').val()=="") {

                    document.getElementById('imgeerror').innerHTML="Choose an image!"
                    document.getElementById('imgeerror').style="display:block;color:white"

                }
            }
        }
    </script>
    @endsection
</body>
</html>