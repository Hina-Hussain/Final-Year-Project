@extends('layouts.layout')
<!DOCTYPE html>
<html>
<head>
	<title>Account Rights - Validator</title>

    <style type="text/css">
    
    .table-title {
        color: #fff;
        background: #4b5366;        
        padding: 16px 25px;
        margin: -20px -25px 10px;
        border-radius: 3px 3px 0 0;
    }

    .table-title h2 {
        margin: 5px 0 0;
        font-size: 24px;
    }

    .table-wrapper {
        background: #fff;
        padding: 20px 25px;
        margin: 30px auto;
        border-radius: 3px;
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }

    .table-filter .filter-group {
        float: right;
        margin-left: 15px;
    }
    .table-filter input{
        height: 34px;
        border-radius: 3px;
        border-color: #ddd;
        box-shadow: none;
    }
    .table-filter {
        padding: 5px 0 15px;
        margin-bottom: 5px;
    }
    .table-filter .btn {
        height: 34px;
    }
    .table-filter input {
        display: inline-block;
        margin-left: 5px;
    }
    .table-filter input {
        width: 200px;
        display: inline-block;
    }
    </style>


</head>
<body>

	@section('content')

	<br>

	    <div class="content-wrap">
	        <div class="main">
	            <div class="container-fluid">

                    <div class="table-wrapper">
                        <div class="table-title">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h2 class="text-white">Manage <b>Account rights</b></h2>
                                </div>
                            </div>
                        </div>
    
	                <main role="main">
	                    <div class="col-sm-12 align-items-center">

	                        <ul class="nav nav-tabs" id="pills-tab" role="tablist">
	                            <li class="nav-item">
	                                <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#rolestab" role="tab" aria-controls="rolestab" aria-selected="true"><span><i class="fa fa-briefcase"></i> Roles </span></a>
	                            </li>
	                            <li class="nav-item">
	                                <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pretab" role="tab" aria-controls="pretab" aria-selected="false"><span><i class="fa fa-universal-access"></i> Previleges </span></a>
	                            </li>
	                        </ul>

	                        <br>
	                        <div class="tab-content" id="pills-tabContent">

                            @if($flash=session('success'))

                            <div class="alert alert-success text-white" role="alert">
                              {{$flash}}
                            </div>

                            @endif

                            @if($flash=session('delete'))                            
                            <div class="alert alert-danger text-white" role="alert">
                               {{$flash}}
                            </div>

                            @endif
	                            
	                            <div class="tab-pane fade show active" id="rolestab" role="tabpanel" aria-labelledby="rolestab">
	            <section id="posts">
                    <div>
                        <div class="row">

                            <div class="col">
                                <div>
                                    <div class="card-header">

                                    	<div style="float:right;display: block;">
		                                    <button class="btn btn-primary" id="createRolebtn" onclick="createRole()">
                                            <i class="fa fa-plus-circle" style="color: white;font-size: 14px;">
                                                <p style="display: inline;" class="text-white">Add New Role</p>
                                            </i>      
                                            </button>
		                                </div>

		                                <br>
		                                <br>

                                    </div>
                                    <table class="table table-striped" style="clear: both;">
                                        <thead>
                                            <tr>
                                                <th style="text-align: left">Id</th>
                                                <th style="text-align: left">Role Name</th>
                                                <th style="text-align: left">Role Desc</th>
                                                <th style="text-align: left"></th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach($res as $value)

                                          	<tr>
                                          		<td>{{$value->id}}</td>
                                          		<td>{{ucwords($value->name)}}</td>
                                          		<td>{{strtolower($value->desc)}}.</td>
                                          		
                                                <td>
                            <button class="btn btn-info" id="viewbtn{{$value->id}}" onclick=
                            'viewRoleInfo({{$value->id}})' title="view role info">

                            <i class=" fa fa-info-circle"></i>

                            </button> 

                            @if($value->id != 1 && $value->id != 2 && $value->id != 3 && session('accInfo')[0]->role == 1)

                                <button class="btn btn-danger" id="delbtn{{$value->id}}" onclick=
                                'deleteRole({{$value->id}})' title="delete role">

                                <i class=" fa fa-trash"></i>

                                </button>

                            @endif
                            
                                                </td>
                                          	</tr>

                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </section>

	                            </div>


	                            <div class="tab-pane fade" id="pretab" role="tabpanel" aria-labelledby="pretab">
	                             
	            <section id="posts">
                    <div>
                        <div class="row">

                            <div class="col">
                                <div>

                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th style="text-align: left">Id</th>
                                                <th style="text-align: left">Previlege Name</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach($res2 as $value)
                                          	<tr>
                                          		<td>{{$value->id}}</td>
                                          		<td style="text-align: left">{{ucfirst($value->prevDesc)}}</td>
                                          	</tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </section>

	                            </div>
	                        </div>

	                    </div>
	                </main>
	            </div>
	        </div>
	    </div>
    </div>
	    
    <dir id="modals"></dir>

	    <!-- end modal -->
	@endsection

	@section('scripts')

	<script type="text/javascript">
        

        document.getElementById('dashboard').classList.remove('active');

        document.getElementById('staff').classList.remove('active');
        
        document.getElementById('students').classList.remove('active');
        
        document.getElementById('account_rights').classList.add('active');
        
        document.getElementById('verstudents').classList.remove('active');
        
        document.getElementById('profile').classList.remove('active');
        
        document.getElementById('log').classList.remove('active');
        
        document.getElementById('setting').classList.remove('active');


        function viewRoleInfo(id){

            $('#viewbtn'+id).attr('disabled','disabled');

            $.get('{{ URL::to("/account_rights/info") }}?q='+id,function(data){
                
                $('#modals').empty().append(data);
                $('#viewaccrights').modal('toggle');
                $('#viewbtn'+id).attr('disabled',false);
            });

        }

        function deleteRole(id){

            $('#delbtn'+id).attr('disabled','disabled');

            $.get('{{ URL::to("/account_rights/delete") }}?q='+id,function(data){
                
                $('#modals').empty().append(data);
                $('#delaccrights').modal('toggle');
                $('#delbtn'+id).attr('disabled',false);
            });

        }

        function createRole(){

            $('#createRolebtn').attr('disabled','disabled');

            $.get('{{ URL::to("/account_rights/create") }}',function(data){
                
                $('#modals').empty().append(data);
                $('#addRole').modal({backdrop: 'static', keyboard: false});
                $('#createRolebtn').attr('disabled',false);
            });            
        }

        function clicked(id){

            if(document.getElementById(id).checked){

                document.getElementById('pd'+id).style="font-weight:bold;color:black;";

            }else{

                document.getElementById('pd'+id).style="font-weight:normal;color:black;";

            }
        }

        $('#modals').on('click','#submitdelete',function(){

            $('#submitdelete').attr('disabled','disabled');

            document.getElementById('deleteform').submit();

        });

        $('#modals').on('click','#submitFormChanges',function(){

            error=document.getElementById('error');

            prevs=$(this).data('prevs');

            console.log(prevs);

            if($('#role_name').val().trim()!=""){

                $.get('{{ URL::to("/employees/roles") }}'+"?q="+$('#role_name').val().trim(), function(data){
                
                if(data==true){
                    // role exists

                    error.style+="display:block;color:white;text-align:left;";
                    error.innerHTML="Role name not available!"; 

                    $prob=true;

                    $('#submitFormChanges').attr('disabled',false);
                    $('#addRole').scrollTop(0);

                }else{

                    //role doesn't exists

                    if($('#role_desc').val().trim()!=""){

                        count=0;
                        
                        for(i=0;i<prevs.length;i++){

                            if(document.getElementById(prevs[i].id).checked){

                                count=0;

                                break; 

                            }else{
                                count=1;
                            }

                        }

                        console.log("countend: "+count);

                        if(count==0){

                            document.getElementById("addRoleForm").submit();
                        }else{

                            error.style+="display:block;color:white;text-align:left";
                                    
                            error.innerHTML="Select privileges for this role!";

                            $('#submitFormChanges').attr('disabled',false);
                            $('#addRole').scrollTop(0);

                        }
                            
                    }else{
                        
                        error.style+="display:block;color:white;text-align:left";
                        error.innerHTML="Enter the role description!"; 

                        $prob=true;

                        $('#submitFormChanges').attr('disabled',false);
                        $('#addRole').scrollTop(0);
                    }
                }

            });

            }else{

                error.innerHTML="Enter the role name!"
                error.style="display:flex;text-align:left"
                $('#addRole').scrollTop(0);

            }

        });

    </script>


	@endsection
</body>
</html>