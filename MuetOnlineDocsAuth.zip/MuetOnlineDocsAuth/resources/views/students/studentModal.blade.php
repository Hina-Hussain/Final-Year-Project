
<!--changings 7/6/18  -->
<!-- Edit Student Info and other info modal -->
<!-- modaE and ModalM class removed  21/6/18-->
<div class="modal fade" id="EditSModal">
<div class="modal-dialog modal-lg" id="editinfo">
<div class="modal-content">
<div class="modal-header bg-success text-white">
<h5 class="modal-title text-white" id="addEModalLabel">Update Student Info - {{ucwords($user->fullname)}} </h5>

<button class="close text-white" data-dismiss="modal">
<span>&times;</span>
</button>

</div>

<div class="col-sm-12">
<ul class="nav nav-pills nav-fill" id="myTab" role="tablist">
<li class="nav-item" id="pinfo">
<a class="nav-link active" id="pinfo-tab" href="#PInfo" 
 role="tab" aria-controls="home" aria-selected="true"
 data-toggle="tab">Personal Information</a>
</li>

<li class="nav-item" id="transInfo">
<a class="nav-link" id="trans-tab" data-toggle="tab" href="#TransInfo" role="tab" aria-controls="profile" aria-selected="false">Transcript Information</a>
</li>
<li class="nav-item" id="otherinfo">
<a class="nav-link" id="other-tab" href="#OtherInfo" 
data-toggle="tab" role="tab" aria-controls="contact2" aria-selected="false">Other Information</a>
</li>
</ul>
<div class="tab-content" id="myTabContent">
<!-- Personal Info Start -->

<div class="tab-pane fade show active" id="PInfo" role="tabpanel" aria-labelledby="home-tab">
<div class="col-sm-12">
	
@include('students.editPInfo')
</div>
</div>
<!-- Personal end -->

<!-- Transcript Info Start -->
<div class="tab-pane fade" id="TransInfo" role="tabpanel" aria-labelledby="profile-tab">

<br><br>
<div class="col-sm-12">

  @include('students.editTranscript')

</div>

@if(strchr(strtolower($system->name),"obe")==TRUE)
<!-- OBE System Rows Start -->
<div class="row" id="obesystem">
<br><br>
@include('students.obeTranscript')
</div>
@endif

</div>

<!-- Transcript Info End -->

<!-- Other Info Start -->
<div class="tab-pane fade" id="OtherInfo" role="tabpanel" aria-labelledby="contact-tab">
  @include('students.editOtherInfo')
</div>
<!-- Other Info end -->

</div>
</div>
</div>
</div>
</div>



<!-- disable tabs according to priviliges-->


<script type="text/javascript">


function show()
{
	 //$("#EditSModal").scrollTo(9999);
 var txt1 = '<form class="form-horizontal" role="form" method="post" action="/student/sendEmail">@csrf<div class="form-group"><h4>Please enter email to send a review request</h4><br><label for="email" class="form-control-label">Email Address</label><input type="email" class="form-control" required name="email"></div><div class="form-group"><label for="textarea" class="control-label">Message</label><textarea class="form-control" name="body" required></textarea></div><div class="pull-right"><button class="btn btn-success" type="submit">Send</button></div></form>';
    

    $("#mydiv").empty().append(txt1);
}

@php
if(array_key_exists('5',$prev) && array_key_exists('6',
	$prev) && array_key_exists('7',$prev))
{
  @endphp
	// all 3 privilige

  $('#myTab2 a').on('click', function (e) {
  e.preventDefault()
  $(this).tab('show')
})

$('#myTab a').on('click', function (e) {
  e.preventDefault()
  $(this).tab('show')
})

@php
	
}
else if(array_key_exists('6',$prev) && !array_key_exists('5',$prev) && !array_key_exists('7',$prev))

{  // only can edit personal info
@endphp
  $('#trans-tab').addClass('disable');
  $('#trans-tab').removeAttr('data-toggle');

  $('#other-tab').addClass('disable');
  $('#other-tab').removeAttr('data-toggle');
@php
}

else if(array_key_exists('5',$prev) && !array_key_exists('6',$prev) && !array_key_exists('7',$prev)) 

{ // only edit otherInfo
@endphp
$('#pinfo-tab').addClass('disable');
$('#pinfo-tab').removeClass('active');
$('#pinfo-tab').removeAttr('data-toggle');
$('#PInfo').removeClass('show');
$('#PInfo').removeClass('active');

$('#trans-tab').addClass('disable');
$('#trans-tab').removeAttr('data-toggle');

$('#other-tab').addClass('active');
$('#OtherInfo').addClass('active');
$('#OtherInfo').addClass('show');
@php 
}

else if(array_key_exists('7',$prev) && !array_key_exists('5',$prev) && !array_key_exists('6',$prev))

{  // only edit transcript
@endphp
$('#trans-tab').addClass('active');
$('#TransInfo').addClass('active');
$('#TransInfo').addClass('show');

$('#pinfo-tab').addClass('disable');
$('#pinfo-tab').removeClass('active');
$('#pinfo-tab').removeAttr('data-toggle');
$('#PInfo').removeClass('show');
$('#PInfo').removeClass('active');

$('#other-tab').addClass('disable');
$('#other-tab').removeAttr('data-toggle');

@php
}

else if(array_key_exists('5',$prev) && array_key_exists('7',$prev) && !array_key_exists('6',$prev))

{ // only edit transcript and otherInfo 
@endphp
 $('#myTab2 a').on('click', function (e) {
  e.preventDefault()
  $(this).tab('show')
})
$('#pinfo-tab').addClass('disable');
$('#pinfo-tab').removeClass('active');
$('#pinfo-tab').removeAttr('data-toggle');
$('#PInfo').removeClass('show');
$('#PInfo').removeClass('active');

$('#trans-tab').tab('show')


$('#other-tab').on('click', function (e) {
e.preventDefault()
  $('#other-tab').tab('show')
})

$('#trans-tab').on('click', function (e) {
e.preventDefault()
  $('#trans-tab').tab('show')
})


@php
}
else if(array_key_exists('5',$prev) && array_key_exists('6',$prev) && !array_key_exists('7',$prev))

{ // only edit stdInfo and otherInfo
@endphp

$('#myTab2 a').on('click', function (e) {
  e.preventDefault()
  $(this).tab('show')
})

$('#trans-tab').addClass('disable');
$('#trans-tab').removeAttr('data-toggle');



$('#other-tab').on('click', function (e) {
e.preventDefault()
  $('#other-tab').tab('show')
})
$('#pinfo-tab').on('click',function(e){
  e.preventDefault()
  $('#pinfo-tab').tab('show')
})

@php
}
else if(array_key_exists('6',$prev) && array_key_exists('7',$prev) && !array_key_exists('5',$prev))

{  // only edit stdInfo and transInfo
@endphp
$('#other-tab').addClass('disable');
$('#other-tab').removeAttr('data-toggle');
@php
}
@endphp
</script>