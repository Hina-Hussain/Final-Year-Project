<div class="modal fade" id="ViewSModal">
<div class="modal-dialog modal-lg">
<div class="modal-content">


<!-- Tab panes -->


<div class="modal-header bg-info  text-white">
<h5 class="modal-title text-white" id="addEModalLabel">Student Profile - {{ucwords($res->fullname)}}</h5>
<button class="close text-white" data-dismiss="modal">
<span>&times;</span>
</button>
</div>
<div class="modal-body">
<form class="form-horizontal" role="form" method="post" action="#">
<div class="col-sm-12">
<div>
<div class="card-user">
<div class="author2">
<a href="#">
<img class="avatar border-gray" src="{{ asset('storage/uploads/students/'.$res->pic)}}" alt="...">
</a>
</div>
<div class="Username">
<p style="text-align: center;font-size: 2em;color: black;font-style: bold;font-family: 'Raleway', sans-serif;margin-bottom: 2px">

    {{ucwords($res->fullname)}}

  </p>

 <p style="text-align: center;font-size: 1.75em;font-family: 'Raleway', sans-serif;margin-top: 2px;letter-spacing: 2px" class="lead">
       {{ucwords(json_decode($res->currentPosition)->curPos)}}
  </p>

 </div>


<!-- Nav tabs -->
<ul class="nav nav-tabs nav-justified customtab2" role="tablist">
<li class="nav-item col-sm-4" > <a class="nav-link active" data-toggle="tab" href="#PInformation" role="tab"><span><i class="fa fa-user-circle"></i> Personal Information</span></a> </li>
<li class="nav-item col-sm-4">
<a class="nav-link" data-toggle="tab" href="#AInfo" role="tab"> <span><i class="ti-blackboard"></i> Academic Information</span></a>
</li>
<li class="nav-item col-sm-4">
<a class="nav-link" data-toggle="tab" href="#SettingInfo" role="tab"> <span><i class="ti-pencil-alt"></i> Settings</span></a>
</li>
</ul>



<!--PErsonal Information-->            
<div class="tab-content">
<div class="tab-pane active" id="PInformation" role="tabpanel">
<div>
<div>
<div class="tab-content">
<div>
<div class="contact-information">
<legend>Personal Information</legend>
<div class="phone-content">
<span class="contact-title">Full Name:</span>
<span class="phone-number">
	{{ucwords($res->fullname)}}

</span>
</div>
<div class="phone-content">
<span class="contact-title">Father Name:</span>
<span class="phone-number">
	{{ucwords($res->fatherName)}}

</span>
</div>
<div class="phone-content">
<span class="contact-title"> Surname:</span>
<span class="phone-number">
	{{ucwords($res->surname)}}
</span>
</div>
<div class="phone-content">
<span class="contact-title">CNIC:</span>
<span class="phone-number">{{$res->cnic}}</span>
</div>
<div class="gender-content">
<span class="contact-title">Date Of Birth:</span>
<span class="gender" type="date" name="bday" >{{$res->dob}}</span>
</div>

<div class="gender-content">
<span class="contact-title">Gender:</span>
<span class="gender">
	
  {{ $res->gender== 'm' ? 'Male' : 'Female' }} 

</span>
</div>
</div>

<div class="contact-information">

<legend>Address & Contact Information</legend>
<div class="phone-content">
<span class="contact-title">Cell Phone:</span>
<span class="phone-number">{{$res->mbNo}}</span>
</div>
      <div class="phone-content">
<span class="contact-title">Address:</span>
<span class="phone-number">{{$res->addr}}</span>
</div>
<div class="phone-content">
<span class="contact-title">Email:</span>
<span class="phone-number">{{$res->email}}</span>
</div>


<div class="gender-content">
<span class="contact-title">Domicile:</span>
<span class="gender" type="date" name="bday" >
	
	{{ucwords($res->domicile)}}
</span>
</div>
<div class="phone-content">
<span class="contact-title">Province:</span>
<span class="phone-number">
	{{ucwords($res->province)}}
</span>
</div>
<div class="phone-content">
<span class="contact-title">Country:</span>
<span class="phone-number">
	{{ucwords($res->country)}}
</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<!-- tab2 -->
<div class="tab-pane p-20" id="AInfo" role="tabpanel">
<div class="col-sm-12">
<div class="row">
<div class="col-sm-6">
<div class="basic-information">
<legend>Academic Information</legend>
<div class="phone-content">
<span class="contact-title">Roll No:</span>
<span class="phone-number">
	{{strtoupper($res->rollNo)}}
</span>
</div>

</div>
<div class="phone-content">
<span class="contact-title">Enrollment No:</span>
<span class="phone-number">
	{{$res->enrollmentNo}}
</span>
</div>                               
 <div class="phone-content">
<span class="contact-title">Department:</span>
<span class="phone-number">
   {{
    chop(ucwords($res->dept),"Engineering")
  }}
	
</span>
</div>
<div class="phone-content">
<span class="contact-title">Date Of Admission:</span>
<span class="phone-number">{{$res->doa}}</span>
</div>

<div class="phone-content">
<span class="contact-title  ">Programme:</span>
<span class="phone-number">
   {{strtoupper($res->programme)}}
</span>
    
</div>
              
<div class="phone-content">
<span class="contact-title">CGPA:</span>
<span class="phone-number">{{$degree->cgpa}}</span>
</div>
              <div class="phone-content">
<span class="contact-title">Position:</span>
@php
if($degree->position==1){$position = "1st";}
elseif($degree->position==2){$position = "2nd";}
elseif($degree->position==3){$position = "3rd";}
else
{$position = "None";}
@endphp
<span class="phone-number">{{$position}}</span>
</div>
              <div class="phone-content">
<span class="contact-title">Last Exam Held:</span>
<span class="phone-number">{{$degree->doe}}</span>
</div>
</div>
</div>

</div>
</div>

<!------------- SETTINGS ------------------------>


<div class="tab-pane p-20" id="SettingInfo" role="tabpanel">
<div class="col-sm-12">
	
<div class="row">
<div class="col-sm-8">


<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label">Mobile No:</label>
<div class="col-sm-8">
<input type="text" name="mobno" class="form-control"
 id="mobno" placeholder="enter mobile no" 
 value="{{$res->mbNo}}" required style="display: none;width: 100%" minlength="11" maxlength="11">

<p style="font-size: 1.25em;" class="lead" id="prevmobno">{{$res->mbNo}}</p>

</div>

<div class="col-sm-1 mr-7" id="editNo">
<a href="#" onclick="editMob()" id="editmob"><i class="btn fa fa-edit" title="Edit" style="color: #FFC107;">

</i></a>

<a href="#" onclick="saveMob('{{$res->rollNo}}')" id="savemob" style="display: none;"><i class="btn fa fa-check-circle-o" title="Save" style="color: green"></i></a>


</div>

<p class="mb-1 hidden" style="width:100%;color:red;display: none;" id="errors1">
	
</p>

<p class="mb-1" style="width:100%;color:green;display: none;" id="success1"></p>

</div>



<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label">Email:</label>
<div class="col-sm-8">

<input type="email" name="mail" class="form-control"
 id="mail" placeholder="enter email" 
 value="{{$res->email}}" required style="display: none;width: 100%">

<p style="font-size: 1.25em;" class="lead" id="prevmail">{{$res->email}}</p>

</div>
<div class="col-sm-1 mr-7" id="editSaveB">
<a href="#" onclick="editMail()" id="editmail"><i class="btn fa fa-edit" title="Edit" style="color: #FFC107;"></i></a>

<a href="#" onclick="saveMail('{{$res->rollNo}}')" id="savemail" style="display: none;"><i class="btn fa fa-check-circle-o" title="Save" style="color: green;"></i></a>

</div>
<p class="mb-1 hidden" style="width:100%;color:red;display: none;" id="errors2"></p>

<p class="mb-1" style="width:100%;color:green;display: none;" id="success2"></p>
</div>



<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label">Address:</label>
<div class="col-sm-8">

<input type="text" name="addr" class="form-control"
 id="addr" placeholder="enter address" 
 value="{{$res->addr}}" required style="display: none;width: 100%">

<p style="font-size: 1.25em;" class="lead" id="prevaddr">{{$res->addr}}</p>


</div>
<div class="col-sm-1 mr-7" id="editA">

<a href="#" onclick="editAddr()" id="editaddr"><i class="btn fa fa-edit" title="Edit" style="color: #FFC107;">
	
</i></a>

<a href="#" onclick="saveAddr('{{$res->rollNo}}')" id="saveaddr" style="display: none;"><i class="btn fa fa-check-circle-o" title="Save" style="color: green"></i></a>
</div>

<p class="mb-1 hidden" style="width:100%;color:red;display: none;" id="errors3"></p>

<p class="mb-1" style="width:100%;color:green;display: none;" id="success3"></p>

</div>


<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label">Current Position:</label>
<div class="col-sm-8">

<input type="text" name="currPos" class="form-control"
 id="currPos" placeholder="enter current Position" 
 value=" {{ucwords(json_decode($res->currentPosition)->curPos)}}" required style="display: none;width: 100%">

<p style="font-size: 1.25em;" class="lead" id="prevCP"> {{ucwords(json_decode($res->currentPosition)->curPos)}}
</p>
</div>
<div class="col-sm-1 mr-7" id="editCP">
<a href="#" onclick="editCP()" id="editCp"><i class="btn fa fa-edit" title="Edit" style="color: #FFC107;">
	
</i></a>

<a href="#" onclick="saveCP('{{$res->rollNo}}')" id="saveCp" style="display: none;"><i class="btn fa fa-check-circle-o" title="Save" style="color: green;"></i></a>


</div>
<p class="mb-1 hidden" style="width:100%;color:red;display: none;" id="errors4"></p>

<p class="mb-1" style="width:100%;color:green;display: none;" id="success4"></p>


</div>

<!-- Added-->
@php
if(json_decode($res->currentPosition)->orgName==""||
  json_decode($res->currentPosition)->orgName==null)
  {$orgname = "None";
  
   }
  else
  {$orgname = json_decode($res->currentPosition)->orgName;
 }
 if(json_decode($res->currentPosition)->type==1)
 {
  $value = 1;
 }
 elseif(json_decode($res->currentPosition)->type==2)
 {
  $value = 2;}
 elseif(json_decode($res->currentPosition)->type==3)
 {
  $value = 3;
 }
 else
 {$value = 0;}
@endphp

<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label">Organization Name:</label>
<div class="col-sm-8">

<input type="text" name="orgname" class="form-control"
 id="orgname" placeholder="enter organization name" 
 value="{{ucwords($orgname)}}" required style="display: none;width: 100%">

<p style="font-size: 1.25em;" class="lead" id="prvorgname"> {{ucwords($orgname)}}</p>
</div>
<div class="col-sm-1 mr-7">
<a href="#" onclick="editOrg()" id="editOrg"><i class="btn fa fa-edit" title="Edit" style="color: #FFC107;">
  
</i></a>

<a href="#" onclick="saveOrg('{{$res->rollNo}}')" 
  id="saveOrg" style="display: none;"><i class="btn fa fa-check-circle-o" title="Save" style="color: green;"></i></a>
  

</div>
<div class="radio-inline" style="margin-left: 25%;margin-top: 5%;" id="orgtype">
  <input type="radio" name="type" value="1" id="govr" disabled>Government &ensp;

  <input type="radio" name="type" value="2" id="semigovr"
  disabled>
 Semi Governemt &ensp;
  
  <input type="radio" name="type" value="3" id="private"
  disabled>Private &ensp;
</div>
<p class="mb-1 hidden" style="width:100%;color:red;display: none;" id="errors5"></p>

<p class="mb-1" style="width:100%;color:green;display: none;" id="success5"></p>


</div>
</div>
</div>
</div>
</div>



</div>
</div>

</div>
</div>
</div>
</div>

<script type="text/javascript">
function editMob()
{
document.getElementById('editmob').style = "display:none";
document.getElementById('savemob').style = "display:inline-block";
document.getElementById('prevmobno').style = "display:none";
document.getElementById('mobno').style = "display:inline-block";

}

function saveMob(id)
{

 var mobno = $('#mobno').val().trim();
 var prevmob = $('#prevmobno').text();
  var numbers = /^[0-9]+$/;

 if(mobno=="")
 {
  document.getElementById('success1').style = "display:none";
 	document.getElementById('errors1').style="color:red;display:inline-block;";

 	document.getElementById('errors1').innerHTML = "Mobile number field is required!";

 }

else if(mobno==prevmob)
 {
  document.getElementById('editmob').style = "display:inline-block";
    document.getElementById('savemob').style = "display:none";
  document.getElementById('prevmobno').style = "display:inline-block;";

document.getElementById('mobno').style = "display:none";
document.getElementById('errors1').style= "display:none";
	
	document.getElementById('success1').style = "display:none";
 }

else if(!mobno.match(numbers))
{
  document.getElementById('success1').style = "display:none";

  document.getElementById('errors1').style="color:red;display:inline-block;";

  document.getElementById('errors1').innerHTML = "Only numeric characters are allowed!";

}

else if(mobno.length!=11)
  {
    document.getElementById('success1').style = "display:none";
    
    document.getElementById('errors1').style="color:red;display:inline-block;";

  document.getElementById('errors1').innerHTML = "Mobile number must be in 11 digits";
  }


 else if(mobno.length==11 && mobno.match(numbers))
 {
 	$.ajax({
 	type:"get",
 	url : '{{ URL::to("/settings/mobno")}}/'+id,
 	data:{'mobno':mobno,'prevmobno':prevmob},
 	success:function(response)
 	{
     if(response=="TRUE")
     {
   document.getElementById('editmob').style = "display:inline-block";
    document.getElementById('savemob').style = "display:none";
  document.getElementById('prevmobno').style = "display:inline-block";

document.getElementById('mobno').style = "display:none";
     $('#prevmobno').text(mobno);

  document.getElementById('errors1').style = "display:none";
   document.getElementById('success1').style="color:green;display:inline-block;";

 	document.getElementById('success1').innerHTML = "Successfully Update!";


     }
 	}
 	});
 }

 
}


function editMail() {
  document.getElementById('editmail').style = "display:none";

  document.getElementById('savemail').style = "display:inline-block";
document.getElementById('prevmail').style = "display:none";
document.getElementById('mail').style = "display:inline-block";


}

function saveMail(id)
{
	var mail = $('#mail').val().trim();
	var oldmail = $('#prevmail').text();

if(mail==oldmail)
{
	 document.getElementById('editmail').style = "display:inline-block";

  document.getElementById('savemail').style = "display:none";
document.getElementById('prevmail').style = "display:inline-block";
document.getElementById('mail').style = "display:none";

document.getElementById('errors2').style= "display:none";
	
	document.getElementById('success2').style = "display:none";
}
else if(mail=="")
{
	document.getElementById('success2').style = "display:none";
	document.getElementById('errors2').style = "color:red;display:inline-block;";
	document.getElementById('errors2').innerHTML = "Email field is required";
}

else if(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
  {
  $.ajax({
   type:"get",
   url : "{{ URL::to('/settings/email')}}/"+id,
   data: {"mail":mail,"prevmail":oldmail},
   success:function(response)
   {
   if(response=="TRUE")
   {
   	 document.getElementById('editmail').style = "display:inline-block";

  document.getElementById('savemail').style = "display:none";
document.getElementById('prevmail').style = "display:inline-block";
$('#prevmail').text(mail);
document.getElementById('mail').style = "display:none";
 
 document.getElementById('errors2').style = "display:none";
   document.getElementById('success2').style="color:green;display:inline-block;";

 	document.getElementById('success2').innerHTML = "Successfully Update!";

   }
   }
  });
}
else
{
	document.getElementById('success2').style = "display:none";

	document.getElementById('errors2').style = "color:red;display:inline-block";
	document.getElementById('errors2').innerHTML = "The email must be a valid email address.";

}
}

function editAddr() {
	 document.getElementById('editaddr').style = "display:none";

  document.getElementById('saveaddr').style = "display:inline-block";
document.getElementById('prevaddr').style = "display:none";
document.getElementById('addr').style = "display:inline-block";


}

function saveAddr(id){
	var address = $('#addr').val().trim();
	var oldaddr = $('#prevaddr').text();

	if(address==oldaddr)
	{
	document.getElementById('errors3').style = "display:none";
	
	document.getElementById('success3').style = "display:none";
		
  document.getElementById('editaddr').style = "display:inline-block";

   document.getElementById('saveaddr').style = "display:none";
 document.getElementById('prevaddr').style = "display:inline-block";
 document.getElementById('addr').style = "display:none";
	}
else if(address=="")
{
 document.getElementById('success3').style = "display:none";
 document.getElementById('errors3').style = "color:red;display:inline-block";
 document.getElementById('errors3').innerHTML = "Address field is required";
}
else
{
 $.ajax({
 	type:"get",
 	url : "{{URL::to('/settings/address')}}/"+id,
 	data : {'addr':address,'prevaddr':oldaddr},
 	success:function(response)
 	{
   if(response=="TRUE")
   {
   	 document.getElementById('editaddr').style = "display:inline-block";

   document.getElementById('saveaddr').style = "display:none";
 document.getElementById('prevaddr').style = "display:inline-block";
 $('#prevaddr').text(address);
 document.getElementById('addr').style = "display:none";
 document.getElementById('errors3').style = "display:none";
 document.getElementById('success3').style = "color:green;display:inline-block";
 document.getElementById('success3').innerHTML = "Successfully Update!";
   }
 	}
 });
}	
}

function editCP()
{
	 document.getElementById('editCp').style = "display:none";

  document.getElementById('saveCp').style = "display:inline-block";
document.getElementById('prevCP').style = "display:none";
document.getElementById('currPos').style = "display:inline-block";


}

function saveCP(id)
{
 var currPos = $('#currPos').val().trim();
 var prevCP =  $('#prevCP').text();
  

 if(currPos==prevCP)
 {
 	document.getElementById('errors4').style = "display:none";
	
	document.getElementById('success4').style = "display:none";

	document.getElementById('editCp').style = "display:inline-block";

  document.getElementById('saveCp').style = "display:none";
document.getElementById('prevCP').style = "display:inline-block";
document.getElementById('currPos').style = "display:none";

 }
 else if(currPos=="")
 {
 	document.getElementById('errors4').style = "color:red;display:inline-block";
 	document.getElementById('errors4').innerHTML = "Current Position field is required";
	
	document.getElementById('success4').style = "display:none";

 }

 else
 {
 	$.ajax({
 	type:"get",
 	url : "{{URL::to('/settings/currPos')}}/"+id,
 	data:{'currPos':currPos,'prevPos':prevCP},
 	success:function(response)
 	{
    if(response=="TRUE")
    {
    	document.getElementById('errors4').style = "display:none";
	
	document.getElementById('editCp').style = "display:inline-block";

  document.getElementById('saveCp').style = "display:none";
document.getElementById('prevCP').style = "display:inline-block";
$('#prevCP').text(currPos);

document.getElementById('currPos').style= "display:none";
    
document.getElementById('success4').style = "color:green;display:inline-block";
document.getElementById('success4').innerHTML="Successfully Update!";
    }
 	}
 	});
 }	
}

function editOrg()
{
 

document.getElementById('saveOrg').style = "display:inline-block";
document.getElementById('editOrg').style = "display:none";
  
document.getElementById('prvorgname').style = "display:none";
document.getElementById('orgname').style = "display:inline-block";
document.getElementById('orgtype').style="display:inline-block;margin-top:5%;margin-left:25%;";
 
 $('#govr').removeAttr('disabled');
$('#semigovr').removeAttr('disabled');
$('#private').removeAttr('disabled');
}

function saveOrg(id)
{
  var orgname  = $('#orgname').val().trim();
  var prevname = $('#prvorgname').text();
 var orgType = $("input[name='type']:checked").val();

if(orgname==prevname)
{
  document.getElementById('errors5').style = "display:none";
  
  document.getElementById('success5').style = "display:none";

  document.getElementById('editOrg').style = "display:inline-block";

  document.getElementById('saveOrg').style = "display:none";
document.getElementById('prvorgname').style = "display:inline-block";
document.getElementById('orgname').style = "display:none";


 $('#govr').attr('disabled',true);
$('#semigovr').attr('disabled',true);
$('#private').attr('disabled',true);

}

else if(orgname=="")
{
 document.getElementById('success5').style = "display:none";
 document.getElementById('errors5').style = "color:red;display:inline-block";
 document.getElementById('errors5').innerHTML = "Organization name is required";
}

 else
 {
  $.ajax({
  type:"get",
  url : "{{URL::to('/settings/orgName')}}/"+id,
  data:{'orgName':orgname,'prevOrg':prevname,"orgType":orgType},
  success:function(response)
  {
    if(response=="TRUE")
    {
      document.getElementById('errors5').style = "display:none";
  
  document.getElementById('editOrg').style = "display:inline-block";

  document.getElementById('saveOrg').style = "display:none";
document.getElementById('prvorgname').style = "display:inline-block";
$('#prvorgname').text(orgname);

document.getElementById('orgname').style= "display:none";
    
document.getElementById('success5').style = "color:green;display:inline-block";
document.getElementById('success5').innerHTML="Successfully Update!";
  $('#govr').attr('disabled',true);
 $('#semigovr').attr('disabled',true);
 $('#private').attr('disabled',true);

if(orgType==1)
{document.getElementById('govr').setAttribute("checked", "checked");}

else if(orgType==2)
{
  document.getElementById('semigovr').setAttribute("checked", "checked");
}
else if(orgType==3)

{document.getElementById('private').setAttribute("checked", "checked");}

    }
  }
  });
 }
}

 if("{{$value}}"==1)
{document.getElementById('govr').setAttribute("checked", "checked");}

else if("{{$value}}"==2)
{
  document.getElementById('semigovr').setAttribute("checked", "checked");
}
else if("{{$value}}"==3)

{document.getElementById('private').setAttribute("checked", "checked");}


</script>

