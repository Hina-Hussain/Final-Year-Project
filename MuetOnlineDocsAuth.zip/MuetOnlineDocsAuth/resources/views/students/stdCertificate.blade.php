@php
$date = date_create($degreeInfo->doe);
$year = date_format($date,"Y");
$month = date_format($date,"m");
if($month=='01' || $month==1){$name = "January";}
elseif($month=='02' || $month==2){$name = "February";}
elseif($month=='03' || $month==3){$name = "March";}
elseif($month=='04' || $month==4){$name = "April";}
elseif($month=='05 '|| $month==5){$name = "May";}
elseif($month=='06' || $month==6){$name = "June";}
elseif($month=='07' || $month==7){$name = "July";}
elseif($month=='08' || $month==8){$name = "August";}
elseif($month=='09' || $month==9){$name = "September";}
elseif($month=='10') {$name = "October";}
elseif($month=='11'){$name = "November";}
elseif($month=='12'){$name = "December";}
$position = $degreeInfo->position;
if($position==1){$value = "First";}
elseif($position==2){$value = "Second";}
elseif($position==3){$value = "Third";}
else
	{$value = "";}
@endphp	

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Student Certificate</title>


<!-- Styles -->

@section('styles1')

<link href="/assets/css/lib/weather-icons.css" rel="stylesheet" />
<link href="/assets/css/lib/owl.carousel.min.css" rel="stylesheet" />
<link href="/assets/css/lib/owl.theme.default.min.css" rel="stylesheet" />
<link href="/assets/css/lib/helper.css" rel="stylesheet">
@endsection

<!-- Styles for inner -->

@section('styles2')
@endsection
<style type="text/css">
p,div {
color: black;
}

  
    .marksSheet th,td{

      padding: 10px;
      border:1px black solid;
     color: black;
    }

    .marksSheet{
      width:100%;
      margin-top:10%;
      text-align: left;
    }

    .year{
      width: 5%;
    }

    .sems{
      width: 5%;
    }

    .subject{
      width: 55%
    }

    .maxM{
      width: 5%;
    }

    .minM{
      width: 5%;
    }

    .mObt{
      width: 5%;
    }

    .grade{
      width: 5%;
    }

    .gpa{
      width: 5%;
    }

    .cgpa{
      width: 5%;
    }

    .chr{
      width: 5%;
    }

}
  


</style>

<script type="text/javascript" src="/js/qrcode/qrcode.js"></script>

</head>

<body>
@extends('layouts.layout')
@section('content')
<!--TABS START-->
<div class="content-wrap">
<div class="main">
<div class="container-fluid">
<br>
<div class="col-sm-12">
<ul class="nav nav-pills nav-fill customtab2" id="myTab" role="tablist">
<li class="nav-item">
<a class="nav-link active" id="trans-tab" data-toggle="tab" href="#transcript" role="tab" aria-controls="home" aria-selected="true">Transcript Certificate</a>
</li>
<li class="nav-item">
<a class="nav-link" id="degree-tab" data-toggle="tab" href="#degree" role="tab" aria-controls="profile" aria-selected="false">Degree Certificate</a>
</li>
<li class="nav-item disable">
<a class="nav-link" id="pass-tab" data-toggle="tab" href="#pass" role="tab" aria-controls="contact" aria-selected="false"> Pass Certificate</a>
</li>
</ul>
<div class="tab-content" id="myTabContent">
<!-- Transcript Start -->
<div class="tab-pane fade show active" id="transcript" role="tabpanel" aria-labelledby="home-tab">

<div class="col-sm-12">

@include('students.transcript')
</div>

</div>
<!-- Transcript end -->

<!-- degree certificate tab start -->
<div class="tab-pane fade" id="degree" role="tabpanel" aria-labelledby="profile-tab">
<br>
@include('students.degree')

</div>
<!-- Pass Certificate-->
<div class="tab-pane fade" id="pass" role="tabpanel" aria-labelledby="contact-tab">

<div class="container-fluid" style="background-color:white">
<br>
<div class="container" style="margin-left:28%">
<div class="row">

<div style="text-align: center;font-size: 170%;">

<p style="font-family: Old English Text MT; font-size: 30px; margin-left:40px;color: black;">Mehran University<br>Of<br>Engineering & Technology</p>
</div>

<div style="margin-left:10%">
<div>
<div style="color:black;margin-left: 70px;">{{$degreeInfo->algP}}</div>
</div>
<div>
<div id="qrcode2" style="margin-left: 90px;"></div>
</div>
</div>

</div>
</div>
<div class="row">
<div class="pull-left" style="color:black">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Book No. .......
</div>

<div class="pull-right" style="margin-left:80%; color:black">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Certificate No. .......
</div>
</div>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<img src="/img/logomuet.png" class="img-responsive" style="width: 20%;margin-left: 40%; margin-top: -38px;" />
</div>
</div>
<div class="row">

<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" style="margin-left: 3px; color:black">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Enrollnment No. {{$pinfo->enrollmentNo}}
</div>

<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
<p style="text-align: center;color: black;"><b><u> PASS CERTIFICATE</u></b></p>

</div>

</div>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
<p style="color: black;"><br>This&nbsp;&nbsp; is&nbsp; &nbsp;to&nbsp; &nbsp;certify&nbsp; &nbsp; that&nbsp; &nbsp;Mr/Miss.&nbsp;&nbsp; ...{{$pinfo->fullname}}................................................. S/O D/O&nbsp;...{{$pinfo->fatherName}}............................&nbsp; &nbsp;<br>                                            Having &nbsp;&nbsp;ID.&nbsp;&nbsp; No.&nbsp;&nbsp; ....{{$pinfo->rollNo}}....................&nbsp;&nbsp; has&nbsp; &nbsp;passed &nbsp;&nbsp;the&nbsp; &nbsp;<b>Bachelor  &nbsp;&nbsp;&nbsp;Of &nbsp;  &nbsp;
Engineering</b><br>&nbsp; &nbsp; <b>Examination&nbsp;</b>&nbsp;in&nbsp; the&nbsp; ..{{$pinfo->name}}............&nbsp; of &nbsp;the&nbsp; University&nbsp; held &nbsp;in &nbsp; the&nbsp;&nbsp; month of&nbsp; ...{{$name}}..{{$year}}............. .<br>                                            <br> He/She&nbsp;&nbsp; has&nbsp; secured &nbsp;...{{$degreeInfo->cgpa}}.................................. Commulative &nbsp;Grade&nbsp; Point Average
<br>Position&nbsp; &nbsp; (If Any): ....{{$value}}...........................................................................................
</p>
<p style="margin-right: 300px;color: black;"> <b>  &nbsp;&nbsp;Date&nbsp; of&nbsp; Declaration&nbsp; Of &nbsp;Result </b>...{{$degreeInfo->dod}}...........</p><br>


</div>
</div>
<div class="row" style="margin-left:10%">
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">

<br><br><br><br>
<p style="color: black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b> Jamshoro,Sindh-Pakistan.</b><br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<b> Dated the</b> .......................</p>
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" style="margin-left:10%">
<p style="margin-left: 70%;color: black;"><b>Controller of examination</b> </p>
<img src="/img/logo12.png" style="margin-left: 70%;" />
</div>
</div>

<p style="color: black;"> <b>Note:&nbsp;</b>1.&nbsp; The university reserves the right to issue any correction int hw result or any mistake detected later. </p>
<p style="margin-left: 54px;color: black;">2.&nbsp; this certifocate has been issued without any assure/overwriting.</p>
<p style="margin-left: 54px;color: black;">3.&nbsp; This criteria for award of Grade & Commulative point Average (C.G.P.A) has been elaborated overleaf.</p>
</div>
</div>

</div>
</div>
</div>

</div>
</div>

<script type="text/javascript">
var qrcode = new QRCode(document.getElementById("qrcode"), {
width: 90,
height: 90
});
var qrcode2 = new QRCode(document.getElementById("qrcode2"), {
width: 90,
height: 90
});

var qrcode1 = new QRCode(document.getElementById("qrcode1"), {
width: 90,
height: 90
});

function makeCode() {

qrcode.makeCode("{{$degreeInfo->algD}}");
qrcode2.makeCode("{{$degreeInfo->algP}}");
qrcode1.makeCode("{{$degreeInfo->algT}}");

}

makeCode();
</script>

@endsection



<!-- bootstrap -->
@section('bootstrap')
<script src="/assets/js/lib/circle-progress/circle-progress.min.js"></script>
<script src="/assets/js/lib/circle-progress/circle-progress-init.js"></script>

@endsection


 @section('scripts')
<script src="/js/jquery.min.js"></script>
<script src="/js/tether.min.js"></script>
<script src="/js/bootstrap.min.js"></script>



<!-- disable tabs according to priviliges-->
<script type="text/javascript">

$(document).ready(function(){

var a = $('#p1').val();


@php

if(array_key_exists('2',$prev) && array_key_exists('3',
  $prev) && array_key_exists('4',$prev))
{
  // same code is ok 
  
}
else if(array_key_exists('2',$prev) && !array_key_exists('3',$prev) && !array_key_exists('4',$prev))

{  // only view verified degrees
@endphp
  console.log('In 2');
   $('#trans-tab').addClass('disable');
   $('#trans-tab').removeClass('active');
   $('#trans-tab').removeAttr('data-toggle');
   $('#transcript').removeClass('active');
   $('#transcript').removeClass('show');

  $('#pass-tab').addClass('disable');
  $('#pass-tab').removeAttr('data-toggle');


  $('#degree-tab').addClass('active');
  $('#degree').addClass('active');
  $('#degree').addClass('show');


@php
}

else if(array_key_exists('3',$prev) && !array_key_exists('2',$prev) && !array_key_exists('4',$prev)) 

{ // only view verified pass certificate
@endphp

   $('#trans-tab').addClass('disable');
   $('#trans-tab').removeClass('active');
   $('#trans-tab').removeAttr('data-toggle');
   $('#transcript').removeClass('active');
   $('#transcript').removeClass('show');
  
  $('#degree-tab').addClass('disable');
  $('#degree-tab').removeAttr('data-toggle');

  $('#pass-tab').addClass('active');
   $('#pass').addClass('active');
   $('#pass').addClass('show');

@php 
}

else if(array_key_exists('4',$prev) && !array_key_exists('2',$prev) && !array_key_exists('3',$prev))

{  // only view verified Transcript
@endphp
$('#degree-tab').addClass('disable');
$('#degree-tab').removeAttr('data-toggle');

$('#pass-tab').addClass('disable');
$('#pass-tab').removeAttr('data-toggle');

@php
}

else if(array_key_exists('3',$prev) && array_key_exists('4',$prev) && !array_key_exists('2',$prev))

{ // only view pass and trancript
@endphp
$('#degree-tab').addClass('disable');
$('#degree-tab').removeAttr('data-toggle');

@php
}
else if(array_key_exists('2',$prev) && array_key_exists('4',$prev) && !array_key_exists('3',$prev))

{ // only transcript and degree
@endphp
$('#pass-tab').addClass('disable');
$('#pass-tab').removeAttr('data-toggle');

@php
}
else if(array_key_exists('2',$prev) && array_key_exists('3',$prev) && !array_key_exists('4',$prev))

{  // only view degree and pass
@endphp
   $('#trans-tab').addClass('disable');
   $('#trans-tab').removeClass('active');
   $('#trans-tab').removeAttr('data-toggle');
   $('#transcript').removeClass('active');
   $('#transcript').removeClass('show');

   $('#degree-tab').addClass('active');
   $('#degree').addClass('active');
   $('#degree').addClass('show');

@php
}
@endphp


document.getElementById('dashboard').classList.remove('active');

document.getElementById('students').classList.remove('active');
document.getElementById('staff').classList.remove('active');

document.getElementById('account_rights').classList.remove('active');

document.getElementById('profile').classList.remove('active');

document.getElementById('log').classList.remove('active');

document.getElementById('setting').classList.remove('active');


document.getElementById('verstudents').classList.add('active');



});



</script>

</body>
</html>