<div class="container">

<div class="row">
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
<img src="/img/logomuet.png" class="img-responsive " style="width: 35%;    margin-top: 15px; float: left;"/>    
</div>

<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 " style="margin-top: 15px; text-align: center;  font-size: 150%; ">


<p style="font-family: Old English Text MT;color: black;  " >Mehran University<br>Of<br>Engineering and Technology</p>
</div>

<div style="margin-left:80%;margin-top: -10%;">
<div>
<div style="margin-left: 30%">{{$degreeInfo->algT}}</div>
</div>
<div>
<div id="qrcode1" style="margin-left: 50%"></div>
</div>
</div>

</div>
<br>

<div class="row">
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" style="color: black;">
Book No. .......
</div>

<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
<p style="margin-left: 20%;color: black;"><b>TRANSCRIPT CERTIFICATE</b></p>
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
Certificate No.......
</div>
</div>
<div class="row">
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">

Name of Student: {{ucwords($pinfo->fullname)}} 
 {{ $pinfo->gender== 'm' ? 'S/O' : 'D/O' }} 
 {{ucwords($pinfo->fatherName)}}
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">

<p style="margin-left: 21%;color: black;"><b>Bachelor of Engineering </b></p>
</div>


<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
Enrollnment No: {{$pinfo->enrollmentNo}}
</div>
</div>

<div class="row">
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
Date of Admission: {{$pinfo->doa}}
</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
<p style="margin-left: 31%;color: black;"><b>
  ({{
    chop(strtoupper($pinfo->name),"ENGINEERING")
  }})
</b></p>
</div>


<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4" >
Identification: {{strtoupper($pinfo->rollNo)}}
        </div>
</div>
<div class="row">

<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" >
Date of passing: {{$degreeInfo->dop}}                                                           
</div>
<div style="margin-left: 67%;" class="col-lg-6 col-md-6 col-sm-6 col-xs-6" >
 @php
 if($degreeInfo->position==1){$position="1st";}
 elseif($degreeInfo->position==2){$position="2nd";}
 elseif($degreeInfo->position==3){$position="3rd";}
 else{$position = "";}
 @endphp 
position Secured:....{{$position}}......
</div>        
</div>
</div>




 
<div class="content-wrap">
  <div class="main">
      <div class="container-fluid">
          <main role="main">

            <table class="marksSheet center">
          <thead>
            <tr>
              <th rowspan="6" class="year" style="text-align: left;">Year</th>
              
              <th rowspan="3" class="sems" style="text-align: left;">Semester</th>
              <th class="subj" style="text-align: left;">Subject</th>
               <th class="chr" style="text-align: left;">Credit hour</th>

              <th class="maxM" style="text-align: left;">Max Marks</th>
              <th class="minM" style="text-align: left;">Min Marks</th>
              <th class="mObt" style="text-align: left;">Marks obtained</th>
              <th class="grade" style="text-align: left;">Grade</th>
             
              <th rowspan="3" class="gpa"  style="text-align: left;">g.p.a</th>

              <th rowspan="6" class="cgpa" style="text-align: left;">C.g.p.a</th>

            </tr>
          </thead>

          <tbody >
  

@php
$check=0;
$counter = 0;
$flag = 0;
$year = 0;
$semsName = "";
$yearName = "";
$yearCgpa = 0;
@endphp           

@foreach($marksInfo as $info)
<tr>
@if($counter!=$info->sems && $flag!=$info->sems)
@php
$counter = $info->sems;
$year = $semester[$counter]+ $semester[++$counter];
$counter= 0;
if(count($semester)==8)
{
if($info->sems==1){$yearName = "FIRST";}
elseif($info->sems==3){$yearName = "SECOND";}
elseif($info->sems==5){$yearName = "THIRD";}
elseif($info->sems==7){$yearName = "FINAL";}
}

elseif(count($semester)==10)
{
if($info->sems==1){$yearName = "FIRST";}
elseif($info->sems==3){$yearName = "SECOND";}
elseif($info->sems==5){$yearName = "THIRD";}
elseif($info->sems==7){$yearName = "FOURTH";}
elseif($info->sems==9){$yearName = "FINAL";}
}
@endphp

<td rowspan="{{$year}}"  style="text-align: left;color: black;">{{$yearName}}</td>

@endif

@if($check!=$info->sems)
 @php
 if($info->sems==1||$info->sems==3||$info->sems==5||$info->sems==7|| $info->sems==9)
{$semsName = "1ST";}

 elseif($info->sems==2||$info->sems==4||$info->sems==6||$info->sems==8|| $info->sems==10)
{$semsName = "2ND";}
@endphp

 <td rowspan="{{$semester[$info->sems]}}"  style="text-align: left;color: black;">{{$semsName}}</td>


@endif


@if($info->IsTheory==1)

 
    <td style="text-align: left;color: black;">{{$info->courseName}}<sub>(THEORY)</sub>
    </td>
    <td style="text-align: left;color: black;">{{$info->creditHr}}
    </td> 
    <td style="text-align: left;color: black;">{{$info->maxMarks}}
    </td>
    <td style="text-align: left;color: black;">{{$info->maxMarks/2}}
    </td>
    <td style="text-align: left;color: black;">
      {{$info->markObtInTh}}
    </td>
    <td style="text-align: left;color: black;">
      {{$grades[0][$info->courseCode]}}
    </td>
    @endif

    @if($check!=$info->sems)

    <td rowspan="{{$semester[$info->sems]}}"  style="text-align: left;color: black;">{{$semGpa[$info->sems]}}
    </td>
      @php $check = $info->sems; @endphp
     @endif

    @if($counter!=$info->sems && $flag!=$info->sems)
    @php
     $counter = $info->sems;
    $year = $semester[$counter]+ $semester[++$counter];
   
     $counter = $info->sems;
    $yearCgpa = ($semGpa[$counter] + $semGpa[++$counter])/2; 
   
      $counter = $info->sems;
     $flag    = ++$counter;
     $counter = $info->sems;
     @endphp
    <td rowspan="{{$year}}"  style="text-align: left;color: black;">
  {{$yearCgpa}}
    </td>
   @endif
  </tr>
  

  <!-- Now for practical marks-->

@if($info->IsPractical==1)

<tr >
 @if($loop->last)
 
 <td rowspan="{{$year}}"  style="text-align: left;color: black;"></td>

<td rowspan="{{$semester[$info->sems]}}"  style="text-align: left;color: black;"></td>
@endif


<td style="text-align: left;color: black;">{{$info->courseName}}<sub>(PRACTICAL)</sub>
    </td>
    <td style="text-align: left;color: black;">{{$info->creditHour}}
    </td> 
    <td style="text-align: left;color: black;">{{$info->maximumMarks}}
    </td>
    <td style="text-align: left;color: black;">{{$info->maximumMarks/2}}
    </td>
    <td style="text-align: left;color: black;">
      {{$info->markObtInPr}}
    </td>
    <td style="text-align: left;color: black;">
  {{$grades[1][$info->courseCode]}}
    </td>
   @if($loop->last)
  
    <td rowspan="{{$semester[$info->sems]}}"  style="text-align: left;">
    </td>
    

    <td rowspan="{{$year}}"  style="text-align: left;">
    </td>
   @endif

  
  </tr>
 @endif
@endforeach


</tbody>
</table>

<table style="width: 100%;">
  <tr>

    <td style="text-align:left;color:black;">
  <div style="margin-left: 65%;">
   <b>   Cumulative G.P.A(1<sup>st</sup> to Final Year)
     = {{$degreeInfo->cgpa}}
   </b> 
  </div>
     
    
  </td>
  </tr>
</table>
</main>
</div>
</div>
</div>

