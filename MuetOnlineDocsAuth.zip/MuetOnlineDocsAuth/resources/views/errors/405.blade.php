<!DOCTYPE html>
<html>
<head>
	
	<title></title>

	<link href="/assets/css/lib/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/css/style.css">

</head>
<body style="background-color: #f4f4f5;">
	
<div class="web_back_color">
	<nav class="navbar">
	  
	  <a class="navError navbar-brand" href="/">
	    
	    <img src="/img/logo.png" alt="" width="48px" height="48px">
	    
	    {{ config('app.name')}} 
	  
	  </a>

	</nav>
</div>

<br>

<header class="p-5" style="margin-left: 10%">

	<h4 style="font-weight: bolder;color: #333">Method Not Allowed</h4>
	<hr>

	<p>The requested method is not allowed.</p>
	<hr>

	<p class="text-center">
		&copy; {{\Carbon\Carbon::now()->year}}. {{ config('app.name')}} 
	</p>
	<hr>

</header>

    <!-- Scripts for InnerView -->
    <script src="/js/jquery.min.js"></script>
    <script src="/js/tether.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
</body>
</html>