<!-- sidebar -->

<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">       
 <div class="nano web_back_color">
            <div class="nano-content web_back_color">
                <div class="logo" style="background-color: #24273c;">

                    <!-- name in the sidebar at the top -->
                    
                    <a href="/dashboard/profile">

                        <img 
                        
                                src=

                                @if(session('staffInfo')[0]->pic!=null)
                                  "{{ asset('storage/uploads/staff/'
                                .session('staffInfo')[0]->pic)}}"

                                @else

                                "/img/avatar.png"

                                @endif



                            class="img-responsive rounded-circle" alt="" style="width:50%;height: 100px;" />         
                    </a>
                </div>
                <ul>
                    <li class="active" id="dashboard">
                        <a href="/dashboard">
                            <i class="ti-home"></i> Dashboard</a>
                    </li>
                    
                    @if(array_key_exists ( 'emp' , $result ) || array_key_exists ( 'std' , $result ) || array_key_exists ( 'acc_rights' , $result ))
                        
                        <li class="label">Manage</li>
                    
                    @endif

                        @if(array_key_exists ( 'emp' , $result ))

                            <li id="staff"> 
                                <a href="/dashboard/employees"><i class="ti-world"></i>Employee Accounts</a>
                            </li>

                        @endif

                        <li id="staff"> </li>
                        
                        @if(array_key_exists ( 'std' , $result ))

                            <li id="students">
                                <a href="/dashboard/students"><i class="ti-world"></i>Students</a>
                            </li>

                        @endif

                        <li id="students"></li>


                        @if(array_key_exists ( 'acc_rights' , $result ))

                            <li id="account_rights">
                                <a href="/dashboard/account_rights">
                                    <i class="ti-key"></i>
                                    Accounts Rights
                                </a>
                            </li>

                        @endif
                        <li id="account_rights"></li>

                    @if(array_key_exists ( 'vstd' , $result ))

                    <li class="label">General</li>

                        <li id="verstudents">
                            <a href="/dashboard/verifiedStudents"><i class= "ti-check-box"></i> Verified Students </a>
                        </li>

                    @endif

                    <li id="verstudents"></li>


                    <li class="label">Account Information</li>

                    <li id="profile"><a href="/dashboard/profile"><i class="ti-user"></i>Profile</a></li>

                    <li id="log"><a href="/dashboard/log"><i class="ti-bar-chart-alt"></i>Activity Log</a></li>

                    <li id="setting">
                        <a href="/dashboard/settings"><i class="ti-pencil-alt"></i>Settings</a>
                    </li>
                    
                    <li><a href="/logout"><i class="ti-close"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /# sidebar -->

    