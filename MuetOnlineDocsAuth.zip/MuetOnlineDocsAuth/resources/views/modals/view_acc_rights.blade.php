 <div class="modal fade" id="viewaccrights" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title text-white" id="addEModalLabel">Role - ' {{ucwords($res2[0]->name)}} '</h5>
                    <button class="close text-white" data-dismiss="modal">
                     <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                	<h3 class="text-center">
                		{{ucwords($res2[0]->name)}}
                	</h3>
                	<p class="text-center">
                		{{strtolower($res2[0]->desc)}}
                	</p>

                	<legend>Privileges Assigned</legend>

                                        
                    <div class="phone-content" id="prevassigned" >

                    	@foreach( $res as $value)
                        	<p>
                        		{{ucfirst($value->prevDesc)}}
                        	</p>
                        @endforeach
                    </div>

                </div>
            </div>
        </div>
    </div>