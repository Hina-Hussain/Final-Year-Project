<!-- Create Employee Info Modal start-->

<div class="modal  fade" id="addemp">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<div class="modal-header web_back_color text-white">
<h5 class="modal-title text-white" id="addEModalLabel">Create Employee Account</h5>
<button class="close text-white" data-dismiss="modal">
<span>&times;</span>
</button>
</div>
<div class="modal-body">

<form class="form-horizontal" role="form" method="post" action="/employee/create" enctype="multipart/form-data" id='createemp'> 

<div class="col-sm-12">

@csrf

<div class=" text-center">
<br>
<legend>Personal Information</legend>

<div class="alert alert-danger text-white" role="alert" id="cimgeerror" style="display:none;">
Image should be less than 64 kb in size and image should have jpg or png extension!
</div>

<div class="alert alert-danger" role="alert" id="cerror" style="display:none;color:white;">
<!-- display errors here  -->
</div>

<div class="row">
<div class="col-sm-8">
<br>

<div class="form-group row" id="idElement">

<label for="Name" class="col-sm-3 col-form-label mt-2">Staff Id</label>
<div class="col-sm-6">
<input type="text" name="staffid" class="form-control" id="cempid" placeholder="Enter employee id" required>

</div>

</div>

<div class="form-group row" >
<label for="Name" class="col-sm-3 col-form-label mt-2">Email</label>
<div class="col-sm-6">
<input type="email" name="email" class="form-control" id="cemail" placeholder="Enter employee email" required>

</div>
</div>

<div class="form-group row">

<div class="alert alert-primary" id="passrules" style="color:white;;text-align: left; width: 80%;margin-left: 5%;font-size: 0.9em;border: 1px solid white;border-radius: 5px;display: none;">

<ul>
<li>
&bull; Password should have atleast 6 characters.
</li>
<li>
&bull; Password should have one Uppercase character.
</li>
<li>
&bull; Password should have one Lowercase character.
</li>
</ul>
</div>

</div>

<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label mt-2">Password</label>
<div class="col-sm-6">
<input name="password" class="form-control" id="cpassword" placeholder="Enter employee password"  type="password"  required minlength="6">
</div>
</div>

<div class="form-group row">
<label for="Name" class="col-sm-3 col-form-label mt-2">Confirm Password</label>
<div class="col-sm-6">
<input  name="password_confirmation" class="form-control" id="cpassword_confirmation" placeholder="Enter employee password again" type="password" required minlength="6">
</div>
</div>


<div class="form-group row">
<label for="domicile" class="col-sm-3 control-label mt-2">Role</label>
<div class="col-sm-6">
<select class="form-control selectpicker" id='croleSelect' name="select" data-roles="{{$res['rolePrevs']}}" data-prevs="{{$res['prevs']}}">

<option id="cCustom role" name="Custom role">Custom role</option>

@foreach($res['roles'] as $value)

<option name="{{$value->id}}"  value="{{$value->id}}">
{{ucwords($value->name)}}
</option>

@endforeach
</select>
</div>
</div>

<div class="form-group row" id='cform'>

<label for="Name" class="col-sm-3 col-form-label mt-2">Role Name</label> 

<div class="col-sm-6"> 
<input type="text" name="role-name" class="form-control" id="crole_name" placeholder="Enter role name" required >
</div>

</div>

<div class="form-group row" id='cform1'>

<label for="Name" class="col-sm-3 col-form-label mt-2">Role Description</label> <div class="col-sm-6"> <input type="text" name="role-desc" class="form-control" id="crole_desc" placeholder="Enter role description" required></div> 

</div>

</div>

<div class="col-sm-4">

<img src="/img/avatar.png" alt="" class="img-fluid mb-3" width="170px" height="170px" style="padding-top: 2%;" id="cuser_pic_edit" >
<div class="form-group" id="cselectFile">
<input type="file" class="mr-8 form-control-file " name="image" onchange="imagePreview(this.files[0],1)">
</div>
</div>
</div>
</div>
</div>

<div class="col-sm-12">                 
<div class=" text-center">
<br>
<legend>Employee Privilege</legend>
</div>


<div id="cprevss" name="prevs">

@foreach($res['prevs'] as $value)

<div class="row">
<div class="form-group row ml-5 pl-5">
<input class="form-check-input" type="checkbox" value="1" id= 'cp{{$value->id}}' onchange="clicked(this.id,1)" name="{{$value->id}}" >

<label class="form-check-label" style="color:black" for="label" id='cpd{{$value->id}}'>{{ucfirst($value->prevDesc)}}</label>

</div>
</div>

@endforeach
</div>
</div>

<div class="pull-right">
<button type="button" class="btn btn-primary" id="csubmitFormChanges" data-prevs="{{$res['prevs']}}"  style="border-radius:5px;">Save Changes</button>

<button type="button" class="btn btn-dark text-white" data-dismiss="modal"  style="border-radius:5px;">Cancel</button>

</div>


</form>
</div>

</div>

</div>
</div>
